package it.polito.laib_3.seller

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.android.volley.RequestQueue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.Consegna
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.formatCurrency
import it.polito.laib_3.sendNotification
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter


@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDetailSeller(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, delivery: Consegna, FCM_API:String, serverKey:String, contentType:String, requestQueue: RequestQueue) {

    var username = ""
    viewModel.users.forEach(){u ->
        if(u.email == delivery.id_destinatario)
            username = u.username

    }

    var count by remember { mutableStateOf(0) }
    var totProds by remember { mutableStateOf(0) }

    var back by remember { mutableStateOf(false) }
    var route by remember { mutableStateOf("") }

    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
    val current = LocalDateTime.now().format(formatter)

    val parts1 = current.split(" | ")
    val date = parts1[0]
    val time = parts1[1]


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text="Ordine di "+username
                ) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = {
                                       if(count>0)
                                       {    back=true
                                           route = ""+Screen.HomeSellerScreen.route}
                                       else
                                           navController.navigate(Screen.HomeSellerScreen.route)
                                        })
                    {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {

                        IconButton(onClick = {
                            if(count>0)
                            {    back=true
                                route = ""+Screen.HomeSellerScreen.route}
                            else
                                navController.navigate(Screen.HomeSellerScreen.route)
                        })
                        {
                            Image(
                                painter = painterResource(id = R.drawable.home),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                if(count>0)
                                {    back=true
                                    route = ""+Screen.SellerLockerScreen.route}
                                else
                                    navController.navigate(Screen.SellerLockerScreen.route)
                            })
                        {
                            Image(
                                painter = painterResource(id = R.drawable.lock),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                if(count>0)
                                {    back=true
                                    route = ""+Screen.SellerOrdersScreen.route}
                                else
                                    navController.navigate(Screen.SellerOrdersScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = {
                            if(count>0)
                            {    back=true
                                 route = ""+Screen.SellerProfileScreen.route}
                            else
                                navController.navigate(Screen.SellerProfileScreen.route)
                        }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                 //   horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(15.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Favorite Item",
                            )
                            Spacer(modifier = Modifier.width(12.dp))

                            var address = ""
                            viewModel.lockersList.forEach() { lock ->
                                if (lock.id_locker == delivery.locker)
                                    address = lock.spaces[0].address
                            }


                            Text(
                                text = "" + address,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                //  textAlign = TextAlign.Left,
                            )
                        }

                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {

                        Text(
                            text = "Da consegnare "+viewModel.currentDay.value+" entro le "+delivery.time_Due,
                            fontSize = 16.sp,
                        )
                    }

                    val oraActual = LocalTime.now()
                    val delHour = delivery.time_Due.split(":")
                    val hh = delHour[0]
                    val mm = delHour[1]

                    val delHour2 = LocalTime.of(hh.toInt(), mm.toInt())
                    val isPrecedente = delHour2.isBefore(oraActual)

                    if(isPrecedente && viewModel.currentDay.value=="oggi") {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically

                        ) {

                            Text(
                                text = "Preparazione in ritardo",
                                color=Color.Red,
                                fontSize = 16.sp,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)
                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        Text(
                            text = "Da preparare:",
                            fontSize = 20.sp,
                        )
                    }
                    Spacer(modifier = Modifier.height(5.dp))



                    val prods: Map<String, Int> = delivery.products.split(',')
                        .map { it.split(':') }
                        .associate { it[0] to it[1].toInt() }

                    totProds = prods.size


                    prods.forEach(){ item->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement
                                .spacedBy(
                                    space = 10.dp,
                                    alignment = Alignment.Start
                                ),
                            verticalAlignment = Alignment.CenterVertically

                        ) {
                            Checkbox(
                                checked = viewModel.availables.contains(item.key),
                                onCheckedChange = { isChecked ->
                                    if (isChecked) {
                                        viewModel.addToAvailable(item.key)
                                        count++
                                    } else {
                                        viewModel.removeToAvailable(item.key)
                                        count--
                                    }
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = colorResource(id = R.color.green), // Colore quando la Checkbox è selezionata
                                    uncheckedColor = Color.White // Colore quando la Checkbox non è selezionata
                                )
                            )


                            Text(
                                text = ""+item.key+" x "+item.value,
                                fontSize = 16.sp,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.padding(end=20.dp)
                            )
                        }

                    }

                    Spacer(modifier = Modifier.height(15.dp))

                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 220.dp,
                                //  alignment = Alignment.Start
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Totale",
                            fontSize = 18.sp,
                            fontWeight= FontWeight.Bold,
                            textAlign = TextAlign.Start,
                        )

                        Text(
                            text = "${formatCurrency(delivery.price)} €",
                            fontSize = 18.sp,
                            textAlign = TextAlign.Right,
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Pagato con",
                            fontSize = 18.sp,
                            textAlign = TextAlign.End,
                        )
                        Spacer(modifier = Modifier.width(20.dp))
                        Image(
                            painter = painterResource(
                                id =
                                if(delivery.payment=="PayPal") R.drawable.paypal
                                else if(delivery.payment=="Apple Pay") R.drawable.applepay
                                else R.drawable.card ),
                            contentDescription = "confermato",
                            modifier = Modifier.size(60.dp),
                            contentScale = ContentScale.Fit )

                    }

                    Spacer(modifier = Modifier.height(50.dp))


                        Button(
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(2.dp, colorResource(id = R.color.green)),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                            modifier = Modifier
                                .bounceClick()
                                .wrapContentSize()
                                .align(Alignment.CenterHorizontally)
                                .padding(8.dp), // Aggiunto padding per un margine più piacevole
                            onClick = {

                                var code = ""

                                viewModel.deliveriesComplete.forEach(){ del ->
                                    if(del.value == delivery)
                                        code = del.key
                                }

                                //   var del = viewModel.currentDelivery.value
                                var updatedDel = delivery?.let {
                                    Consegna("toLocker", it.date_Start, delivery.time_Start, date, time, delivery.date_Due, delivery.time_Due,
                                        delivery.id_mittente, delivery.id_destinatario, delivery.locker, delivery.locker_space, delivery.code_inserimento,
                                        delivery.code_sblocco, delivery.products, delivery.price, delivery.payment, "")
                                }

                                db.child("deliveries").child(""+code).setValue(updatedDel)

                                navController.navigate(Screen.HomeSellerScreen.route)
                                viewModel.clearAvailable()

                                val topic = "/topics/SELLER${code.drop(1)}" //topic has to match what the receiver subscribed to

                                val notification = JSONObject()
                                val notifcationBody = JSONObject()

                                try {
                                    notifcationBody.put("title", "Goodbuy")
                                    notifcationBody.put("message", "Il tuo ordine presso ${delivery.id_mittente} è stato preparato. " +
                                            "A breve verrà portato al locker")   //Enter your notification message
                                    notification.put("to", topic)
                                    notification.put("data", notifcationBody)
                                    Log.d("ccccccccc", "try+ topic : "+topic)
                                } catch (e: JSONException) {
                                    Log.e("ccccccc", "onCreate: " + e.message)
                                }

                                sendNotification(notification,FCM_API, serverKey,contentType,requestQueue)

                                      },
                            enabled = count==totProds,
                            content = {
                                Text(
                                    text = "Ordine pronto",
                                    fontSize = 16.sp
                                )
                            }
                        )
                }
            }
        }
    }

    if (back) {
        AlertDialog(
            onDismissRequest = { back = false },
            text = { Text("Sei sicuro di voler tornare indietro? Tutti i progressi non verranno salvati") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = colorResource(id = R.color.green),
                        contentColor = Color.Black
                    ),
                    onClick = {
                        back = false
                        viewModel.clearAvailable()
                        navController.navigate("" + route)
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = colorResource(id = R.color.green),
                        contentColor = Color.Black
                    ),
                    onClick = { back = false }
                ) {
                    Text("Annulla")
                }
            }
        )
    }
    }
}