package it.polito.laib_3.user

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Log
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.formatCurrency


@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage: StorageReference) {

    var context = LocalContext.current
    var route by remember { mutableStateOf("") }
    var back by remember { mutableStateOf((false)) }


    viewModel.favs.forEach(){ f->

        Log.d("aaaa", "FirebaseUtentifavs first shop  " + f)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text="Carrello"
                     ) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.ShopScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { route = ""+Screen.HomeUserScreen.route
                            if(viewModel.cart.isEmpty()) {
                                viewModel.clearCurrentCatProds()
                                navController.navigate(""+route)
                            }
                            viewModel.clearCurrentCatProds()
                            viewModel.clearCurrentProds()
                            back = true}) {
                            Image(
                                painter = painterResource(id = R.drawable.home),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(
                            onClick = {
                                route = ""+ Screen.UserSearchScreen.route
                                if(viewModel.cart.isEmpty()) {
                                    viewModel.clearCurrentCatProds()
                                    navController.navigate(""+route)
                                }
                                viewModel.clearCurrentCatProds()
                                viewModel.clearCurrentProds()

                                back = true
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { route = ""+Screen.OrdersUserScreen.route
                                if(viewModel.cart.isEmpty()) {
                                    viewModel.clearCurrentCatProds()
                                    navController.navigate(""+route)
                                }

                                back = true
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { route=""+Screen.UserProfileScreen.route
                            if(viewModel.cart.isEmpty()) {
                                viewModel.clearCurrentCatProds()
                                navController.navigate(""+route)
                            }
                            viewModel.clearCurrentCatProds()
                            viewModel.clearCurrentProds()
                            back = true  }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },

    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 5.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                        verticalAlignment = Alignment.CenterVertically

                    ) {

                        Image(
                            painter = painterResource(id = R.drawable.carrello),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                            modifier = Modifier.size(23.dp)
                        )


                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight / 2),
                                end = Offset(x = 0f, y = canvasHeight / 2),
                                color = Color.Gray,
                                strokeWidth = 1F
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.pin),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.Gray),
                            modifier = Modifier.size(23.dp)
                        )
                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight / 2),
                                end = Offset(x = 0f, y = canvasHeight / 2),
                                color = Color.Gray,
                                strokeWidth = 1F
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.wallet),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.Gray),
                            modifier = Modifier.size(23.dp)
                        )

                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                    Spacer(modifier = Modifier.height(10.dp))

                    if (!viewModel.cart.isEmpty()) {
                        viewModel.cart.forEach() { item ->

                            if (item.value > 0) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement
                                        .spacedBy(
                                            space = 10.dp,
                                            alignment = Alignment.Start
                                        ),
                                    verticalAlignment = Alignment.CenterVertically

                                ) {
                                    val bitmap = remember { mutableStateOf<Bitmap?>(null) }

                                    var image = item.key.image
                                    storage.child("images/$image").getBytes(Long.MAX_VALUE)
                                        .addOnSuccessListener { bytes ->
                                            bitmap.value =
                                                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                        }.addOnFailureListener {}

                                    bitmap?.value.let { btm ->

                                        if (btm != null) {
                                            Box(
                                                modifier = Modifier.height(45.dp).width(35.dp)
                                                    .border(2.dp, Color.Black)
                                                    .clip(shape = RoundedCornerShape(size = 12.dp))
                                            )
                                            {
                                                Image(
                                                    bitmap = btm.asImageBitmap(),
                                                    contentDescription = null,
                                                    contentScale = ContentScale.Crop
                                                )
                                            }
                                        } else {
                                            Box(
                                                modifier = Modifier.height(35.dp).width(35.dp)
                                                    .border(2.dp, Color.Black)
                                                    .clip(shape = RoundedCornerShape(size = 12.dp))
                                            ) {
                                                val view = remember { ImageView(context) }

                                                // Load Gif with Glide library
                                                DisposableEffect(context) {
                                                    Glide.with(context)
                                                        .asGif()
                                                        .load("https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif")
                                                        .into(view)
                                                    onDispose {
                                                        // Cleanup when the composable is disposed
                                                        Glide.with(context).clear(view)
                                                    }
                                                }
                                                AndroidView(factory = { view })
                                            }
                                        }
                                    }

                                    Box(
                                        modifier = Modifier.fillMaxHeight().width(120.dp)
                                    )
                                    {
                                        Text(
                                            text = "" + item.key.name,
                                            fontSize = 16.sp,
                                            textAlign = TextAlign.Start,
                                            modifier = Modifier.padding(end = 15.dp)
                                        )
                                    }

                                    CircleButton(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Minus",
                                        clickable = item.value != 0
                                    ) {
                                        if (item.value != 0) {
                                            viewModel.updateCart(item.key, item.value - 1)
                                            viewModel.updatePrice()
                                        }
                                    }

                                    Text(
                                        text = "${item.value}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight(500),
                                        color = Color.White
                                    )

                                    CircleButton(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add"
                                    ) {
                                        viewModel.updateCart(item.key, item.value + 1)
                                        viewModel.updatePrice()
                                    }

                                    //Spacer(modifier = Modifier.size(5.dp))

                                    Box(
                                        modifier = Modifier.fillMaxWidth().width(100.dp)
                                    )
                                    {
                                        Text(
                                            //modifier = Modifier.padding(start=10.dp),
                                            text = "€" + formatCurrency(item.key.price.toDouble() * item.value),
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                            //textAlign = TextAlign.Right,
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement
                                .spacedBy(
                                    space = 220.dp,
                                    //  alignment = Alignment.Start
                                ),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Totale",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Start,
                            )

                            viewModel.updatePrice()
                            Text(
                                text = "€${viewModel.totalPrice.value?.let { formatCurrency(it) }}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Right,
                            )
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Il tuo carrello è vuoto.",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Start,
                            )
                        }
                    }


                    Spacer(modifier = Modifier.height(40.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(120.dp),
                        enabled = if (viewModel.cart.isEmpty()) false else true,
                        onClick = { navController.navigate(Screen.LockerPositionScreen.route) },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = colorResource(
                                id = R.color.green
                            ), contentColor = Color.Black
                        ),
                        content = {
                            Text(
                                text = "Avanti",

                                fontSize = 16.sp
                            )
                        }
                    )


                }
                }
            }
        }
    }

    if (viewModel.cart.isEmpty()) {
        AlertDialog(
            onDismissRequest = {navController.navigate(Screen.ShopScreen.route) },
            text = {
                Text(
                    text = "Non hai più elementi nel carrello!",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .wrapContentSize(),
                        shape = RoundedCornerShape(10.dp),
                        //border = BorderStroke(2.dp, colorResource(id = R.color.green)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = colorResource(id = R.color.green),
                            contentColor = Color.Black
                        ),
                        onClick = {
                            navController.navigate(Screen.ShopScreen.route)
                            viewModel.clearActualLockers()
                        }
                    ) {
                        Text("Torna allo shop")
                    }
                }
            }
        )

    }
    if (back && !viewModel.cart.isEmpty()) {
        AlertDialog(
            onDismissRequest = { back = false },
            text = { Text("Sei sicuro di voler tornare indietro? Il tuo carrello non verrà salvato") },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = { back = false }
                ) {
                    Text("Annulla")
                }
            },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = { back = false
                        viewModel.clearCart()
                        viewModel.clearActualLockers()
                        viewModel.clearCurrentCatProds()

                        viewModel.currentDimension.value = ""
                        viewModel.totalPrice.value = 0.0
                        viewModel.currentShop.value=null
                        viewModel.currentLocker.value = null
                        viewModel.currentLockerSpace.value=null
                        viewModel.currentDate.value = ""
                        viewModel.currentTime.value = ""
                        viewModel.currentTimeChoice.value = ""
                        viewModel.currentDelivery.value=null
                        viewModel.credit.value=false

                        viewModel.changeChoice(0)
                        viewModel.changeAddress("")


                        navController.navigate(""+route)
                    }
                ) {
                    Text("OK")
                }
            }
        )

    }
}



