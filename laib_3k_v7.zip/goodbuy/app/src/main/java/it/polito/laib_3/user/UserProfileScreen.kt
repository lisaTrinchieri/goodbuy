package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    var exit by remember { mutableStateOf((false)) }
    var found by remember { mutableStateOf((false)) }



    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Goodbuy") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    //containerColor = Color.Black,
                    titleContentColor = Color.White,
                ),
            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
          //  horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    //  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ciao ${viewModel.currentUser.value?.username} !",
                            fontSize = 25.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Start,
                        )
                    }



                    Spacer(modifier = Modifier.height(20.dp))
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(5.dp),
                        horizontalAlignment = Alignment.Start,
                    ) {

                        Divider(color = Color.Black, thickness = 2.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                                .clickable { navController.navigate(Screen.UserFavouriteScreen.route) },
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.fillMaxHeight().width(230.dp),
                                contentAlignment = Alignment.CenterStart
                            )
                            {
                                Text(
                                    text = "I tuoi preferiti",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                )
                            }
                            // Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Spacer(modifier = Modifier.width(50.dp))
                            Box(
                                modifier = Modifier.fillMaxHeight().width(40.dp),
                                contentAlignment = Alignment.CenterStart
                            )
                            {
                                Icon(
                                    Icons.Filled.ArrowForward,
                                    contentDescription = "Favorite",
                                    modifier = Modifier.size(ButtonDefaults.IconSize),
                                    tint = Color.White
                                )
                            }


                        }


                        Divider(color = Color.Black, thickness = 2.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                                .clickable { navController.navigate(Screen.UserSettingsScreen.route) },
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.fillMaxHeight().width(230.dp),
                                contentAlignment = Alignment.CenterStart
                            )
                            {
                                Text(
                                    text = "Impostazioni",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                )
                            }

                            Spacer(modifier = Modifier.width(50.dp))
                            Box(
                                modifier = Modifier.fillMaxHeight().width(40.dp),
                                contentAlignment = Alignment.CenterStart
                            )
                            {
                                Icon(
                                    Icons.Filled.ArrowForward,
                                    contentDescription = "Favorite",
                                    modifier = Modifier.size(ButtonDefaults.IconSize),
                                    tint = Color.White
                                )
                            }

                        }

                        Divider(color = Color.Black, thickness = 2.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth().height(50.dp).clickable { },
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.fillMaxHeight().width(230.dp),
                                contentAlignment = Alignment.CenterStart
                            )
                            {
                                Text(
                                    text = "FAQ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    textAlign = TextAlign.Start,
                                )
                            }
                            Spacer(modifier = Modifier.width(50.dp))
                            Box(
                                modifier = Modifier.fillMaxHeight().width(40.dp),
                                contentAlignment = Alignment.CenterStart
                            )
                            {
                                Icon(
                                    Icons.Filled.ArrowForward,
                                    contentDescription = "Favorite",
                                    modifier = Modifier.size(ButtonDefaults.IconSize),
                                    tint = Color.White
                                )
                            }
                        }
                        Divider(color = Color.Black, thickness = 2.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                                .clickable { exit = true },
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.fillMaxHeight().width(230.dp),
                                contentAlignment = Alignment.CenterStart
                            )
                            {
                                Text(
                                    text = "Esci dal profilo",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    textAlign = TextAlign.Start,
                                )
                            }
                            Spacer(modifier = Modifier.width(50.dp))
                            Box(
                                modifier = Modifier.fillMaxHeight().width(40.dp),
                                contentAlignment = Alignment.CenterStart
                            )
                            {
                                Icon(
                                    Icons.Filled.ArrowForward,
                                    contentDescription = "Favorite",
                                    modifier = Modifier.size(ButtonDefaults.IconSize),
                                    tint = Color.White
                                )
                            }
                        }
                        Divider(color = Color.Black, thickness = 2.dp)
                    }
                }


                if (exit) {
                    AlertDialog(
                        onDismissRequest = { exit = false },
                        text = { Text("Confermi di voler effettuare il logout?") },
                        confirmButton = {
                            Button(
                                modifier = Modifier.bounceClick(),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = colorResource(id = R.color.green),
                                    contentColor = Color.Black
                                ),
                                onClick = {
                                    authentic.signOut()

                                    exit = false
                                    viewModel.user.value = null
                                    navController.navigate(Screen.LoginScreen.route)

                                    viewModel.currentUser.value = null
                                    viewModel.clearAvailable()
                                    viewModel.clearSellersSearch()
                                    viewModel.clearCart()
                                    viewModel.clearFavs()
                                    viewModel.clearNotAv()

                                    viewModel.currentDimension.value = ""
                                    viewModel.totalPrice.value = 0.0
                                    viewModel.currentShop.value = null
                                    viewModel.currentLocker.value = null
                                    viewModel.currentLockerSpace.value = null
                                    viewModel.currentDate.value = ""
                                    viewModel.currentTime.value = ""
                                    viewModel.currentTimeChoice.value = ""

                                    viewModel.changeChoice(0)

                                    viewModel.clearCart()
                                    viewModel.clearActualLockers()
                                }
                            ) {
                                Text("Si")
                            }
                        },
                        dismissButton = {
                            Button(
                                modifier = Modifier.bounceClick(),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = colorResource(id = R.color.green),
                                    contentColor = Color.Black
                                ),
                                onClick = { exit = false }
                            ) {
                                Text("No")
                            }
                        }
                    )
                }

            }
        }
    }
    }
}
