package it.polito.laib_3.registration

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick


//per scegliere il ruolo (cliente o commerciante) al momneto della registrazione
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectRoleScreen(navController: NavController, viewModel: PurchaseViewModel) {


    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.LoginScreen.route) }) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
           item{

            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(30.dp))
                Row() {
                    Text(
                        text = "BENVENUTO!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }
                Spacer(modifier = Modifier.height(35.dp))
                Row() {
                    Text(
                        text = "Vuoi usare GoodBuy come...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }

                Spacer(modifier = Modifier.height(50.dp))


                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(250.dp),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(2.dp, Color.Black),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                     //   shape = RoundedCornerShape(10.dp),
                        onClick = { navController.navigate(Screen.RegisterSellerScreen.route) },
                    ) {
                            Text(text = "Commerciante",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp)
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Icon(
                                Icons.Filled.ArrowForward,
                                contentDescription = "Favorite",
                                modifier = Modifier.size(ButtonDefaults.IconSize),
                                tint = Color.Black
                            )
                    }

                Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(250.dp),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(2.dp, Color.Black),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                        //   shape = RoundedCornerShape(10.dp),
                        onClick = { navController.navigate(Screen.RegisterUserScreen.route) },
                    ) {
                        Text(text = "Cliente  ",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp)
                        Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                        Icon(
                            Icons.Filled.ArrowForward,
                            contentDescription = "Favorite",
                            modifier = Modifier.size(ButtonDefaults.IconSize),
                            tint = Color.Black
                        )
                    }

                }
            }

            }
        }
    }
