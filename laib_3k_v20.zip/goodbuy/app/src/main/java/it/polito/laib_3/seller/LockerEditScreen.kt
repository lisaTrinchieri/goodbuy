package it.polito.laib_3.seller


import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.Seller
import it.polito.laib_3.bounceClick

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LockerEditScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage: StorageReference) {

    subscribeSeller(viewModel)

    var error by remember { mutableStateOf((false)) }
    var confirm by remember { mutableStateOf((false)) }

    var same by remember { mutableStateOf((false))}
    var count by remember { mutableStateOf((0))}

    var start by remember { mutableStateOf((true))}

    val initial = viewModel.currentSeller.value?.lockers

    if(start) {
        viewModel.lockersList.forEach() { lock ->

            var address = lock.spaces[0].address
            if (viewModel.currentSeller.value?.lockers?.contains(address) == true)
                if(!viewModel.lockersSelected.contains(lock))
                   viewModel.addLockersSelected(lock)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "I tuoi locker") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.SellerProfileScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
                actions = {
                    var count = 0
                    viewModel.deliveries.forEach(){del ->
                        if(del.status == "started" && del.id_mittente== viewModel.currentSeller.value?.name ?: "")
                            count++
                    }
                    if(count > 0)
                    {
                        BadgedBox(
                            modifier = Modifier
                                .wrapContentSize()
                                .padding(end = 20.dp),
                            badge = { Badge() { Text("$count") } })
                        {
                            /* IconButton(
                                 modifier = Modifier.wrapContentSize(),
                                 onClick = { navController.navigate(Screen.OrdersStartedScreen.route) }) { */
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                modifier = Modifier.clickable { navController.navigate(Screen.OrdersStartedScreen.route) },
                                tint = Color.White,)
                        }
                        // }
                    }
                    else
                    {
                        IconButton(onClick = { navController.navigate(Screen.OrdersStartedScreen.route) }) {
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                tint = Color.White,)
                        }
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { navController.navigate(Screen.RegisterProductScreen.route) })
                    { Icon(Icons.Filled.Add, contentDescription = "Localized description") }
                },
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {

                        IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerLockerScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.lock),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerOrdersScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.SellerProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },

        ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    //  horizontalAlignment = Alignment.CenterHorizontally
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {

                    /*Row() {
                        Text(
                            text = "I tuoi locker",
                            fontWeight = FontWeight.Bold,
                            fontSize = 25.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }
                    Spacer(modifier = Modifier.height(20.dp))
*/

///////////////////////////////////////////////////////////////////////////////////
                    Row() {
                        Text(
                            text = "Seleziona i locker in cui portare gli ordini: ",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }

                    Spacer(modifier = Modifier.height(5.dp))
                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                    Box()
                        {
                            Image(
                                painter = painterResource(id = R.drawable.mappa),
                                contentDescription = null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                            )

                            viewModel.lockersList.forEach() { lock ->


                                    IconToggleButton(
                                        checked =// if(started) viewModel.currentSeller.value?.lockers.contains(lock.spaces[0].address)
                                           // else
                                           viewModel.lockersSelected.contains(lock),
                                        onCheckedChange = { _checked ->

                                            if (_checked)
                                                viewModel.addLockersSelected(lock)
                                            else
                                                viewModel.removeLockersSelected(lock)

                                            start = false

                                        },
                                        modifier = Modifier.padding(top = lock.spaces[0].positionX.dp,start=lock.spaces[0].positionY.dp)
                                    ) {
                                        Icon(
                                        //    modifier = Modifier.padding(bottom = lock.spaces[0].positionX.dp, start=lock.spaces[0].positionY.dp),
                                            imageVector = Icons.Default.LocationOn,
                                            contentDescription = "Favorite Item",
                                            tint = if (viewModel.lockersSelected.contains(lock)) colorResource(id = R.color.green) else Color.DarkGray // icon color
                                        )
                                    }
                        }
                    }


                /*    viewModel.lockersList.forEach() { lock ->

                        Row()
                        {
                            IconToggleButton(
                                    checked = viewModel.lockersSelected.contains(lock),
                                    onCheckedChange = { _checked ->


                                        if (_checked)
                                            viewModel.addLockersSelected(lock)
                                        else
                                            viewModel.removeLockersSelected(lock)

                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "Favorite Item",
                                        tint = if (viewModel.lockersSelected.contains(lock)) Color.Red else Color.LightGray // icon color
                                    )
                                }
                            }
                        } */
                    }
                    //Spacer(modifier = Modifier.height(5.dp))

                if(!viewModel.lockersSelected.isEmpty()) {
                    Row(
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Locker selezionati:")
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))

                    viewModel.lockersSelected.forEach() { lock ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.fillMaxHeight().width(300.dp)
                            )
                            {
                                Text(
                                    modifier = Modifier.padding(horizontal = 16.dp),
                                    text = "${lock.spaces[0].address}",
                                    fontSize = 18.sp,
                                    textAlign = TextAlign.Start,
                                )
                            }
                            Spacer(modifier = Modifier.width(5.dp))
                            Box(
                                modifier = Modifier.fillMaxHeight().width(60.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = null,
                                    modifier = Modifier.clickable { viewModel.removeLockersSelected(lock) }
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row()
                    {
                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .wrapContentSize(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                            onClick = {

                                viewModel.lockersSelected.forEach() { lock ->
                                    if (viewModel.currentSeller.value?.lockers?.contains(lock.spaces[0].address) == true)
                                        same = true
                                    else {
                                        same = false
                                        count++
                                    }
                                }
                                val num = initial?.count { it == ',' }?.plus(1)

                                if (num == viewModel.lockersSelected.size) {
                                    same = true
                                } else
                                    count++


                                //  already = true
                                if (viewModel.lockersSelected.isEmpty())
                                    error = true


                                // if ((!same && !error) || (same && !error && count>0) || (!same && !error && count>0)) {
                                if (!error && count > 0) {
                                    val seller = viewModel.currentSeller.value
                                    var id = ""

                                    viewModel.sellersComplete.forEach() { s ->
                                        if (s.value == viewModel.currentSeller.value)
                                            id = s.key
                                    }

                                    var lockersString = ""
                                    viewModel.lockersSelected.forEach() { lock ->
                                        lockersString = lockersString + lock.spaces[0].address + ","
                                    }

                                    val newSeller = seller?.let {
                                        Seller(
                                            it.password,
                                            seller.name,
                                            seller.address,
                                            seller.category,
                                            seller.number,
                                            seller.email,
                                            seller.orari,
                                            lockersString.dropLast(1),
                                            seller.image
                                        )
                                    }

                                    db.child("sellers").child(id).setValue(newSeller)
                                    confirm = true
                                }
                            },
                            content = {
                                Text(
                                    text = "Conferma",
                                    fontSize = 16.sp
                                )
                            }
                        )




                        if (error) {
                            AlertDialog(
                                onDismissRequest = { error = false },
                                text = { Text("È necessario selezionare almeno un locker") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        onClick = { error = false }
                                    ) {
                                        Text("OK")
                                    }
                                }
                            )

                        }

                        if (confirm) {
                            AlertDialog(
                                onDismissRequest = { viewModel.confirm.value = false },
                                text = { Text("Aggiornamento avvenuto con successo") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        onClick = {
                                            navController.navigate(Screen.SellerSettingsScreen.route)
                                        }

                                    ) {
                                        Text("OK")
                                    }
                                }
                            )

                        }

                        if (same && count == 0) {
                            AlertDialog(
                                onDismissRequest = { same = false },
                                text = { Text("Non è stata effettuata nessuna modifica") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        onClick = { same = false }
                                    ) {
                                        Text("OK")
                                    }
                                }
                            )

                        }

                    }
                    }

                }
            }
        }
    }
