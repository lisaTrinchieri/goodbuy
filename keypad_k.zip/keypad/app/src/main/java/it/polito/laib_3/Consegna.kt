package it.polito.laib_3

data class Consegna(
  //  val id_cons: String, data dal db
    var status: String,
    val date_Start: String,
    var time_Start: String,
    var date_Update: String,
    var time_Update: String,
    var date_Due: String,
    var time_Due: String,
    val id_mittente:String,
    val id_destinatario:String,
    val locker : String,
    val locker_space: String,
    val code_inserimento: Int,
    val code_sblocco: Int,
    val products: String,
    //val products: Map<String,Int>,
    val price: Double,
    val payment:String,
    val rejected: String,

)

