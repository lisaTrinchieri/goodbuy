package it.polito.laib_3

data class Locker(
    val id_locker: String,
    var spaces : List<LockerSpace>
)

