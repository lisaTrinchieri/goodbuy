package it.polito.laib_3

import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModelProvider
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.common.api.Response
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.BuildConfig
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import it.polito.laib_3.screen.getLocker
import it.polito.laib_3.ui.theme.Laib_3Theme
import org.json.JSONObject


private lateinit var viewModel: PurchaseViewModel
private lateinit var  auth: FirebaseAuth
private lateinit var mAuthListener : FirebaseAuth.AuthStateListener
private lateinit var authAnon: FirebaseAuth


class MainActivity : ComponentActivity() {

    //message
    private val FCM_API = "https://fcm.googleapis.com/fcm/send"
    // private val serverKey= "key="+"AIzaSyBvX0MJi-JImQxITm42WaHHNABkqsbNRPw"
    private val serverKey = "key=" + "AAAAkCQ_oFM:APA91bFDL_42qFmg8TNgsbaTU1X52vpqGnsbvjvm_K8yApics8DB_okLoHIbDMgal_P4xdzx7dmHBD-1WmTKkgvIat7NSPDDbrNRVcL6NRwl7F3AXewhHYUjSHiVNUS5YxP-CjyphcO8"
    private val contentType = "application/json"
    private val requestQueue: RequestQueue by lazy { Volley.newRequestQueue(this.applicationContext) }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        viewModel = ViewModelProvider(this)[PurchaseViewModel::class.java]


       val db = Firebase.database.reference
        auth = FirebaseAuth.getInstance()


        var mediaPlayer = MediaPlayer()




        viewModel.loggedIn.value = false

        if(auth.currentUser?.email?.contains("lock1") == true)
        {    getLocker("locker1", db, viewModel)
            viewModel.loggedIn.value = true }

        if(auth.currentUser?.email?.contains("lock2") == true)
        {   getLocker("locker2", db, viewModel)
            viewModel.loggedIn.value = true
        }

        if(auth.currentUser?.email?.contains("lock3") == true)
        {   getLocker("lock3", db, viewModel)
            viewModel.loggedIn.value = true}

        setContent {
            Laib_3Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                   // Navigation(db)
                    mediaPlayer = MediaPlayer.create(LocalContext.current, R.raw.bleep)
                    Navigation(viewModel, db, auth, FCM_API, serverKey, contentType, requestQueue, mediaPlayer)

                }
            }
        }


    }
}

enum class ButtonState { Pressed, Idle }
fun Modifier.bounceClick() = composed {
    var buttonState by remember { mutableStateOf(ButtonState.Idle) }
    val scale by animateFloatAsState(if (buttonState == ButtonState.Pressed) 0.70f else 1f)

    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = {

            }
        )
        .pointerInput(buttonState) {
            awaitPointerEventScope {
                buttonState = if (buttonState == ButtonState.Pressed) {
                    waitForUpOrCancellation()
                    ButtonState.Idle
                } else {
                    awaitFirstDown(false)
                    ButtonState.Pressed
                }
            }
        }
}


fun sendNotification(notification: JSONObject, FCM_API:String , serverKey:String, contentType:String, requestQueue: RequestQueue) {
    Log.d("cccc", "sendNotification serverKey=[$serverKey]")
    val jsonObjectRequest = object : JsonObjectRequest(
        Method.POST, FCM_API, notification,
        com.android.volley.Response.Listener<JSONObject> { response ->
            Log.i("ccccc", "onResponse: $response")
            // msg.setText("")
        },
        com.android.volley.Response.ErrorListener {
            Log.i("TAG", "onErrorResponse: Didn't work [$it]")
        }) {

        override fun getHeaders(): Map<String, String> {
            Log.d("ccc", "getHeaders() invoked serverKey=[$serverKey]")
            val params = HashMap<String, String>()
            params["Authorization"] = serverKey
            params["Content-Type"] = contentType
            return params
        }
    }
    requestQueue.add(jsonObjectRequest)
}



