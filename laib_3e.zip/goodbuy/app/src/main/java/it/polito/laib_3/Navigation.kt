package it.polito.laib_3

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.MutableLiveData
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.android.volley.RequestQueue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.registration.EditProductScreen
import it.polito.laib_3.registration.RegisterProductScreen
import it.polito.laib_3.registration.RegisterSellerScreen
import it.polito.laib_3.registration.RegisterUserScreen
import it.polito.laib_3.registration.SelectRoleScreen
import it.polito.laib_3.registration.SplashScreen
import it.polito.laib_3.seller.HomeSellerScreen
import it.polito.laib_3.seller.OrderDetailSeller
import it.polito.laib_3.seller.OrdersStartedScreen
import it.polito.laib_3.seller.SellerLockerScreen
import it.polito.laib_3.seller.SellerOrdersScreen
import it.polito.laib_3.seller.SellerProductsScreen
import it.polito.laib_3.seller.SellerProfileScreen
import it.polito.laib_3.seller.SellerSettingsScreen
import it.polito.laib_3.user.CartScreen
import it.polito.laib_3.user.HomeUserScreen
import it.polito.laib_3.user.LockerPositionScreen
import it.polito.laib_3.user.OrderDetailUser
import it.polito.laib_3.user.OrdersUserScreen
import it.polito.laib_3.user.PaymentScreen
import it.polito.laib_3.user.ShopScreen
import it.polito.laib_3.user.UserFavouriteScreen
import it.polito.laib_3.user.UserProfileScreen
import it.polito.laib_3.user.UserSearchScreen
import it.polito.laib_3.user.UserSettingsScreen
import org.json.JSONException
import org.json.JSONObject


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun Navigation(viewModel: PurchaseViewModel, db: DatabaseReference, auth: FirebaseAuth, storage: StorageReference, FCM_API:String, serverKey:String, contentType:String, requestQueue: RequestQueue) {


    val valid by viewModel.valid.collectAsState()

    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = // Screen.HomeSellerScreen.route
                        // if(auth.currentUser?.email!="" )//&& viewModel.currentRole.value=="user")
                         //   Screen.HomeUserScreen.route
                                //  else if(auth.currentUser?.email!="" && viewModel.currentRole.value=="seller")
                        //     Screen.HomeSellerScreen.route
                      //   else
                           //  Screen.LoginScreen.route
                           Screen.SplashScreen.route
                       //   Screen.RegisterProductScreen.route
           ) {

        composable(Screen.SplashScreen.route) {
            SplashScreen(
                valid = valid,
               // onStart = viewModel::trackSplashScreenStarted,
                onSplashEndedValid = {
                 //   navController.navigate(Screen.RegisterProductScreen.route)
                   if(auth.currentUser?.email=="" )
                        navController.navigate(Screen.LoginScreen.route)
                    else {
                        if (viewModel.currentRole.value == "seller")
                           // navController.navigate(Screen.HomeSellerScreen.route)
                            navController.navigate(Screen.HomeSellerScreen.route)
                        else
                            navController.navigate(Screen.HomeUserScreen.route)
                    }
                },
              //  onSplashEndedInvalid = {}
            )
        }
        //REGISTRATION
        composable(Screen.LoginScreen.route) { LoginScreen(navController = navController, viewModel, auth, FCM_API, serverKey, contentType, requestQueue) }

       composable(Screen.SelectRoleScreen.route) { SelectRoleScreen(navController = navController, viewModel) }

       composable(Screen.RegisterUserScreen.route) { RegisterUserScreen(navController = navController, viewModel, db, auth, storage) }
       composable(Screen.RegisterSellerScreen.route) {RegisterSellerScreen(navController = navController, viewModel, db, auth, storage) }
       composable(Screen.RegisterProductScreen.route) { RegisterProductScreen(navController = navController, viewModel, db, auth, storage) }

        composable(Screen.EditProductScreen.route) { viewModel.currentProduct.value?.let { it1 ->
            EditProductScreen(navController = navController, viewModel, db, auth, storage,
                it1
            )
        } }


        //USER
        composable(Screen.HomeUserScreen.route) { HomeUserScreen(navController = navController, viewModel, db, auth, storage) }
        composable(Screen.ShopScreen.route) { viewModel.currentShop.value?.let { it1 ->
            ShopScreen(navController = navController, viewModel, db, auth,
                it1, storage
            )
        } }
        composable(Screen.CartScreen.route) { CartScreen(navController = navController, viewModel, db, auth, storage) }
        composable(Screen.LockerPositionScreen.route) { LockerPositionScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.PaymentScreen.route) { PaymentScreen(navController = navController, viewModel, db, auth) }
        //
       composable(Screen.UserSearchScreen.route) { UserSearchScreen(navController = navController, viewModel, db, auth) }
        //
       composable(Screen.OrdersUserScreen.route) { OrdersUserScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.OrderDetailUser.route) { viewModel.currentDelivery.value?.let { it1 ->
            OrderDetailUser(navController = navController, viewModel, db, auth,
                it1, storage
            )
        } }
        //
        composable(Screen.UserProfileScreen.route) { UserProfileScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.UserSettingsScreen.route) { UserSettingsScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.UserFavouriteScreen.route) { UserFavouriteScreen(navController = navController, viewModel, db, auth, storage) }

        //SELLER
        composable(Screen.HomeSellerScreen.route) { HomeSellerScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.OrderDetailSeller.route) { viewModel.currentDelivery.value?.let { it1 ->
            OrderDetailSeller(navController = navController, viewModel, db, auth,
                it1
            )
        } }
        composable(Screen.OrdersStartedScreen.route) { OrdersStartedScreen(navController = navController, viewModel, db, auth) }


        composable(Screen.SellerLockerScreen.route) { SellerLockerScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.SellerOrdersScreen.route) { SellerOrdersScreen(navController = navController, viewModel, db, auth) }

        composable(Screen.SellerProfileScreen.route) { SellerProfileScreen(navController = navController, viewModel, db, auth, storage) }
        composable(Screen.SellerSettingsScreen.route) { SellerSettingsScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.SellerProductsScreen.route) { SellerProductsScreen(navController = navController, viewModel, db, auth, storage) }

    }

}

//per autneticazione in anonimo
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StartScreen(navController: NavController, viewModel: PurchaseViewModel, authAnon: FirebaseAuth) {


    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Locker manager",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )

        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(150.dp))
                Row() {
                    Text(
                        text = "Benvenuto!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }

                Spacer(modifier = Modifier.height(40.dp))

                Button(
                    modifier = Modifier
                        .bounceClick()
                        .height(45.dp)
                        .width(120.dp),
                    shape = RoundedCornerShape(20.dp),
                    onClick = {

                        authAnon.signInAnonymously()
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d("aaa", "FIREBASEAUTH sign InAnonymously:success")
                               //     navController.navigate(Screen.SelectScreen.route)
                                    val user = authAnon.currentUser?.uid
                                    viewModel.userUid.value = user

                                    Log.d("aaa", "FIREBASEAUTH sign InAnonymously USER "+viewModel.userUid.value)
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.d("aaa", " FUREBASEAUTH signInAnonymously:failure", task.exception)

                                }
                            }

                    },
                    content = { Text( text="Entra",
                        fontSize = 16.sp ) }
                )
            }
        }
    }
}

//per autenticazione con username e password
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController, viewModel: PurchaseViewModel, authentic :FirebaseAuth, FCM_API:String, serverKey:String, contentType:String, requestQueue: RequestQueue) {

    Log.d("aaaa", "currentuseremail login: "+ (viewModel.currentRole.value))
    var username by remember {
        mutableStateOf((""))
    }

    var pwd by remember {
        mutableStateOf((""))
    }
    var error by remember {
        mutableStateOf((false))
    }

    var auth by remember {
        mutableStateOf((false))
    }



    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Locker manager",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )

        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(70.dp))
                    Row() {
                        Text(
                        text = "Login",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }
                    Spacer(modifier = Modifier.height(20.dp))
                    OutlinedTextField(
                        value = username,
                        onValueChange = { newText ->
                            username = newText
                        },
                        label = {
                            Text(text = "Email")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    OutlinedTextField(
                        value = pwd,
                        onValueChange = { newText ->
                            pwd = newText
                        },
                        label = {
                            Text(text = "Password")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(120.dp),
                        shape = RoundedCornerShape(20.dp),
                        onClick = {

                            if (username != "" && pwd != "") {

                                authentic.signInWithEmailAndPassword(username, pwd)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {

                                            var role = ""

                                            viewModel.users.forEach(){item->
                                                if(item.email==username && item.password==pwd)
                                                {   role = "user"
                                                    viewModel.currentUser.value = item
                                                    viewModel.currentRole.value = "user"
                                                }
                                            }

                                            viewModel.sellers.forEach(){item->
                                                if(item.email==username && item.password==pwd)
                                                {    role = "seller"
                                                     viewModel.currentSeller.value = item
                                                     viewModel.currentRole.value = "seller"
                                                }
                                            }

                                            if(role=="seller")
                                               navController.navigate(Screen.HomeSellerScreen.route)
                                            else
                                                navController.navigate(Screen.HomeUserScreen.route)

                                            viewModel.user = MutableLiveData(authentic.currentUser)
                                            viewModel.userKey.value = username

                                            Log.w("Login", "username "+viewModel.userKey.value)
                                            val user = authentic.currentUser

                                        } else {
                                            Log.w("Login", "signInWithEmail:failure", task.exception)
                                            error = true
                                        }
                                    }
                            } else {
                                error = true
                            }
                        },
                        content = { Text( text="Login",
                                          fontSize = 16.sp ) }
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    ClickableText(
                        text = AnnotatedString("Registrati"),

                        onClick = {
                         //  FirebaseMessaging.getInstance().subscribeToTopic("/topics/Enter_your_topic_name")

                                    val topic = "/topics/weather" //topic has to match what the receiver subscribed to

                                    val notification = JSONObject()
                                    val notifcationBody = JSONObject()

                                    try {
                                        notifcationBody.put("title", "Goodbuy")
                                        notifcationBody.put("message", "ciao")   //Enter your notification message
                                        notification.put("to", topic)
                                        notification.put("data", notifcationBody)
                                        Log.e("ccccccccc", "try")
                                    } catch (e: JSONException) {
                                        Log.e("ccccccc", "onCreate: " + e.message)
                                    }

                                    sendNotification(notification,FCM_API, contentType, serverKey, requestQueue)




                            navController.navigate(Screen.SelectRoleScreen.route)

                            //navController.navigate(Screen.RegisterSellerScreen.route)

                       /*     viewModel.users.forEach(){u->
                                Log.d("aaaa", "FirebaseUtenti : "+ u)

                            }
                            viewModel.sellers.forEach(){s->
                                Log.d("aaaa", "FirebaseUtentiSell : "+ s)

                            }
                            viewModel.products.forEach(){p->
                                Log.d("aaaa", "FirebaseUtentiProd : "+ p)

                            }  */

                     /*      Log.d("aaaa", "FirebaseUtentifavs size at  pt1 "+ viewModel.favsComplete.get("user1"))
                            Log.d("aaaa", "FirebaseUtentifavs numero "+viewModel.favsComplete.keys.size)
                            viewModel.favsComplete.forEach(){f->

                                Log.d("aaaa", "FirebaseUtentifavs keys "+ f.key)
                                Log.d("aaaa", "FirebaseUtentifavs size values "+ f.value.size)

                                f.value.forEach() {v->
                                    Log.d("aaaa", "FirebaseUtentifavs values "+ v)
                                }

                              //  var shops = viewModel.favsComplete[f]


                        /*      if (shops != null) {
                                    shops.forEach(){s->
                                        Log.d("aaaa", "FirebaseUtentifavs "+f+": "+s)
                                    }
                                } */

                            } */
                        } ,

                    )

                    if (error) {
                            AlertDialog(
                                onDismissRequest = { error = false },
                                text = { Text("Errore username e/o password") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        onClick = {
                                            error = false
                                            username = ""
                                            pwd = ""
                                        }
                                    ) {
                                        Text("OK")
                                    }
                                }
                            )

                    }
                }
            }
        }
    }













