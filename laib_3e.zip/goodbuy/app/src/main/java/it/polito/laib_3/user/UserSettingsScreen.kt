package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.User
import it.polito.laib_3.bounceClick


@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSettingsScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    var exit by remember { mutableStateOf((false)) }
    var changeP by remember { mutableStateOf((false)) }
    var changeN by remember { mutableStateOf((false)) }

    var tel by remember { mutableStateOf(("")) }
    var pwd by remember { mutableStateOf(("")) }

    var correct by remember { mutableStateOf((false)) }


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Impostazioni profilo") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Icon(Icons.Filled.Home, contentDescription = "Localized description")
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.UserSearchScreen.route) }) {
                            Icon(

                                Icons.Filled.Search,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(
                            onClick = { navController.navigate(Screen.OrdersUserScreen.route) }
                        ) {
                            Icon(
                                Icons.Filled.List,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Icon(
                                Icons.Filled.Person,
                                contentDescription = "Localized description",
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        //.padding(16.dp)
                        .fillMaxWidth(),
                //    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Divider(color = Color.DarkGray, thickness = 2.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        Text(
                            text = "${viewModel.currentUser.value?.username}",
                            fontSize = 18.sp,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.padding(horizontal=16.dp)
                        )
                    }
                    Divider(color = Color.DarkGray, thickness = 2.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        Text(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            text = "${viewModel.currentUser.value?.email}",
                            fontSize = 18.sp,
                            textAlign = TextAlign.Start,
                        )
                    }

                    Divider(color = Color.DarkGray, thickness = 2.dp)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        Text(
                            text = "Modifica numero di telefono",
                            fontSize = 18.sp,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.padding(horizontal=16.dp)
                        )
                        val arrowIcon =
                            if (changeN) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown
                        Icon(
                            imageVector = arrowIcon,
                            contentDescription = null,
                            modifier = Modifier.clickable { changeN = !changeN }
                        )

                    }
                    AnimatedVisibility(
                        visible = changeN,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            //    horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically

                            ) {
                                Text(
                                    text = "Inserisci nuovo numero di telefono: ",
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Start,
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                OutlinedTextField(
                                    value = tel,
                                    onValueChange = { newText ->
                                        tel = newText
                                    },
                                    placeholder = {
                                        Text(text = "Es. 011145678")
                                    },
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Phone,
                                        imeAction = ImeAction.Done
                                    ),
                                )

                            }
                            Spacer(modifier = Modifier.height(7.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                OutlinedButton(
                                    modifier = Modifier.wrapContentSize(),
                                    onClick = {

                                        if(tel!="")
                                        {
                                            val user = viewModel.currentUser.value
                                            var id = ""

                                            viewModel.usersComplete.forEach() { u ->
                                                if (u.value == viewModel.currentUser.value)
                                                    id = u.key
                                            }

                                            val newUser = user?.let {
                                                User(
                                                    user.username,
                                                    it.password,
                                                    user.email,
                                                    tel
                                                )
                                            }

                                            db.child("users").child(id).setValue(newUser)
                                            correct = true
                                        }

                                        tel = ""
                                    },
                                    shape = RectangleShape,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = Color.Transparent,
                                        contentColor = Color.Black
                                    ),
                                ) {

                                    Text(
                                        text = "Conferma",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Start,
                                    )
                                }
                            }

                        }
                    }
                    }
                    Divider(color = Color.DarkGray, thickness = 2.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        Text(
                            text = "Modifica password",
                            fontSize = 18.sp,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.padding(horizontal=16.dp)
                        )

                        val arrowIcon =
                            if (changeP) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown
                        Icon(
                            imageVector = arrowIcon,
                            contentDescription = null,
                            modifier = Modifier.clickable { changeP = !changeP }
                        )

                    }
                    AnimatedVisibility(
                        visible = changeP,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            //    horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Inserisci nuova password: ",
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Start,
                                )
                            }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Start,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {

                                OutlinedTextField(
                                    value = pwd,
                                    onValueChange = { newText ->
                                        pwd = newText
                                    },
                                    placeholder = {
                                        Text(text = "")
                                    },
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Password,
                                        imeAction = ImeAction.Done
                                    ),
                                )

                            }
                            Spacer(modifier = Modifier.height(7.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                OutlinedButton(
                                    modifier = Modifier.wrapContentSize(),
                                    onClick = {
                                        if(pwd!="") {
                                            val user = viewModel.currentUser.value
                                            var id = ""

                                            viewModel.usersComplete.forEach() { u ->
                                                if (u.value == viewModel.currentUser.value)
                                                    id = u.key
                                            }

                                            val newUser = user?.let {
                                                User(
                                                    user.username,
                                                    pwd,
                                                    user.email,
                                                    it.number
                                                )
                                            }


                                          //  db.child("users").child(id).setValue(newUser)
                                        /*    authentic.currentUser?.updatePassword(pwd)
                                                ?.addOnCompleteListener { task ->

                                                    if (task.isSuccessful) {
                                                        Log.d("aaa", "FIREbase update success")
                                                        db.child("users").child(id).setValue(newUser)
                                                    } else {


                                                    }
                                                }  */
                                            val credential =
                                                viewModel.currentUser.value?.let {
                                                    EmailAuthProvider.getCredential(
                                                        it.email, viewModel.currentUser.value!!.password)
                                                }
                                            if (credential != null) {
                                                authentic.currentUser?.reauthenticate(credential)?.addOnCompleteListener(){ task->
                                                        if (task.isSuccessful) {
                                                            authentic.currentUser?.updatePassword(pwd)
                                                                ?.addOnCompleteListener { task ->
                                                                    Log.d("aaa", "FIREbase reath success success")

                                                                    if (task.isSuccessful) {
                                                                        Log.d("aaa", "FIREbase update success")
                                                                        db.child("users").child(id).setValue(newUser)
                                                                        correct = true
                                                                    } else {
                                                                        Log.d("aaa", "FIREbase password update NOT success")
                                                                    }
                                                                }
                                                        }
                                                        else {

                                                            Log.d("aaa", "FIREbase reauth update NOT success")
                                                        }

                                                    }
                                            }
                                        }
                                              },
                                    shape = RectangleShape,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = Color.Transparent,
                                        contentColor = Color.Black
                                    ),
                                ) {

                                    Text(
                                        text = "Conferma",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Start,
                                    )
                                }
                            }

                        }
                    }
                    Divider(color = Color.DarkGray, thickness = 2.dp)

                }




            }
        }

    if (correct) {
        AlertDialog(
            onDismissRequest = { correct = false },
            text = { Text("Aggiornamento avvenuto correttamente") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = { correct = false }
                ) {
                    Text("OK")
                }
            }
        )

    }
    }
