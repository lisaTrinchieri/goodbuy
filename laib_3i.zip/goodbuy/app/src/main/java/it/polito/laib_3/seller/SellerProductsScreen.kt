package it.polito.laib_3.seller


import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SellerProductsScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage: StorageReference) {

    var context = LocalContext.current

    viewModel.products.forEach(){prod->
        if(prod.shop== viewModel.currentSeller.value?.name ?: "") {
            if (!viewModel.currentProducts.contains(prod)) {
                viewModel.addCurrentProd(prod)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {  },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
                actions = {
                    var count = 0
                    viewModel.deliveries.forEach(){del ->
                        if(del.status == "started")
                            count++
                    }
                    if(count > 0)
                    {
                        BadgedBox(
                            modifier = Modifier
                                .wrapContentSize()
                                .padding(end = 20.dp),
                            badge = { Badge() { Text("$count") } })
                        {
                            /* IconButton(
                                 modifier = Modifier.wrapContentSize(),
                                 onClick = { navController.navigate(Screen.OrdersStartedScreen.route) }) { */
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                modifier = Modifier.clickable { navController.navigate(Screen.OrdersStartedScreen.route) },
                                tint = Color.White,)
                        }
                        // }
                    }
                    else
                    {
                        IconButton(onClick = { navController.navigate(Screen.OrdersStartedScreen.route) }) {
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                tint = Color.White,)
                        }
                    }
                },

                )
        },
        bottomBar = {
            BottomAppBar(
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { navController.navigate(Screen.RegisterProductScreen.route) })
                       { Icon(Icons.Filled.Add, contentDescription = "Localized description") }
                },
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {

                        IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerLockerScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.lock),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerOrdersScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.SellerProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            //  item {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${viewModel.currentProducts.size} articoli",
                        fontWeight = FontWeight.Bold,
                        fontSize = 25.sp,
                    )

                }

                Spacer(modifier = Modifier.height(10.dp))

                SmallFloatingActionButton(
                    onClick = {  navController.navigate(Screen.RegisterProductScreen.route) },
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.secondary
                ) {
                    Icon(Icons.Filled.Add, "Small floating action button.")
                }

                LazyVerticalGrid(
                    modifier = Modifier.fillMaxSize(),
                    columns = GridCells.Fixed(count = 2)
                ) {
                    items(count = viewModel.currentProducts.size) { index ->



                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(190.dp)
                                    .wrapContentSize(Alignment.TopStart)
                                    .padding(bottom = 15.dp)
                            ) {

                                Column() {
                                    OutlinedCard(
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.surface,
                                        ),

                                        border = BorderStroke(1.dp, Color.Black),
                                        modifier = Modifier
                                            .size(width = 165.dp, height = 140.dp)

                                    ) {
                                        Column {
                                            Box()
                                            {

                                                val bitmap =
                                                    remember { mutableStateOf<Bitmap?>(null) }
                                                val image = viewModel.currentProducts[index].image
                                                storage.child("images/$image")
                                                    .getBytes(Long.MAX_VALUE)
                                                    .addOnSuccessListener { bytes ->

                                                        bitmap.value =
                                                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

                                                    }.addOnFailureListener {}

                                                bitmap?.value.let { btm ->
                                                    if (btm != null) {
                                                        Image(
                                                            bitmap = btm.asImageBitmap(),
                                                            contentDescription = null,
                                                            modifier = Modifier
                                                                .width(width = 250.dp)
                                                                .clip(
                                                                    shape = RoundedCornerShape(
                                                                        size = 12.dp
                                                                    )
                                                                ),
                                                            contentScale = ContentScale.Crop
                                                        )
                                                    }
                                                    else
                                                    {
                                                        val view = remember { ImageView(context) }

                                                        // Load Gif with Glide library
                                                        DisposableEffect(context) {
                                                            Glide.with(context)
                                                                .asGif()
                                                                .load("https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif")
                                                                .into(view)
                                                            onDispose {
                                                                // Cleanup when the composable is disposed
                                                                Glide.with(context).clear(view)
                                                            }
                                                        }
                                                        AndroidView(factory = { view })

                                                    }
                                                }

                                                IconButton(
                                                    modifier = Modifier.padding(start = 110.dp, bottom=60.dp),
                                                    onClick = {
                                                        viewModel.currentProduct.value = viewModel.currentProducts[index]
                                                        navController.navigate(Screen.EditProductScreen.route)
                                                    },
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Create,
                                                        contentDescription = "Favorite Item",
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "" + viewModel.currentProducts[index].price + " €",
                                        fontSize = 13.sp,
                                        color = Color.Black
                                    )
                                    Text(
                                        text = "" + viewModel.currentProducts[index].name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black
                                    )
                                    Text(
                                        text = "" + viewModel.currentProducts[index].quantity + " " + viewModel.currentProducts[index].unit,
                                        fontSize = 13.sp,
                                        color = Color.Black
                                    )


                                }
                            }


                    }
                }

            }
        }


    }
}