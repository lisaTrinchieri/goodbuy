package it.polito.laib_3

data class User(

   // val name: String,
    //val surname: String,
    val username: String,
    val password: String,
    val email: String,
    val number: String,
    val credito: String,
  //  val image: String
  //  val favourites: List<String>,

)
