package it.polito.laib_3.user

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SearchBar
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.Product
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.Seller

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "SuspiciousIndentation")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSearchScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    val configuration = LocalConfiguration.current

    val screenHeight = configuration.screenHeightDp.dp
    val screenWidth = configuration.screenWidthDp.dp

    //Collecting states from ViewModel
   // val searchText by viewModel.searchText.collectAsState()
    val searchText by viewModel.searchTextStateFlow.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    //val sellersList by viewModel.sellersList.collectAsState()

    val searchResultsSellers by viewModel.searchResultsSellers.collectAsStateWithLifecycle()
    val searchResultsProds by viewModel.searchResultsProducts.collectAsStateWithLifecycle()

    var isSellers by remember { mutableStateOf((true)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text="") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Icon(Icons.Filled.Home, contentDescription = "Localized description")
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Icon(

                                Icons.Filled.Search,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Icon(
                                Icons.Filled.List,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Icon(
                                Icons.Filled.Person,
                                contentDescription = "Localized description",
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            SearchBar(
                query = searchText,//text showed on SearchBar
                onQueryChange = viewModel::setSearchText, //onSearchTextChange, //update the value of searchText
                onSearch = viewModel::setSearchText, //onSearchTextChange, //the callback to be invoked when the input service triggers the ImeAction.Search action
                active = isSearching, //whether the user is searching or not
                onActiveChange = { viewModel.onToogleSearch() }, //the callback to be invoked when this search bar's active state is changed
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = {
                    Text(text = "inizia ricerca")
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        tint = MaterialTheme.colorScheme.onSurface,
                        contentDescription = null
                    )
                },
             /*   trailingIcon = {
                    if(isSearching) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            modifier = Modifier.clickable { viewModel.onResetSearch()
                                 },
                            tint = MaterialTheme.colorScheme.onSurface,
                            contentDescription = null
                        )
                    }
                },  */
                trailingIcon = {
                    if (searchText.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchText("")
                                                viewModel.onResetSearch()}) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                tint = MaterialTheme.colorScheme.onSurface,
                                contentDescription = "Clear search"
                            )
                        }
                    }
                },
                content = {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(32.dp),
                        contentPadding = PaddingValues(16.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(
                            count = if(isSellers) searchResultsSellers.size else searchResultsProds.size,
                            key = { index -> if(isSellers) searchResultsSellers[index].name else searchResultsProds[index].name },
                            itemContent = { index ->

                                var sell = Seller("","","","","","", "","")
                                var prod = Product("","",0,"","","","", false, false, "")

                                if(isSellers)
                                   sell = searchResultsSellers[index]
                                else
                                    prod= searchResultsProds[index]

                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable {
                                            viewModel.currentShop.value = sell
                                            if(isSellers) navController.navigate(Screen.ShopScreen.route) }
                                        .height(30.dp)
                                ) {

                                        Text(
                                            text = if(isSellers) sell.name else prod.name,
                                            fontSize = 15.sp,
                                        )
                                    }


                            }
                        )
                    }
                },
              )

            Spacer(modifier = Modifier.height(5.dp))

            Row(){


                Button(
                    modifier = Modifier
                        .height(60.dp)
                        .width(screenWidth/2)
                        .drawBehind {

                            var strokeWidth = 0.0

                            if (isSellers)
                                strokeWidth = 3.dp.toPx().toDouble()
                            else
                                strokeWidth = 1.dp.toPx().toDouble()


                                drawLine(
                                    color = Color.DarkGray,
                                    start = Offset(0f, size.height),
                                    end = Offset(size.width, size.height),
                                    strokeWidth = strokeWidth.toFloat()
                                )

                        }
                            .padding(vertical = 10.dp) ,
                    shape = RectangleShape,
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                    //   shape = RoundedCornerShape(10.dp),
                    onClick = { isSellers=true },
                ) {
                    Text(text = "Attività",
                        fontWeight = if(isSellers)FontWeight.Bold else FontWeight.Normal,
                        fontSize = 15.sp)
                }


                Button(
                    modifier = Modifier
                        .height(60.dp)
                        .width(screenWidth/2)
                        .drawBehind {

                            var strokeWidth = 0.0

                            if (!isSellers)
                                strokeWidth = 3.dp.toPx().toDouble()
                            else
                                strokeWidth = 1.dp.toPx().toDouble()


                            drawLine(
                                color = Color.DarkGray,
                                start = Offset(0f, size.height),
                                end = Offset(size.width, size.height),
                                strokeWidth = strokeWidth.toFloat()
                            )

                        }
                        .padding(vertical = 10.dp) ,
                    shape = RectangleShape,
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                    //   shape = RoundedCornerShape(10.dp),
                    onClick = { isSellers=false },
                ) {
                    Text(text = "Prodotti",
                        fontWeight = if(!isSellers)FontWeight.Bold else FontWeight.Normal,
                        fontSize = 15.sp)
                }

            }


        }

    }
    }




