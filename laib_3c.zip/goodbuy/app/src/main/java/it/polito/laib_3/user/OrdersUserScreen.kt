package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.formatCurrency

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersUserScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    val configuration = LocalConfiguration.current

    var isExpanded by remember { mutableStateOf((false)) }
    var status by remember { mutableStateOf(("")) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Icon(Icons.Filled.Home, contentDescription = "Localized description")
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserSearchScreen.route) }) {
                            Icon(
                                Icons.Filled.Search,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.OrdersUserScreen.route) }) {
                            Icon(
                                Icons.Filled.List,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Icon(
                                Icons.Filled.Person,
                                contentDescription = "Localized description",
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(7.dp))
                //  item {
                Row() {
                    //   Divider(color = Color.DarkGray, thickness = 2.dp)

                    Box(
                        modifier = Modifier.fillMaxWidth()
                            .wrapContentSize(Alignment.TopEnd)
                            .padding(end=200.dp)
                    ) {
                        OutlinedButton(onClick = { isExpanded = !isExpanded }) {
                            Text(
                                text = "Filtra per",
                                fontSize = 15.sp,
                            )
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = "More"
                            )
                        }

                        DropdownMenu(
                            expanded = isExpanded,
                            onDismissRequest = { isExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("In corso") },
                                onClick = { status = "inProgress" }
                            )
                            DropdownMenuItem(
                                text = { Text("Terminate") },
                                onClick = { status = "ended" }
                            )
                            DropdownMenuItem(
                                text = { Text("Future") },
                                onClick = { status = "started" }
                            )
                            //     }

                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {

                    viewModel.deliveries.forEach() { del ->

                        if (status=="" || del.status == status) {
                            Row() {

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                    ),
                                    modifier = Modifier
                                        .size(width = 330.dp, height = 100.dp),
                                    onClick = {
                                        navController.navigate(Screen.OrderDetailUser.route)
                                        viewModel.currentDelivery.value = del
                                    }
                                ) {
                                    Row()
                                    {
                                        Box(
                                            modifier = Modifier.fillMaxHeight()
                                                .width(100.dp)
                                                .wrapContentSize(Alignment.TopStart)
                                        ) {
                                            if(del.status=="started") {
                                                Image(
                                                    painter = painterResource(id = R.drawable.busta_della_spesa),
                                                    contentDescription = "confermato",
                                                    colorFilter = ColorFilter.tint(Color.Black),
                                                    modifier = Modifier.size(30.dp)
                                                )
                                            }

                                            if(del.status=="inProgress") {
                                                Image(
                                                    painter = painterResource(id = R.drawable.clock),
                                                    contentDescription = "confermato",
                                                    colorFilter = ColorFilter.tint(Color.Black),
                                                    modifier = Modifier.size(30.dp)
                                                )
                                            }
                                            if(del.status=="ended") {
                                                Image(
                                                    painter = painterResource(id = R.drawable.check),
                                                    contentDescription = "confermato",
                                                    colorFilter = ColorFilter.tint(Color.Black),
                                                    modifier = Modifier.size(30.dp)
                                                )
                                            }
                                        }

                                        Box(
                                            modifier = Modifier.fillMaxHeight()
                                                .width(160.dp)
                                                .wrapContentSize(Alignment.TopStart)
                                        ) {
                                            Column() {

                                                Text(
                                                    text = "" + del.id_mittente,
                                                    textAlign = TextAlign.Left,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Black
                                                )

                                         /*       val prods: Map<String, Int> = del.products.split(',')
                                                    .map { it.split(':') }
                                                    .associate { it[0] to it[1].toInt() }

                                             //   val prods = del.products
                                                prods.keys.forEach() { prod ->
                                                    Text(
                                                        text = "" + prods.getValue(prod) + "x " + prod,
                                                        textAlign = TextAlign.Left,
                                                        fontSize = 13.sp,
                                                        color = Color.Black
                                                    )

                                                } */

                                                Text(
                                                    text = "" + del.status,
                                                    textAlign = TextAlign.Left,
                                                    fontSize = 13.sp,
                                                    color = Color.Black
                                                )
                                            }

                                        }
                                        Box(
                                            modifier = Modifier.fillMaxHeight()
                                                .width(70.dp)
                                                .wrapContentSize(Alignment.TopEnd)
                                        ) {
                                            Text(
                                                text = "" + formatCurrency(del.price)+" €",
                                                modifier = Modifier
                                                    .padding(16.dp),
                                                textAlign = TextAlign.End,
                                            )
                                        }
                                    }
                                }


                            }


                            //     }

                        }
                    }
                }
            }
        }
    }
}



