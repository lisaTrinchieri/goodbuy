package it.polito.laib_3

sealed class Screen(val route: String) {

    object SplashScreen : Screen("splash_screen")

    object LoginScreen : Screen("login_screen")
  //  object StartScreen : Screen("start_screen")

    //REGISTRATION
    object SelectRoleScreen : Screen("selectRole_screen")

    object RegisterUserScreen : Screen("registerUser_screen")
    object RegisterSellerScreen : Screen("registerSeller_screen")
    object RegisterProductScreen : Screen("registerProduct_screen")

    //USER
    object HomeUserScreen : Screen("homeUser_screen")
    object ShopScreen : Screen("shop_screen")
    object CartScreen : Screen("cart_screen")
    object LockerPositionScreen : Screen("lockerPosition_screen")
    object PaymentScreen : Screen("payment_screen")

    //
    object UserSearchScreen : Screen("searchUser_screen")

    //
    object OrdersUserScreen : Screen("ordersUser_screen")
    object OrderDetailUser : Screen("orderDetailUser_screen")

    //
    object UserProfileScreen : Screen("userProfile_screen")
    object UserSettingsScreen : Screen("userSettings_screen")
    object UserFavouriteScreen : Screen("userFavourite_screen")


    //SELLERRRRRR
    object HomeSellerScreen : Screen("homeSeller_screen")
    object OrderDetailSeller : Screen("orderDetailSeller_screen")
    object OrdersStartedScreen : Screen("ordersStarted_screen")

    object SellerLockerScreen : Screen("sellerLocker_screen")
    object SellerOrdersScreen : Screen("sellerOrders_screen")

    object SellerProfileScreen : Screen("sellerProfile_screen")
    object SellerSettingsScreen : Screen("sellerSettings_screen")



}
