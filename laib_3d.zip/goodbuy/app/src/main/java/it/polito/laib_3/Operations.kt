package it.polito.laib_3

data class Operations (

    val consegne : List<Consegna>,
   // val ritiri : List<Ritiro>
)

