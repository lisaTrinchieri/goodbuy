package it.polito.laib_3

data class Product(

    val shop:String,
    val name:String,
    val quantity: Int,
    val dimension: String,
    val unit: String,
    val price: String,
   // val ingredients: List<String>,
    val ingredients: String,
    val vegan:Boolean,
    val glutenFree:Boolean,
    val image:String,
)
