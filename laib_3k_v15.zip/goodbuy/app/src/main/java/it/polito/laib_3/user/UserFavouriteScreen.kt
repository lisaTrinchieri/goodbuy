package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.Seller

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserFavouriteScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage: StorageReference) {

    var context = LocalContext.current
    val changed by viewModel.changed.collectAsState()

    getFavsDb(db, viewModel)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "I tuoi preferiti") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(  modifier = Modifier.fillMaxWidth()
                        .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),)
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
            Column(
                modifier = Modifier
                    .padding(innerPadding),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                //  item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    /*Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "I tuoi preferiti",
                        fontWeight = FontWeight.Bold,
                        fontSize = 25.sp,
                    )

                }

                Spacer(modifier = Modifier.height(10.dp))*/

                    if (viewModel.favs.isEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Non ci sono ancora negozi tra i tuoi preferiti.",
                                fontSize = 17.sp,
                            )

                        }
                    } else {
                        LazyVerticalGrid(
                            modifier = Modifier.fillMaxSize(),
                            columns = GridCells.Fixed(count = 2)
                        ) {

                            var ff: MutableList<Seller> = mutableStateListOf()

                            viewModel.sellers.forEach() { s->
                                if (viewModel.favs.contains(s.name))
                                    ff.add(s)
                            }

                            items(count = ff.size) { index ->

                             //   if (viewModel.favs.contains(viewModel.sellers[index].name)) {
                                    Box(
                                        modifier = Modifier.fillMaxHeight()
                                            .width(190.dp)
                                            .wrapContentSize(Alignment.TopStart)
                                            .padding(bottom = 15.dp)
                                    ) {

                                        Column() {
                                            OutlinedCard(
                                                colors = CardDefaults.cardColors(
                                                    containerColor = MaterialTheme.colorScheme.surface,
                                                ),

                                                border = BorderStroke(1.dp, Color.Black),
                                                modifier = Modifier
                                                    .size(width = 165.dp, height = 140.dp)
                                                    // .padding(16.dp)
                                                    .clickable(onClick = {
                                                        viewModel.currentShop.value = ff[index]
                                                         //   viewModel.sellers[index]
                                                        navController.navigate(Screen.ShopScreen.route)
                                                    })
                                            ) {
                                                Column {
                                                    Box()
                                                    {

                                                        val bitmap = remember { mutableStateOf<Bitmap?>(null) }
                                                        val image = ff[index].image//viewModel.sellers[index].image
                                                        storage.child("images/$image")
                                                            .getBytes(Long.MAX_VALUE)
                                                            .addOnSuccessListener { bytes ->

                                                                bitmap.value =
                                                                    BitmapFactory.decodeByteArray(
                                                                        bytes,
                                                                        0,
                                                                        bytes.size
                                                                    )

                                                            }.addOnFailureListener {}

                                                        if(changed)
                                                        {
                                                            val view = remember { ImageView(context) }

                                                            DisposableEffect(context) {
                                                                Glide.with(context)
                                                                    .asGif()
                                                                    .load("https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif")
                                                                    .into(view)
                                                                onDispose {
                                                                    Glide.with(context).clear(view)
                                                                }
                                                            }
                                                        }
                                                        else {
                                                            bitmap?.value.let { btm ->
                                                                if (btm != null) {
                                                                    Image(
                                                                        bitmap = btm.asImageBitmap(),
                                                                        contentDescription = null,
                                                                        modifier = Modifier
                                                                            .width(width = 250.dp)
                                                                            .clip(
                                                                                shape = RoundedCornerShape(
                                                                                    size = 12.dp
                                                                                )
                                                                            ),
                                                                        contentScale = ContentScale.Crop
                                                                    )
                                                                } else {
                                                                    val view =
                                                                        remember { ImageView(context) }

                                                                    // Load Gif with Glide library
                                                                    DisposableEffect(context) {
                                                                        Glide.with(context)
                                                                            .asGif()
                                                                            .load("https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif")
                                                                            .into(view)
                                                                        onDispose {
                                                                            // Cleanup when the composable is disposed
                                                                            Glide.with(context)
                                                                                .clear(view)
                                                                        }
                                                                    }
                                                                    AndroidView(factory = { view })
                                                                }
                                                            }
                                                        }

                                                        Text(
                                                            modifier = Modifier.padding(
                                                                start = 6.dp,
                                                                top = 70.dp,
                                                                bottom = 10.dp
                                                            ),
                                                            text = "" +ff[index].category,
                                                                //    viewModel.sellers[index].category,
                                                            fontSize = 16.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.Black
                                                        )
                                                        IconToggleButton(
                                                            modifier = Modifier.padding(start = 110.dp),
                                                            checked = viewModel.favs.contains(
                                                                ff[index].name
                                                               // viewModel.sellers[index].name
                                                            ),
                                                            onCheckedChange = { _checked ->

                                                                if (_checked) {
                                                                    viewModel.addFav(  ff[index].name
                                                                      //  viewModel.sellers[index].name
                                                                    )
                                                                    db.child("favourites").child(
                                                                        "" + (viewModel.currentUser.value?.username
                                                                            ?: ""))
                                                                        .child( ff[index].name
                                                                            //viewModel.sellers[index].name
                                                                            ).setValue(  ff[index].name
                                                                          //  viewModel.sellers[index].name
                                                                        )

                                                                } else {
                                                                    viewModel.removeFav(  ff[index].name
                                                                        //viewModel.sellers[index].name
                                                                        )
                                                                    viewModel.changed.value=true
                                                                    viewModel.startChange()

                                                                    Toast.makeText(context, "'"+ff[index].name+"' rimosso dai preferiti",
                                                                        Toast.LENGTH_SHORT
                                                                    ).show()

                                                                    // db.child("favourites").child("user1").removeValue(shop.name)
                                                                    db.getRef().child("favourites").child(
                                                                            "" + (viewModel.currentUser.value?.username
                                                                                ?: "")).removeValue()
                                                                    viewModel.favs.forEach() { f ->
                                                                        db.child("favourites").child(
                                                                                "" + (viewModel.currentUser.value?.username
                                                                                    ?: "")).child(f).setValue(f)
                                                                        // Log.d("aaaa", "FirebaseUtentifavs shop  " + f)
                                                                    }

                                                              //      viewModel.clearFavs()
                                                               //     getFavsDb(db, viewModel)


                                                                }
                                                            }
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Favorite,
                                                                contentDescription = "Favorite Item",
                                                                tint = if (viewModel.favs.contains(
                                                                        ff[index].name
                                                                      //  viewModel.sellers[index].name
                                                                    )
                                                                ) Color.Red else Color.LightGray // icon color
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            Text(
                                                text = "" +  ff[index].name,//viewModel.sellers[index].name,
                                                fontSize = 15.sp,
                                                modifier = Modifier
                                                    .padding(top = 5.dp, start = 3.dp),
                                                fontWeight = FontWeight.Bold,
                                                textAlign = TextAlign.Center,
                                            )


                                        }
                                    }
                               // }

                            }
                        }
                    }

                }
            }

        }
    }
}

fun getFavsDb (db: DatabaseReference, viewModel: PurchaseViewModel)
{
    val favs = db.child("favourites")
    favs.addValueEventListener(object : ValueEventListener {
        override fun onDataChange(dataSnapshot: DataSnapshot){

            var id=""

            dataSnapshot.children.forEach(){u ->

                id = u.key.toString()


                if(id== viewModel.currentUser.value?.username ?: "") {
                    u.children.forEach() { shop ->
                        val name = shop.getValue().toString()
                        if(!viewModel.favs.contains(name))
                            viewModel.addFav(name)
                    }
                }
            }


        }
        override fun onCancelled(databaseError: DatabaseError){
            println("The read failed: " + databaseError.code)
        }
    })
}
