package it.polito.laib_3.user

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LockerPositionScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    var selected by remember { mutableStateOf((false)) }
    var program by remember { mutableStateOf((false)) }
    var highlighted1 by remember { mutableStateOf((false)) }
    var highlighted2 by remember { mutableStateOf((false)) }
    var error by remember { mutableStateOf((false)) }

    var isExpanded by remember { mutableStateOf((false)) }

    var inputError by remember { mutableStateOf((false)) }
    var day by remember { mutableStateOf("Oggi") }
    var hh by remember { mutableStateOf("") }
    var mm by remember { mutableStateOf("") }


    val context = LocalContext.current

    Log.d("bbbb", "Numero di carrello "+viewModel.cart.size)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text="Mappa"
                ) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.currentDate.value = ""
                        viewModel.currentTime.value = ""
                        viewModel.currentLocker.value = null
                        viewModel.currentLockerSpace.value = null
                        navController.navigate(Screen.CartScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },
    ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 5.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.carrello),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.Black),
                            modifier = Modifier.size(23.dp)
                        )

                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight/2),
                                end = Offset(x = 0f, y = canvasHeight/2),
                                color = Color.Black,
                                strokeWidth = 2F
                            )
                        }
                        OutlinedIconButton(
                            onClick = { },
                            enabled = false,
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.pin),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight/2),
                                end = Offset(x = 0f, y = canvasHeight/2),
                                color = Color.DarkGray,
                                strokeWidth = 1F
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.wallet),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.Black),
                            modifier = Modifier.size(23.dp)
                        )

                    }

                    Spacer(modifier = Modifier.height(15.dp))

                    Text(
                        text = "Seleziona un locker dalla mappa",
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val singapore = LatLng(1.35, 103.87)
                 /*   val cameraPositionState = rememberCameraPositionState {
                        position = CameraPosition.fromLatLngZoom(singapore, 10f)
                    }
                    GoogleMap(
                        modifier = Modifier.fillMaxSize(),
                        cameraPositionState = cameraPositionState
                    ) {
                        Marker(
                            state = MarkerState(position = singapore),
                            title = "Singapore",
                            snippet = "Marker in Singapore"
                        )
                    } */

                    viewModel.lockersList.forEach(){lock->
                        var address = lock.spaces[0].address

                        if(viewModel.currentShop.value?.lockers?.contains(address) == true && !viewModel.actualLockers.contains(lock))
                            viewModel.addActualLocker(lock)
                    }



                    viewModel.actualLockers.forEach { lock ->

                        var available = false
                        var piccola = 0
                        var media = 0
                        var grande = 0

                        viewModel.cart.forEach() {prod->

                            if (prod.key.dimension == "Piccola")
                                piccola = piccola + prod.value
                            if (prod.key.dimension == "Media")
                                media = media + prod.value
                            if (prod.key.dimension == "Grande")
                                grande = grande + prod.value

                        }


                        if(piccola<10 && media==0 && grande==0)
                         viewModel.currentDimension.value = "Piccola"
                        else if(piccola<4 && media>0 && media<4 && grande==0)
                         viewModel.currentDimension.value = "Media"
                        else
                          viewModel.currentDimension.value = "Grande"

                        Log.d("delivery", "locker screen delivery : "+ (viewModel.currentDimension.value
                            ?: ""))




                        //implementare anche per le dimensioni
                        lock.spaces.forEach() {space->
                            if(space.free)
                            {    if(space.dimension == viewModel.currentDimension.value)
                                        available = true
                            }
                        }

                        if(available)
                        {
                            Row()
                            {
                                IconToggleButton(
                                    checked = viewModel.lockersChecked.getValue(lock),
                                    onCheckedChange = { _checked ->
                                        viewModel.resetLockers()
                                        viewModel.changeSelectedLocker(lock, _checked)

                                        if(_checked)
                                        {   viewModel.currentLocker.value = lock
                                            selected=true

                                            // qui vedere lo spazio per le dimensioni del pacco
                                        }
                                        else
                                            selected=false
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "Favorite Item",
                                        tint = if (viewModel.lockersChecked.getValue(lock)) Color.Red else Color.LightGray // icon color
                                    )
                                }
                            }
                        }
                        else
                        {   Row()
                            {
                                IconButton(
                                    onClick = { Toast.makeText(context,"Nessuno spazio libero con le giuste dimensioni per questo locker", Toast.LENGTH_SHORT).show()}
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "Favorite Item",
                                        tint = Color.LightGray // icon color
                                    )
                                }
                            }
                        }

                    }


                    Spacer(modifier = Modifier.height(15.dp))

                    if(selected) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically

                        ) {
                            var address = ""
                            viewModel.lockersList.forEach() { lock ->
                                if (lock.id_locker == viewModel.currentLocker.value?.id_locker ?: "")
                                    address = lock.spaces[0].address
                            }

                            Text(
                                text = "Hai selezionato il locker in ${address}",
                                fontSize = 18.sp,
                            )
                        }
                    }
                    }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement
                        .spacedBy(
                            space = 20.dp,
                            alignment = Alignment.CenterHorizontally
                        ),
                )
                {
                    OutlinedButton(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(150.dp),
                        shape = RectangleShape,
                        border = BorderStroke(1.dp, if(highlighted1) Color.Green else Color.DarkGray),
                        onClick = { program = false
                                    highlighted1 = true
                                    highlighted2 = false

                            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
                            val current = LocalDateTime.now().format(formatter)

                            val parts = current.split(" | ")
                            val d = parts[0]
                            val t = parts[1]


                            viewModel.currentDate.value = d

                                val tom = LocalDateTime.now().plusMinutes(45).format(formatter)
                                val parts2 = tom.split(" | ")
                                val timeNext = parts2[1]
                                viewModel.currentTime.value = timeNext

                        },
                        content = {
                            Text(
                                text = "45-60 minuti",
                                fontSize = 10.sp
                            )
                        }
                    )

                    OutlinedButton(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(150.dp),
                        shape = RectangleShape,
                        onClick = { program = true
                                    highlighted2 = true
                                    highlighted1 = false},
                        border = BorderStroke(1.dp, if(highlighted2) Color.Green else Color.DarkGray),
                        content = {
                            Text(
                                text = "Programma l'ordine",
                                fontSize = 10.sp
                            )
                        }
                    )

                }



                    Spacer(modifier = Modifier.height(40.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(120.dp),
                        onClick = {

                           // if(!selected || (!highlighted1 && !highlighted2))
                            if(!highlighted1 && !highlighted2)
                                error =true

                       /*     var currentLocker=""
                            currentLocker = viewModel.currentLocker.value?.id_locker ?: ""

                            if(currentLocker=="")
                                error = true */

                            if(!error)
                            {

                                var found = false

                                viewModel.currentLocker.value?.spaces?.forEach() { space ->
                                  if (space.free && space.dimension == viewModel.currentDimension.value) {
                                    if (!found) {
                                        viewModel.currentLockerSpace.value = space
                                        found = true
                                    }
                                  }
                                }

                                navController.navigate(Screen.PaymentScreen.route)
                                Log.d("dddd", "actual day: ${viewModel.currentDate.value} e actual hour: ${viewModel.currentTime.value}")


                            }
                                  },
                        content = { Text( text="Avanti",
                            fontSize = 16.sp ) }
                    )


                }
            }
        }
    if (error) {
        AlertDialog(
            onDismissRequest = { error = false },
            text = {
                var currentLocker=""
                currentLocker = viewModel.currentLocker.value?.id_locker ?: ""

                if(currentLocker=="")
                    Text("Nessun locker selezionato")

                if(!highlighted1 && !highlighted2)
                    Text("Nessun orario selezionato")


                 },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = { error = false }
                ) {
                    Text("OK")
                }
            }
        )

    }

    if (program) {
        AlertDialog(
            modifier = Modifier.wrapContentSize(),
            onDismissRequest = { program = false },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Programma l'ordine",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                    )
                    Spacer(modifier = Modifier.height(30.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 2.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                        verticalAlignment = Alignment.CenterVertically,
                    )
                    {
                        ExposedDropdownMenuBox(
                            modifier = Modifier.width(142.dp).padding(end=15.dp),
                            expanded = isExpanded,
                            onExpandedChange = { isExpanded = !isExpanded }
                        ) {
                            TextField(
                                value = day,
                                onValueChange = { },
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                },
                                placeholder = {
                                    Text(text = "Oggi")
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier
                                    .menuAnchor()
                                    .width(142.dp),
                            )
                            ExposedDropdownMenu(
                                expanded = isExpanded,
                                onDismissRequest = { isExpanded = !isExpanded }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(text = "Oggi") },
                                    onClick = {
                                        day = "Oggi"
                                        isExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(text = "Domani") },
                                    onClick = {
                                        day = "Domani"
                                        isExpanded = false

                                    }
                                )


                            }

                        }


                        OutlinedTextField(
                            modifier = Modifier.width(63.dp),
                                value = hh,
                                onValueChange = { newText ->
                                    hh = newText
                                },
                                placeholder = { Text(text = "8") },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                            )
                        Text(
                            text = ":",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                        )

                        OutlinedTextField(
                            modifier = Modifier.width(63.dp),
                            value = mm,
                            onValueChange = { newText ->
                                mm = newText
                            },
                            placeholder = { Text(text = "00")},
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                        )


                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }

            },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {

                        if (mm.toInt() > 60 || hh.toInt() > 23)
                        {     inputError = true
                              Toast.makeText(context, "Errore orario inserito",Toast.LENGTH_SHORT).show()
                        }

                        if (!inputError) {
                            program = false

                            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
                            val current = LocalDateTime.now().format(formatter)

                            val parts = current.split(" | ")
                            val d = parts[0]
                            val t = parts[1]

                            if (day == "Oggi")
                                viewModel.currentDate.value = d
                            else {
                                val tom = LocalDateTime.now().plusDays(1).format(formatter)
                                val parts2 = tom.split(" | ")
                                val dateTom = parts2[0]
                                viewModel.currentDate.value = dateTom
                            }

                            viewModel.currentTime.value = hh + ":" + mm

                        }
                    }
                ) {
                    Text("Conferma")
                }
            },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = { program = false
                                day = "oggi"
                                hh = ""
                        hh = "mm"}
                ) {
                    Text("Annulla")
                }
            }

        )

    }
}
