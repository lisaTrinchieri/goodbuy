package it.polito.laib_3

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import it.polito.laib_3.ui.theme.Laib_3Theme

private lateinit var viewModel: PurchaseViewModel
private lateinit var  auth: FirebaseAuth
private lateinit var authAnon: FirebaseAuth

@SuppressLint("CustomSplashScreen")
class SplashActivity: ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        viewModel = ViewModelProvider(this)[PurchaseViewModel::class.java]
        val db = Firebase.database.reference //OK
        auth= FirebaseAuth.getInstance()
        authAnon = Firebase.auth


        //AGGIUNTA UTENTI
        val users = db.child("users")
        users.addValueEventListener(object : ValueEventListener {
            @SuppressLint("SuspiciousIndentation")
            override fun onDataChange(dataSnapshot: DataSnapshot){

                viewModel.clearUsers()
                dataSnapshot.children.forEach() { u ->

                    val id = u.key.toString()
                    val username = u.child("username").getValue().toString()
                    val password = u.child("password").getValue().toString()
                    val email = u.child("email").getValue().toString()
                    val tel = u.child("number").getValue().toString()
                    //  val image = u.child("image").getValue().toString()


                    val newUser = User(username, password, email, tel)

                    //     if(viewModel.currentRole.value == "seller")
                    //     {
                    if (!viewModel.users.contains(newUser)) {
                        viewModel.addUser(newUser)
                        viewModel.addUsersComplete(id, newUser)
                    }
                    //    }
                    //    else if (viewModel.currentRole.value == "user")

                    if(auth.currentUser?.email ==email)
                    {   viewModel.currentUser.value = newUser
                        viewModel.currentRole.value = "user"
                    }
                }

            }
            override fun onCancelled(databaseError: DatabaseError){
                println("The read failed: " + databaseError.code)
            }
        })

        //AGGIUNTA DEI COMMERCIANTI
        val sellers = db.child("sellers")
        sellers.addValueEventListener(object : ValueEventListener {
            @SuppressLint("SuspiciousIndentation")
            override fun onDataChange(dataSnapshot: DataSnapshot){

                viewModel.clearSellers()
                dataSnapshot.children.forEach() { u ->

                    val id = u.key.toString()
                    val name = u.child("name").getValue().toString()
                    val address = u.child("address").getValue().toString()
                    val category = u.child("category").getValue().toString()
                    val password = u.child("password").getValue().toString()
                    val email = u.child("email").getValue().toString()
                    val tel = u.child("number").getValue().toString()
                    val orari = u.child("orari").getValue().toString()
                    val lockers = u.child("lockers").getValue().toString()
                    val image = u.child("image").getValue().toString()

                    val newSeller = Seller(password, name, address, category, tel, email, orari, lockers, image)

                    //  if (viewModel.currentRole.value == "user")
                    //  {
                    if (!viewModel.sellers.contains(newSeller)) {
                        viewModel.addSeller(newSeller)
                        viewModel.addSellersComplete(id, newSeller)
                    }

                    if(auth.currentUser?.email == email)
                    {    viewModel.currentSeller.value = newSeller
                        viewModel.currentRole.value = "seller"
                    }
                    //  }
                    //  else if(viewModel.currentRole.value == "seller")
                    //  {
                    //si salva solo il seller che ha fatto accesso precedentemete
                    //  }

                }
                //  }

            }
            override fun onCancelled(databaseError: DatabaseError){
                println("The read failed: " + databaseError.code)
            }
        })


        //AGGIUNTA DEI PRODOTTI
        val products = db.child("products")
        products.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot){

                viewModel.clearProducts()
                dataSnapshot.children.forEach(){u ->

                    val id = u.key.toString()
                    val shop= u.child("shop").getValue().toString()
                    val name = u.child("name").getValue().toString()
                    val quantity= u.child("quantity").getValue().toString().toInt()
                    val unit = u.child("unit").getValue().toString()
                    val dimension = u.child("dimension").getValue().toString()
                    val price = u.child("price").getValue().toString()
                    val ingredients = u.child("ingredients").getValue().toString()
                    val vegan = u.child("vegan").getValue().toString().toBoolean()
                    val gluten = u.child("glutenFree").getValue().toString().toBoolean()
                    val image = u.child("image").getValue().toString()

                    val newProduct = Product(shop, name, quantity, dimension, unit, price, ingredients, vegan, gluten, image)

                    if(!viewModel.products.contains(newProduct))
                    {   viewModel.addProduct(newProduct)
                        viewModel.addProductsComplete(shop, newProduct)
                    }
                }
                //  }

            }
            override fun onCancelled(databaseError: DatabaseError){
                println("The read failed: " + databaseError.code)
            }
        })

        //AGGIUNTA DELLE CONSEGNE
        val deliveries = db.child("deliveries")
        deliveries.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot){

                viewModel.clearDeliveries()
                viewModel.clearDeliveriesOrder()

                dataSnapshot.children.forEach(){del ->
                    val id = del.key.toString()
                    val status = del.child("status").getValue().toString()
                    val dateStart = del.child("date_Start").getValue().toString()
                    val timeStart = del.child("time_Start").getValue().toString()
                    val dateUpdate = del.child("date_Update").getValue().toString()
                    val timeUpdate = del.child("time_Update").getValue().toString()
                    val dateDue = del.child("date_Due").getValue().toString()
                    val timeDue = del.child("time_Due").getValue().toString()
                    val mittente = del.child("id_mittente").getValue().toString()
                    val destinatario = del.child("id_destinatario").getValue().toString()
                    val locker = del.child("locker").getValue().toString()
                    val space = del.child("locker_space").getValue().toString()
                    val inserimento = del.child("code_inserimento").getValue().toString().toInt()
                    val sblocco = del.child("code_sblocco").getValue().toString().toInt()
                    val prodsString = del.child("products").getValue().toString()
                    val price = del.child("price").getValue().toString().toDouble()
                    val payment = del.child("payment").getValue().toString()

                    val delivery = Consegna(status, dateStart,timeStart,dateUpdate,timeUpdate,dateDue, timeDue, mittente,destinatario, locker,space, inserimento, sblocco,prodsString, price, payment)

                    if(!viewModel.deliveries.contains(delivery))
                        viewModel.addDelivery(delivery)

                    if(!viewModel.deliveriesComplete.containsKey(id))
                        viewModel.addDeliveryComplete(id, delivery)

                }

                viewModel.orderDeliveries("In corso")

            }
            override fun onCancelled(databaseError: DatabaseError){
                println("The read failed: " + databaseError.code)
            }
        })

        //AGGIUNTA DEI LOCKER

        val lockers = db.child("lockers")
        lockers.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot){

                viewModel.clearLockers()
                dataSnapshot.children.forEach(){locker ->

                    val lockerSpaces = ArrayList<LockerSpace>()
                    val id = locker.key.toString()

                    locker.children.forEach() {space->
                        val id = space.key.toString()
                        val idSpace = space.child("name").getValue().toString()
                        val isFree = space.child("free").getValue().toString().toBoolean()
                        val codeIns = space.child("code_ins").getValue().toString().toInt()
                        val codeRit = space.child("code_rit").getValue().toString().toInt()
                        val dimension = space.child("dimension").getValue().toString()
                        val address = space.child("address").getValue().toString()

                        val lockerSpace = LockerSpace(idSpace, isFree, codeIns, codeRit, dimension, address)

                        lockerSpaces.add(lockerSpace)
                    }


                    val locker = Locker(id, lockerSpaces)

                    var already = false
                    viewModel.lockersList.forEach() {lock ->

                        if(lock.id_locker == locker.id_locker)
                            already = true

                    }

                    if(!already)
                        viewModel.addLocker(locker)
                }

            }
            override fun onCancelled(databaseError: DatabaseError){
                println("The read failed: " + databaseError.code)
            }
        })


        setContent {
            Laib_3Theme{
                SplashScreen2()

                Handler().postDelayed({
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }, 5000)
            }
        }
    }
}

@Composable
fun SplashScreen2() {
  /*  LaunchedEffect(key1 = true){
        delay(20000)
        startActivity(Intent(this@SplashActivity, MainActivity::class.java))
    } */
    Box(modifier = Modifier
        .height(300.dp)
        .width(300.dp) ){
        Image(
            painter = painterResource(id = R.drawable.artboard_1),
            contentDescription = null,
            modifier = Modifier
                .width(width = 250.dp)
                .clip(
                    shape = RoundedCornerShape(
                        size = 12.dp
                    )
                ),
            contentScale = ContentScale.Crop
        )
    }

}