package it.polito.laib_3.seller

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeSellerScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
    val current = LocalDateTime.now().format(formatter)

    val parts1 = current.split(" | ")
    val date = parts1[0]
    val time = parts1[1]

    val tom = LocalDateTime.now().plusDays(1).format(formatter)
    val parts2 = tom.split(" | ")
    val dateTom = parts2[0]


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Goodbuy") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                actions = {
                        var count = 0
                        viewModel.deliveries.forEach(){del ->
                            if(del.status == "started")
                                count++
                        }
                        if(count > 0)
                        {
                        BadgedBox(
                            modifier = Modifier.wrapContentSize().padding(end=20.dp),
                            badge = { Badge() { Text("$count") } })
                        {
                                 /* IconButton(
                                      modifier = Modifier.wrapContentSize(),
                                      onClick = { navController.navigate(Screen.OrdersStartedScreen.route) }) { */
                                  Icon(
                                      imageVector = Icons.Filled.Notifications,
                                      contentDescription = "to show",
                                      modifier = Modifier.clickable { navController.navigate(Screen.OrdersStartedScreen.route) },
                                      tint = Color.White,)
                                  }
                               // }
                        }
                    else
                    {
                        IconButton(onClick = { navController.navigate(Screen.OrdersStartedScreen.route) }) {
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                tint = Color.White,)
                            }
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(  modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),)
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                            Icon(Icons.Filled.Home, contentDescription = "Localized description")
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerLockerScreen.route)
                            }) {
                            Icon(

                                Icons.Filled.Lock,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerOrdersScreen.route)
                            }) {
                            Icon(
                                Icons.Filled.List,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.SellerProfileScreen.route) }) {
                            Icon(
                                Icons.Filled.Person,
                                contentDescription = "Localized description",
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                     //   .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ordini da preparare",
                            fontWeight = FontWeight.Bold,
                            fontSize = 25.sp,
                        )

                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().background(Color.LightGray)
                        )
                        {
                            Text(
                                modifier = Modifier.padding(horizontal=16.dp, vertical=4.dp),
                                text = "OGGI",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                            )
                        }

                    }

                    Divider(color = Color.DarkGray, thickness = 2.dp)

                    var empty = true

                    viewModel.deliveries.forEach() { del ->
                        if(del.status == "inProgress" && del.date_Due==date)
                            empty = false
                    }

                    if(empty)
                    {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ){
                            Text(
                                text = "Non sono presenti ordini da preparare per oggi." ,
                                fontSize = 18.sp,
                                //  textAlign = TextAlign.Left,
                            )
                        }
                    }
                    else {
                        viewModel.deliveries.forEach() { del ->
                            //   if(del.id_mittente== viewModel.currentSeller.value?.name ?: "")
                            //   {
                            if (del.status == "inProgress" && del.date_Due == date) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    horizontalArrangement = Arrangement.Start,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        modifier = Modifier
                                            .height(105.dp)
                                            .fillMaxWidth(),
                                        onClick = {
                                            navController.navigate(Screen.OrderDetailSeller.route)
                                            viewModel.currentDelivery.value = del
                                            viewModel.currentDay.value = "oggi"
                                        },
                                        shape = RectangleShape,
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = Color.Transparent,
                                            contentColor = Color.Black
                                        ),
                                    ) {

                                        Box(
                                            modifier = Modifier
                                                .height(105.dp)
                                                .width(250.dp)
                                        ) {
                                            Column() {
                                                Spacer(modifier = Modifier.height(5.dp))
                                                Row() {
                                                    Icon(
                                                        imageVector = Icons.Default.LocationOn,
                                                        contentDescription = "Favorite Item",
                                                    )
                                                    Spacer(modifier = Modifier.width(25.dp))

                                                    var address = ""
                                                    viewModel.lockersList.forEach() { lock ->
                                                        if (lock.id_locker == del.locker)
                                                            address = lock.spaces[0].address
                                                    }


                                                    Text(
                                                        text = "" + address,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 18.sp,
                                                        //  textAlign = TextAlign.Left,
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(3.dp))
                                                Row() {

                                                    val parti1 = time.split(":")
                                                    val startTime = LocalTime.of(
                                                        parti1[0].toInt(),
                                                        parti1[1].toInt()
                                                    ) // Esempio: 09:00

                                                    val parti2 = del.time_Due.split(":")
                                                    val endTime = LocalTime.of(
                                                        parti2[0].toInt(),
                                                        parti2[1].toInt()
                                                    )

                                                    val duration =
                                                        Duration.between(startTime, endTime)

                                                    // Ottieni il numero di ore e minuti dalla durata
                                                    val hours = duration.toHours()
                                                    val minutes = duration.toMinutes() % 60

                                                    if (hours.toInt() != 0) {
                                                        Spacer(modifier = Modifier.width(60.dp))

                                                        var username = ""
                                                        viewModel.users.forEach() { u ->
                                                            if (u.email == del.id_destinatario)
                                                                username = u.username

                                                        }

                                                        Text(
                                                            text = "" + username,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 18.sp,
                                                            //  textAlign = TextAlign.Left,
                                                        )
                                                    } else {
                                                        Image(
                                                            painter = painterResource(id = R.drawable.clock),
                                                            contentDescription = "confermato",
                                                            colorFilter = ColorFilter.tint(Color.Black),
                                                            modifier = Modifier.size(20.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(15.dp))

                                                        var username = ""
                                                        viewModel.users.forEach() { u ->
                                                            if (u.email == del.id_destinatario)
                                                                username = u.username

                                                        }

                                                        Text(
                                                            text = "" + username,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 18.sp,
                                                            //  textAlign = TextAlign.Left,
                                                        )
                                                    }
                                                }
                                                Row() {

                                                    Spacer(modifier = Modifier.width(60.dp))

                                                    Text(
                                                        text = "entro le " + del.time_Due,
                                                        fontSize = 16.sp,
                                                        //  textAlign = TextAlign.Left,
                                                    )
                                                }
                                            }
                                        }

                                        Box(
                                            modifier = Modifier
                                                .height(105.dp)
                                                .width(70.dp)
                                                .wrapContentSize(Alignment.Center)

                                        ) {
                                            Icon(
                                                Icons.Filled.ArrowForward,
                                                contentDescription = "Favorite",
                                                modifier = Modifier.size(ButtonDefaults.IconSize),
                                                tint = Color.Black
                                            )

                                        }

                                    }
                                }
                                Divider(color = Color.DarkGray, thickness = 2.dp)
                            }
                        }
                    }


                    //DOMANI
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().background(Color.LightGray)
                        )
                        {
                            Text(
                                modifier = Modifier.padding(horizontal=16.dp, vertical=4.dp),
                                text = "DOMANI",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                            )
                        }
                    }

                    Divider(color = Color.DarkGray, thickness = 2.dp)

                    var emptyTom = true

                    viewModel.deliveries.forEach() { del ->
                        if(del.status == "inProgress" && del.date_Due==dateTom)
                            emptyTom = false
                    }

                    if(emptyTom)
                    {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ){
                            Text(
                                text = "Non sono presenti ordini da preparare per domani." ,
                                fontSize = 18.sp,
                                //  textAlign = TextAlign.Left,
                            )
                        }
                    }
                    else {

                    viewModel.deliveries.forEach(){del->
                        //   if(del.id_mittente== viewModel.currentSeller.value?.name ?: "")
                        //   {
                        if(del.status == "inProgress" && del.date_Due==dateTom)
                        {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ){
                                Button(
                                    modifier = Modifier
                                        .height(105.dp)
                                        .fillMaxWidth(),
                                    onClick = {
                                        navController.navigate(Screen.OrderDetailSeller.route)
                                        viewModel.currentDelivery.value = del
                                        viewModel.currentDay.value = "domani"
                                    },
                                    shape = RectangleShape,
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                                ) {

                                    Box(
                                        modifier = Modifier
                                            .height(105.dp)
                                            .width(250.dp)
                                    ) {
                                        Column() {
                                            Spacer(modifier = Modifier.height(5.dp))
                                            Row() {
                                                Icon(
                                                    imageVector = Icons.Default.LocationOn,
                                                    contentDescription = "Favorite Item",
                                                )
                                                Spacer(modifier = Modifier.width(25.dp))

                                                var address = ""
                                                viewModel.lockersList.forEach() { lock ->
                                                    if (lock.id_locker == del.locker)
                                                        address = lock.spaces[0].address
                                                }


                                                Text(
                                                    text = "" + address,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 18.sp,
                                                    //  textAlign = TextAlign.Left,
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(3.dp))
                                            Row() {

                                                Spacer(modifier = Modifier.width(50.dp))

                                                var username = ""
                                                viewModel.users.forEach(){u ->
                                                    if(u.email == del.id_destinatario)
                                                        username = u.username

                                                }

                                                Text(
                                                    text = "" + username,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 18.sp,
                                                    //  textAlign = TextAlign.Left,
                                                )
                                            }
                                            Row() {

                                                Spacer(modifier = Modifier.width(50.dp))

                                                Text(
                                                    text = "entro le " + del.time_Due,
                                                    fontSize = 16.sp,
                                                    //  textAlign = TextAlign.Left,
                                                )
                                            }
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .height(105.dp)
                                            .width(70.dp)
                                            .wrapContentSize(Alignment.Center)

                                    ) {
                                        Icon(
                                            Icons.Filled.ArrowForward,
                                            contentDescription = "Favorite",
                                            modifier = Modifier.size(ButtonDefaults.IconSize),
                                            tint = Color.Black
                                        )

                                    }

                                }
                            }
                            Divider(color = Color.DarkGray, thickness = 2.dp)
                        }
                      }
                    }

                }
            }
        }
    }
}