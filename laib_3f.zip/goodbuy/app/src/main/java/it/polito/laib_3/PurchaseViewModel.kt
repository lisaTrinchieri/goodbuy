package it.polito.laib_3

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PurchaseViewModel : ViewModel() {


    val categories = listOf("Panificio", "Rosticceria", "Fruttivendolo", "Pasticceria", "Minimarket")

    val hoursMenu = listOf(6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24)
   // val minutesMenu = listOf(00, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55)

    val dimensions = listOf("Piccola", "Media", "Grande")

    val days=listOf("Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica")

    val status = listOf("In corso", "Terminate", "Grande")

    var currentSeller = MutableLiveData<Seller>()
    var currentUser = MutableLiveData<User>()
    var currentRole = MutableLiveData<String>()
    var currentImageUrl = MutableLiveData<String>()
    var currentDelivery = MutableLiveData<Consegna>()


    //user
    var currentShop = MutableLiveData<Seller>()
    var currentProduct = MutableLiveData<Product>()
    var currentLocker = MutableLiveData<Locker>()
    var currentLockerSpace = MutableLiveData<LockerSpace>()
    var currentDimension = MutableLiveData<String>()
    var currentDate = MutableLiveData<String>()
    var currentTime = MutableLiveData<String>()

    var showSearchingResults = MutableStateFlow(false)
    var firstResearch = MutableStateFlow(false)

   //seller
    var currentDay = MutableLiveData<String>()
    private var _available: MutableList<String> = mutableStateListOf()
    val availables: List<String> = _available

    //lista degli utenti
    private var _users: MutableList<User> = mutableStateListOf()
    val users: List<User> = _users

    private var _usersComplete: MutableMap<String, User> = mutableStateMapOf()
    val usersComplete: Map<String,User> = _usersComplete

    //lista dei commercianti
    private var _sellers: MutableList<Seller> = mutableStateListOf()
    val sellers: List<Seller> = _sellers

    private var _sellersComplete: MutableMap<String, Seller> = mutableStateMapOf()
    val sellersComplete: Map<String,Seller> = _sellersComplete

    private var _sellersSearch: MutableList<Seller> = mutableStateListOf()
    val sellersSearch: List<Seller> = _sellersSearch

    //lista dei prodotti
    private var _products: MutableList<Product> = mutableStateListOf()
    val products: List<Product> = _products

    private var _productsNames: MutableList<String> = mutableStateListOf()
    val productsNames: List<String> = _productsNames

    private var _currentProducts: MutableList<Product> = mutableStateListOf()
    val currentProducts: List<Product> = _currentProducts

    private var _productsComplete: MutableMap<String, Product> = mutableStateMapOf()
    val productsComplete: Map<String,Product> = _productsComplete

    //favs
    private var _favs: MutableList<String> = mutableStateListOf()
    val favs: List<String> = _favs

    private var _favsComplete: MutableMap<String, List<String>> = mutableStateMapOf()
    val favsComplete: Map<String,List<String>> = _favsComplete

    //carrello
    private var _cart: MutableMap<Product, Int> = mutableStateMapOf()
    val cart: Map<Product, Int> = _cart
    var totalPrice = MutableLiveData<Double>()


    //SEARCHING
    private val _isSearching = MutableStateFlow(false)
    val isSearching = _isSearching.asStateFlow()

    //second state the text typed by the user
    private val _searchText = MutableStateFlow("")
    val searchText = _searchText.asStateFlow()


    private val sellersFlow = flowOf(sellers)
    private val productsFlow = flowOf(products)


    private val productsFlowText = flowOf(productsNames)

    val searchTextStateFlow = MutableStateFlow("")


        val searchResultsSellers: StateFlow<List<Seller>> =
            searchTextStateFlow
                .combine(sellersFlow) { searchQuery, sellers ->
                    when {
                        searchQuery.isNotEmpty() -> sellers.filter { seller ->
                            seller.name.contains(searchQuery, ignoreCase = true)
                        }
                        else -> sellers
                    }
                }
                .stateIn(
                    scope = viewModelScope,
                    initialValue = emptyList(),
                    started = SharingStarted.WhileSubscribed(5_000)
                )

    val searchResultsProducts: StateFlow<List<Product>> =
        searchTextStateFlow
            .combine(productsFlow) { searchQuery, products ->
                when {
                    searchQuery.isNotEmpty() -> products.filter { prod ->
                        prod.name.contains(searchQuery, ignoreCase = true)
                    }
                    else -> products
                }
            }
            .stateIn(
                scope = viewModelScope,
                initialValue = emptyList(),
                started = SharingStarted.WhileSubscribed(5_000)
            )

    val searchResultsProductsText: StateFlow<List<String>> =
        searchTextStateFlow
            .combine(productsFlowText) { searchQuery, products ->
                when {
                    searchQuery.isNotEmpty() -> products.filter { prod ->
                        prod.contains(searchQuery, ignoreCase = true)
                    }
                    else -> products
                }
            }
            .stateIn(
                scope = viewModelScope,
                initialValue = emptyList(),
                started = SharingStarted.WhileSubscribed(5_000)
            )


    var userKey = MutableLiveData<String>()
    var userUid = MutableLiveData<String>()

    //lista dei locker
    private var _lockersList: MutableList<Locker> = mutableStateListOf()
    val lockersList: List<Locker> = _lockersList
    private var _lockersSelected: MutableList<Locker> = mutableStateListOf()
    val lockersSelected: List<Locker> = _lockersSelected
    private var _lockersChecked: MutableMap<Locker, Boolean> = mutableStateMapOf()
    val lockersChecked: Map<Locker, Boolean> = _lockersChecked
    private var _actualLockers: MutableList<Locker> = mutableStateListOf()
    val actualLockers: List<Locker> = _actualLockers


    //lista delle consegne senza ID
    private var _deliveries: MutableList<Consegna> = mutableStateListOf()
    val deliveries: List<Consegna> = _deliveries

    //mappa delle consegne con ID
    private var _deliveriesComplete: MutableMap<String, Consegna> = mutableStateMapOf()
    val deliveriesComplete: Map<String,Consegna> = _deliveriesComplete

   //mappa delle consegne ordinate
    private var _deliveriesOrdered: MutableMap<String, Consegna> = mutableStateMapOf()
    val deliveriesOrdered: Map<String,Consegna> = _deliveriesOrdered

    //mappa delle consegne con cui interagire
    private var _inProgress: MutableMap<String, Consegna> = mutableStateMapOf()
    val inProgress: Map<String,Consegna> = _inProgress

    //lista delle categorie espanse
    private var _expanded: MutableList<String> = mutableStateListOf()
    val expanded: List<String> = _expanded

    var user = MutableLiveData<FirebaseUser>()



    //gestione clienti
    fun addUser(user: User) {
        _users.add(user)
    }

    fun clearUsers() {
        _users.clear()
    }
    fun addUsersComplete(id:String, user:User){
        _usersComplete.put(id, user)
    }

    //gestione venditori
    fun addSeller(seller: Seller) {
        _sellers.add(seller)
    }

    fun clearSellers() {
        _sellers.clear()
    }
    fun addSellersComplete(id:String, seller:Seller){
        _sellersComplete.put(id, seller)
    }

    //gestione prodotti
    fun addProduct(prod: Product) {
        _products.add(prod)
        _productsNames.add(prod.name)
    }

    fun clearProducts() {
        _products.clear()
        _productsNames.clear()
    }
    fun addProductsComplete(id:String, prod:Product){
        _productsComplete.put(id, prod)
    }

    //gestione prodotti
    fun addCurrentProd(prod: Product) {
        _currentProducts.add(prod)
    }

    fun clearCurrentProds() {
        _currentProducts.clear()
    }


    //favourites
    fun addFav(fav: String) {
        _favs.add(fav)
    }

    fun removeFav(fav: String) {
        _favs.remove(fav)
    }

    fun clearFavs() {
        _favs.clear()
    }
    fun addFavsComplete(id:String, list: List<String>){
        _favsComplete.put(id, list)
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //carrello
    fun addToCart(prod: Product, num: Int) {
        _cart.put(prod, num)
    }

    fun updateCart(prod: Product, num: Int) {
        _cart.replace(prod, num)
    }

    fun clearCart() {
        _cart.clear()
    }

    fun updatePrice(){
        var total = 0.00

        cart.forEach() {item->
            total += item.value * item.key.price.toDouble()
        }

        totalPrice.value = total
    }




////////////////////////////////////////////////////////////////////////////////////////////////////

    fun addLocker(locker : Locker){
        _lockersList.add(locker)
        _lockersChecked.put(locker, false)
    }

    fun clearLockers() {
        _lockersList.clear()
        _lockersChecked.clear()
    }

    fun addLockersSelected(locker : Locker){
        _lockersSelected.add(locker)
    }
    fun removeLockersSelected(locker:Locker) {
        _lockersSelected.remove(locker)
    }

    fun removeLockerSelectedAll() {
        _lockersSelected.clear()
    }

    fun resetLockers() {
        _lockersChecked.keys.forEach(){ lock->
            _lockersChecked.replace(lock, false)
        }
    }
    fun changeSelectedLocker(lock: Locker, value:Boolean){
        _lockersChecked.replace(lock, value)
    }

    fun addActualLocker(locker : Locker){
        _actualLockers.add(locker)
    }

    fun clearActualLockers(){
        _actualLockers.clear()
    }



    ///////////////////////////////////////////////////////////////////////////////////////////////7
    //REASEARCH
    fun onSearchTextChange(text: String) {
        _searchText.value = text
        firstResearch.value = true

    }

    fun onToogleSearch() {
        _isSearching.value = !_isSearching.value
        if (!_isSearching.value) {
            onSearchTextChange("")
        }
    }

    fun onResetSearch() {
        _isSearching.value = false

    }

    // Funzione per impostare il valore del testo di ricerca
    fun setSearchText(query: String) {
        searchTextStateFlow.value = query
        firstResearch.value = true
    }

    fun filterForProduct(prod: String) {

        products.forEach() {p->
            if(p.name.contains(prod)) {
                var seller = p.shop

                sellers.forEach() {s->
                    if(s.name == seller)
                        _sellersSearch.add(s)

                }

            }
        }
        _isSearching.value = false
        _searchText.value = prod
    }




///////////////////////////////////////////////////////////////////////////////////////////////////////////

    fun addDelivery(delivery: Consegna) {
        _deliveries.add(delivery)
    }

    fun addDeliveryComplete(id:String, delivery:Consegna){
        _deliveriesComplete.put(id, delivery)
    }



    fun clearDeliveriesOrder() {
        _deliveriesOrdered.clear()
    }



    fun clearDeliveries() {
        _deliveries.clear()
        _deliveriesComplete.clear()
    }


    fun orderDeliveries(orderBy : String){

        if(orderBy == "")
            _deliveriesOrdered = _deliveriesComplete

        if(orderBy == "Terminate")
        {
            _deliveriesComplete.forEach() {delivery ->
                if(delivery.value.status=="pacco depositato" || delivery.value.status=="pacco ritirato" ||
                    delivery.value.status == "superato tempo massimo")
                    _deliveriesOrdered.put(delivery.key, delivery.value)
            }
        }

        if(orderBy == "In corso")
        {
            _deliveriesComplete.forEach() {delivery ->
                if(delivery.value.status=="iniziata")
                    _deliveriesOrdered.put(delivery.key, delivery.value)
            }
        }

    }
/////////////////////////////////////////////
//available
     fun addToAvailable(prod : String) {
          _available.add(prod)
    }

    fun removeToAvailable(prod : String) {
        _available.remove(prod)
    }


fun clearAvailable() {
    _available.clear()
}

    //////
    //splash screen
    private val _valid : MutableStateFlow<Boolean?> = MutableStateFlow(null)
    val valid : StateFlow<Boolean?> = _valid

    fun trackSplashScreenStarted() {
        //dummy method
    }

    ////////////////////////////////
    fun removeInProg(id: String, del : Consegna) {
        _inProgress.remove(id, del)
    }

    fun addInProg(id: String, del : Consegna) {
        _inProgress.put(id, del)
    }

    fun addExpanded(key : String) {
        _expanded.add(key)
    }

    fun removeExpanded(key : String) {
        _expanded.remove(key)
    }


    //lloading dialog
    var open = MutableLiveData<Boolean>()

    var open2 = MutableStateFlow(false)
    var confirm = MutableStateFlow(false)

    fun startThread(
        db:DatabaseReference, name:String, quantity:String, unit:String, dimension:String,
        ingredients:String, price: String, isVegan: Boolean, isGluten: Boolean, id:String
    ) {
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                // Do the background work here
                // I'm adding the delay
                delay(4000)
            }

            closeDialog(db, name, quantity, unit, dimension, ingredients, price, isVegan, isGluten,id)
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private fun closeDialog(db:DatabaseReference, name:String, quantity:String, unit:String, dimension:String,
                            ingredients:String, price:String, isVegan:Boolean, isGluten:Boolean, id:String) {
        open2.value = false
        confirm.value=true


        val prod =
            currentSeller.value?.let {
                Product(
                    it.name,
                    name,
                    quantity.toInt(),
                    dimension,
                    unit,
                    price,
                    ingredients.replace("\\s".toRegex(), ""),
                    isVegan,
                    isGluten,
                    currentImageUrl.value.toString()
                )
            }

        if(id=="")
           db.child("products").push().setValue(prod)
        else
           db.child("products").child(id).setValue(prod)
    }

    fun startThreadSeller(
        auth : FirebaseAuth,
        db:DatabaseReference, pwd:String, name:String, address:String, category:String,
        telephone:String, email: String, orari: String, lockers:String) {
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                delay(4000)
            }
            closeDialogSeller(auth, db, pwd, name, address, category, telephone, email, orari, lockers)
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private fun closeDialogSeller(authentic: FirebaseAuth, db:DatabaseReference, pwd:String, name:String, address:String, category:String,
                            telephone:String, email:String, orari:String, lockers:String) {
        open2.value = false


        val seller = Seller(pwd, name, address, category, telephone, email, orari.dropLast(1), lockers.dropLast(1), currentImageUrl.value.toString())


        db.child("sellers").push().setValue(seller)
        currentSeller.value=seller

        authentic.createUserWithEmailAndPassword(email, pwd)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d("aaaaa", "createUserWithEmail:success")

                    val user = authentic.currentUser
                    confirm.value=true

                    Log.d("aaaaa", "createUserWithEmail user: "+user)

                } else {
                    Log.w(
                        "aaaaa",
                        "createUserWithEmail:failure",
                        task.exception
                    )
                }
            }

    }




}


