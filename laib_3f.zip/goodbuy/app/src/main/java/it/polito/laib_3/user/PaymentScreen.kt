package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import it.polito.laib_3.Consegna
import it.polito.laib_3.LockerSpace
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.formatCurrency
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    var ended by remember { mutableStateOf((false)) }
    val selectedOption = remember { mutableStateOf("paypal") }

    //Log.d("bbbb", "Numero di carrello "+viewModel.cart.size)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text="Pagamento"
                ) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        navController.navigate(Screen.LockerPositionScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },
    ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 5.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                        verticalAlignment = Alignment.CenterVertically

                    ) {

                        Image(
                            painter = painterResource(id = R.drawable.carrello),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.Black),
                            modifier = Modifier.size(23.dp)
                        )
                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight / 2),
                                end = Offset(x = 0f, y = canvasHeight / 2),
                                color = Color.Black,
                                strokeWidth = 2F
                            )
                        }

                            Image(
                                painter = painterResource(id = R.drawable.pin),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )

                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight / 2),
                                end = Offset(x = 0f, y = canvasHeight / 2),
                                color = Color.DarkGray,
                                strokeWidth = 2F
                            )
                        }
                        OutlinedIconButton(
                            onClick = { },
                            enabled = false,
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.wallet),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "Seleziona un metodo di pagamento:",
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "Totale: ${viewModel.totalPrice.value?.let { formatCurrency(it) }} €",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(modifier = Modifier.height(25.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        //aggiungere immagine
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(100.dp)
                        ){
                            Image(
                                painter = painterResource(id = R.drawable.paypal),
                                contentDescription = "confermato",
                                modifier = Modifier.size(90.dp),
                                contentScale = ContentScale.Fit )
                        }
                        Spacer(modifier = Modifier.width(25.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(150.dp)
                        ) {
                            Text(
                                text = "PayPal",
                                fontSize = 17.sp,
                                textAlign = TextAlign.Left,
                            )
                        }
                        Spacer(modifier = Modifier.width(25.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(30.dp)
                        ) {
                            RadioButton(
                                selected = selectedOption.value == "PayPal",
                                onClick = { selectedOption.value = "PayPal" }
                            )
                        }

                    }
                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        //aggiungere immagine
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(100.dp)
                        ){
                            Image(
                                painter = painterResource(id = R.drawable.applepay),
                                contentDescription = "confermato",
                                modifier = Modifier.size(90.dp),
                                contentScale = ContentScale.Fit )
                        }
                        Spacer(modifier = Modifier.width(25.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(150.dp)
                        ) {
                            Text(
                                text = "Apple Pay",
                                fontSize = 17.sp,
                                textAlign = TextAlign.Left,
                            )
                        }
                        Spacer(modifier = Modifier.width(25.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(30.dp)
                        ) {
                            RadioButton(
                                selected = selectedOption.value == "Apple Pay",
                                onClick = { selectedOption.value = "Apple Pay" }
                             )
                        }

                    }
                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        //aggiungere immagine
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(100.dp)
                        ){
                            Image(
                            painter = painterResource(id = R.drawable.card),
                            contentDescription = "confermato",
                            modifier = Modifier.size(90.dp),
                            contentScale = ContentScale.Fit )
                        }
                        Spacer(modifier = Modifier.width(25.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(150.dp)
                        ) {
                            Text(
                                text = "Carta di credito",
                                fontSize = 17.sp,
                                textAlign = TextAlign.Left,
                            )
                        }
                        Spacer(modifier = Modifier.width(25.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(30.dp)
                        ) {
                            RadioButton(
                                selected = selectedOption.value == "carta di credito",
                                onClick = { selectedOption.value = "carta di credito" }
                            )
                        }

                    }

                    Spacer(modifier = Modifier.height(60.dp))


                    Button(
                        modifier = Modifier
                            .wrapContentSize(align = Alignment.Center)
                            .bounceClick(),
                        onClick = {
                            ended = true
                            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
                            val current = LocalDateTime.now().format(formatter)

                            val parts = current.split(" | ")
                            val date = parts[0]
                            val time = parts[1]

                            var prods=""
                            viewModel.cart.forEach(){item->
                                prods += ""+item.key.name+":"+item.value+","

                            }


                            val delivery = viewModel.totalPrice.value?.let {
                                viewModel.currentLockerSpace.value?.let { it1 ->
                                    viewModel.currentLocker.value?.let { it2 ->
                                        viewModel.currentShop.value?.let { it3 ->
                                            viewModel.currentDate.value?.let { it4 ->
                                                viewModel.currentTime.value?.let { it5 ->
                                                    Consegna("started", date,time,date,time,
                                                        it4,
                                                        it5,
                                                        it3.name,""+ (viewModel.currentUser.value?.email ?: ""), it2.id_locker,
                                                        it1.name, viewModel.currentLockerSpace.value!!.code_ins, viewModel.currentLockerSpace.value!!.code_rit,
                                                        prods.dropLast(1),
                                                        it, selectedOption.value
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }


                            var space = viewModel.currentLockerSpace.value
                            var spaceNew = space?.let { LockerSpace(space.name, false, space.code_ins, space.code_rit, space.dimension, space.address) }

                            db.child("lockers").child(""+ (viewModel.currentLocker.value?.id_locker ?: "")) //.child(""+space.name)
                                .runTransaction(object : Transaction.Handler {
                                    override fun doTransaction(p0: MutableData): Transaction.Result {
                                        //any operation
                                        if (space != null) {
                                            db.child("lockers").child(""+viewModel.currentLocker.value?.id_locker).child(""+space.name).setValue(spaceNew)
                                        }
                                        return Transaction.success(p0)
                                    }

                                    override fun onComplete(error: DatabaseError?, p1: Boolean, snapshot: DataSnapshot?) {
                                        Log.d("aaa", "FIREBASE TRANS COMPLETATA")
                                        db.child("deliveries").push().setValue(delivery)
                                    }
                                })
                                  },
                        content = {
                            Text(
                                text = "Conferma ordine",
                                fontSize = 16.sp
                            )
                        }
                    )

                    if (ended) {
                        AlertDialog(
                            onDismissRequest = { ended = false },
                            text = { Text("Ordine inviato con successo!") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    onClick = {
                                        ended = false

                                        viewModel.currentDimension.value = ""
                                        viewModel.totalPrice.value = 0.0
                                        viewModel.currentShop.value=null
                                        viewModel.currentLocker.value = null
                                        viewModel.currentLockerSpace.value=null
                                        viewModel.currentDate.value = ""
                                        viewModel.currentTime.value = ""

                                        viewModel.clearCart()
                                        viewModel.clearActualLockers()

                                        navController.navigate(Screen.HomeUserScreen.route)
                                    }
                                ) {
                                    Text("OK")
                                }
                            }
                        )

                    }


                }
            }
        }
    }
}
