package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.Consegna
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.dateFormat
import it.polito.laib_3.formatCurrency
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersUserScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
    val current = LocalDateTime.now().format(formatter)

    val parts1 = current.split(" | ")
    val date = parts1[0]
    val time = parts1[1]

    viewModel.clearCurrentCatProds()
    viewModel.clearCurrentProds()
    viewModel.clearActualCategories()

    var showEmpty by remember { mutableStateOf((false)) }
    var isExpanded by remember { mutableStateOf((false)) }
    var isEmpty by remember { mutableStateOf((true)) }
    var status by remember { mutableStateOf(("")) }
    var chip by remember { mutableStateOf(("")) }
    var rejected by remember { mutableStateOf((false)) }
    val primetime = FontFamily(Font(R.font.primetime))


    viewModel.deliveries.forEach() {del->

        if (del.rejected=="superato tempo massimo" && del.status != "leftInLocker" && del.id_destinatario == viewModel.currentUser.value?.email ?: "") {
            var code = ""

            viewModel.deliveriesComplete.forEach() { delivery ->
                if (delivery.value == del)
                    code = delivery.key
            }

            //   var del = viewModel.currentDelivery.value
            var updatedDel = del?.let {
                Consegna(
                    "rejected",
                    it.date_Start,
                    del.time_Start,
                    date,
                    time,
                    del.date_Due,
                    del.time_Due,
                    del.id_mittente,
                    del.id_destinatario,
                    del.locker,
                    del.locker_space,
                    del.code_inserimento,
                    del.code_sblocco,
                    del.products,
                    del.price,
                    del.payment,
                    del.rejected
                )
            }

            db.child("deliveries").child("" + code).setValue(updatedDel)
        }
    }

    viewModel.orderDeliveriesTime()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "GOODBUY", fontFamily = primetime) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                actions = {
                    var count = 0
                    viewModel.cart.forEach(){del ->
                        count++
                    }
                    if(count > 0)
                    {
                        BadgedBox(
                            modifier = Modifier
                                .wrapContentSize()
                                .padding(end = 20.dp),
                            badge = { Badge() { Text("$count") } })
                        {
                            Icon(
                                imageVector = Icons.Filled.ShoppingCart,
                                contentDescription = "to show",
                                modifier = Modifier.clickable { navController.navigate(Screen.CartScreen.route) },
                                tint = Color.White,)
                        }
                    }
                    else
                    {
                        IconButton(
                            onClick = { showEmpty = true }) {
                            Icon(
                                imageVector = Icons.Filled.ShoppingCart,
                                contentDescription = "to show",
                                tint = Color.LightGray,)
                        }
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ){
            item{
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
               // horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(7.dp))
                //  item {
                Row() {
                    //   Divider(color = Color.DarkGray, thickness = 2.dp)

                    Box(
                        modifier = Modifier
                            .width(150.dp)
                            .wrapContentSize(Alignment.TopEnd)
                            .padding(), //if(status=="") end=200.dp else end=2.dp),

                        contentAlignment = Alignment.CenterStart,

                    ) {
                        OutlinedButton(
                            onClick = { isExpanded = !isExpanded }
                        ) {
                            Text(
                                text = "Filtra per",
                                fontSize = 15.sp,
                                color = Color.White
                            )
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = "More",
                                tint = Color.White
                            )
                        }

                        DropdownMenu(
                            expanded = isExpanded,
                            onDismissRequest = { isExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("In corso") },
                                onClick = { status = "inProgress&toLocker"
                                            chip = "In corso"
                                           isExpanded = false
                                    isEmpty = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Terminate") },
                                onClick = { status = "leftInLocker&taken&rejected"
                                            chip = "Terminate"
                                            isExpanded = false
                                    isEmpty = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Future") },
                                onClick = { status = "started"
                                            chip = "Future"
                                            isExpanded = false
                                    isEmpty = true }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(20.dp))

                    if(status != "") {

                        InputChip(
                            modifier = Modifier
                                .height(40.dp)
                                .wrapContentWidth(),
                            onClick = { status = ""
                                        chip = ""
                                        isEmpty = true },
                            label = { Text(text = ""+chip) },

                            selected = true,
                            trailingIcon = {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Localized description",
                                )
                            },
                        )
                    }
                    Spacer(modifier = Modifier.width(70.dp))
                }

                Spacer(modifier = Modifier.height(20.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    viewModel.deliveries.forEach() { del ->

                        if ((status == "" || status.contains(del.status) && del.id_destinatario== viewModel.currentUser.value?.email ?: "")) {
                            isEmpty = false
                        }
                    }

                    if(!isEmpty)
                    {
                        viewModel.orderDeliveriesTime()
                        viewModel.deliveriesTime.forEach() { del ->

                        if ((status == "" || status.contains(del.status)) && del.id_destinatario == viewModel.currentUser.value?.email ?: "") {

                            val currentDate = LocalDate.now()

                            val yesterday = currentDate.minusDays(1)
                            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
                            val yesFormatted = yesterday.format(formatter)
                            val isYesterday = del.date_Due == yesFormatted.toString()


                            val oraActual = LocalTime.now()
                            val delHour = del.time_Due.split(":")
                            val hh = delHour[0]
                            val mm = delHour[1]

                            val delHour2 = LocalTime.of(hh.toInt(), mm.toInt())
                            val isPrecedente = delHour2.isBefore(oraActual)


                            if (isPrecedente && del.status == "leftInLocker" && isYesterday && currentDate.toString() != del.date_Due) {
                                var code = ""

                                viewModel.deliveriesComplete.forEach() { delivery ->
                                    if (delivery.value == del)
                                        code = delivery.key
                                }

                                //   var del = viewModel.currentDelivery.value
                                var updatedDel = del?.let {
                                    Consegna(
                                        "leftInLocker",
                                        it.date_Start,
                                        del.time_Start,
                                        date,
                                        time,
                                        del.date_Due,
                                        del.time_Due,
                                        del.id_mittente,
                                        del.id_destinatario,
                                        del.locker,
                                        del.locker_space,
                                        del.code_inserimento,
                                        del.code_sblocco,
                                        del.products,
                                        del.price,
                                        del.payment,
                                        "superato tempo massimo"
                                    )
                                }

                                db.child("deliveries").child("" + code).setValue(updatedDel)

                            }





                            isEmpty = false
                            var statusDel = ""

                            Row() {

                                Card(
                                    enabled = if (del.status == "leftInLocker" && del.rejected == "superato tempo massimo") false else true,
                                    colors = CardDefaults.cardColors(
                                        containerColor = Color.DarkGray,
                                    ),
                                    modifier = Modifier.size(width = 370.dp, height = 100.dp),
                                    onClick = {
                                        viewModel.currentDelivery.value = del

                                        if (del.status != "rejected" && del.rejected != "superato tempo massimo") {
                                            if (del.status != "leftInLocker")
                                                navController.navigate(Screen.OrderDetailUser.route)
                                        } else {
                                            if (del.status == "rejected" || del.rejected == "superato tempo massimo")
                                                if (del.status != "leftInLocker")
                                                    rejected = true
                                        }
                                    }
                                ) {
                                    Row()
                                    {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .width(50.dp)
                                                .wrapContentSize(Alignment.Center)
                                                .padding(10.dp)
                                        ) {
                                            val imageModifier: Modifier

                                            when (del.status) {
                                                "started" -> {
                                                    statusDel = "In attesa di conferma"
                                                    imageModifier = Modifier.size(30.dp)
                                                    Image(
                                                        painter = painterResource(id = R.drawable.clock),
                                                        contentDescription = "confermato",
                                                        colorFilter = ColorFilter.tint(Color.Black),
                                                        modifier = imageModifier
                                                    )
                                                }

                                                "inProgress" -> {
                                                    statusDel =
                                                        "Da consegnare il " + dateFormat(del.date_Due)
                                                    imageModifier = Modifier.size(30.dp)
                                                    Image(
                                                        painter = painterResource(id = R.drawable.confermato),
                                                        contentDescription = "confermato",
                                                        colorFilter = ColorFilter.tint(Color.Black),
                                                        modifier = imageModifier
                                                    )
                                                }

                                                "toLocker" -> {
                                                    statusDel =
                                                        "In consegna il " + dateFormat(del.date_Update)
                                                    imageModifier = Modifier.size(30.dp)
                                                    Image(
                                                        painter = painterResource(id = R.drawable.scooter),
                                                        contentDescription = "confermato",
                                                        colorFilter = ColorFilter.tint(Color.Yellow),
                                                        modifier = imageModifier
                                                    )
                                                }

                                                "leftInLocker", "" -> {
                                                    statusDel =
                                                        "Depositato il" + dateFormat(del.date_Update)
                                                    imageModifier = Modifier.size(30.dp)
                                                    Image(
                                                        painter = painterResource(id = R.drawable.armadietto),
                                                        contentDescription = "confermato",
                                                        colorFilter = if(del.rejected=="") ColorFilter.tint(Color.Green) else ColorFilter.tint(Color.Red),
                                                        modifier = imageModifier
                                                    )
                                                }

                                                "rejected", "superato tempo massimo" -> {
                                                    if (del.status != "leftInLocker") {
                                                        statusDel = "Ordine non confermato"
                                                        imageModifier = Modifier.size(30.dp)
                                                        Image(
                                                            painter = painterResource(id = R.drawable.errore),
                                                            contentDescription = "confermato",
                                                            colorFilter = ColorFilter.tint(Color.Red),
                                                            modifier = imageModifier
                                                        )
                                                    } else {
                                                        statusDel = "Superato tempo massimo"
                                                        imageModifier = Modifier.size(30.dp)
                                                        Image(
                                                            painter = painterResource(id = R.drawable.errore),
                                                            contentDescription = "confermato",
                                                            colorFilter = ColorFilter.tint(Color.Red),
                                                            modifier = imageModifier
                                                        )
                                                    }
                                                }

                                                "taken" -> {
                                                    statusDel =
                                                        "Ritirato il " + dateFormat(del.date_Update)
                                                    imageModifier = Modifier.size(30.dp)
                                                    Image(
                                                        painter = painterResource(id = R.drawable.check),
                                                        contentDescription = "confermato",
                                                        modifier = imageModifier
                                                    )
                                                }

                                                else -> {
                                                    statusDel = ""
                                                    imageModifier = Modifier.size(0.dp)
                                                }
                                            }
                                        }


                                        Box(
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .width(220.dp)
                                                .wrapContentSize(Alignment.TopStart)
                                        ) {
                                            Column() {
                                                Spacer(modifier = Modifier.height(10.dp))

                                                Text(
                                                    text = "" + del.id_mittente,
                                                    textAlign = TextAlign.Left,
                                                    fontSize = 16.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )

                                                val prods: Map<String, Int> =
                                                    del.products.split(',')
                                                        .map { it.split(':') }
                                                        .associate { it[0] to it[1].toInt() }


                                                prods.forEach() { item ->
                                                    //Spacer(modifier = Modifier.height(3.dp))
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        verticalAlignment = Alignment.CenterVertically

                                                    ) {

                                                        Text(
                                                            text = "${item.value} x ${item.key}",
                                                            fontSize = 15.sp,
                                                            textAlign = TextAlign.Start,
                                                        )
                                                    }

                                                }

                                                if (del.status == "inProgress") {
                                                    Text(
                                                        text = "In preparazione",
                                                        textAlign = TextAlign.Left,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.Black
                                                    )
                                                }
                                                if (del.status == "toLocker") {
                                                    Text(
                                                        text = "In consegna",
                                                        textAlign = TextAlign.Left,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.Yellow
                                                    )
                                                }
                                                if (del.status == "leftInLocker") {
                                                    if(del.rejected=="") {
                                                        Text(
                                                            text = "Pronto per il ritiro",
                                                            textAlign = TextAlign.Left,
                                                            fontSize = 14.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.Green
                                                        )
                                                    }
                                                    else
                                                    {
                                                        Text(
                                                            text = "Superato tempo massimo",
                                                            textAlign = TextAlign.Left,
                                                            fontSize = 14.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.Red
                                                        )
                                                    }

                                                }
                                                if (del.status == "taken") {
                                                    Text(
                                                        text = "Ritirato",
                                                        textAlign = TextAlign.Left,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.DarkGray
                                                    )
                                                }
                                                if (del.status == "rejected") {
                                                    Text(
                                                        text = "Rifiutato",
                                                        textAlign = TextAlign.Left,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.Red
                                                    )
                                                }
                                            }

                                        }
                                        Box(
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .width(300.dp)
                                                .wrapContentSize()
                                        ) {
                                            Text(
                                                text = "€" + formatCurrency(del.price),
                                                modifier = Modifier
                                                    .padding(5.dp),
                                                //textAlign = TextAlign.Right,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }

                            }
                        }
                    }


                        }
                       }
                    }

                    if(isEmpty && chip!="")
                    {
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(
                            modifier = Modifier
                                .padding(start = 16.dp, end = 16.dp)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        )
                        {
                            Row()
                            {  val text = "Nessun ordine nello stato '$chip'."

                                val annotatedString = buildAnnotatedString {
                                    append(text)
                                    addStyle(
                                        style = SpanStyle(fontWeight = FontWeight.Bold),
                                        start = 25,
                                        end = text.length-1
                                    )
                                }

                                Text(text = annotatedString) }
                        }
                    }
                }
            }
        }
    }

    if (rejected) {
        AlertDialog(
            modifier = Modifier.wrapContentSize(),
            onDismissRequest = { rejected = false },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text(
                        text = "Siamo spiacenti, l'ordine non è stato confermato!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                    )
                    Spacer(modifier = Modifier.height(18.dp))

                    if (viewModel.currentDelivery.value?.rejected?.contains("Alcuni prodotti non sono attualmente disponibili") == true) {
                        val parts = viewModel.currentDelivery.value?.rejected?.split(":")
                        val mot = parts?.get(0)
                        val other = parts?.get(1)

                        Text(
                            text = "${mot}",
                            fontSize = 16.sp,
                        )

                        Text(
                            text = "${other}",
                            fontSize = 16.sp,
                        )
                    } else {
                        Text(
                            text = "${viewModel.currentDelivery.value?.rejected}",
                            fontSize = 16.sp,
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    Text(
                        text = "Chiama ${viewModel.currentDelivery.value?.id_mittente}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                    )

                    var num = ""

                    viewModel.sellers.forEach() { s ->
                        if (s.name == viewModel.currentDelivery.value?.id_mittente)
                            num = s.number
                    }
                    Spacer(modifier = Modifier.height(1.dp))
                    Text(
                        text = "$num",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                    )

                }
            },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = { rejected = false }
                ) {
                    Text("OK")
                }
            },

            )
    }
    }
    if (showEmpty) {
        AlertDialog(
            onDismissRequest = { showEmpty = false },
            text = { Text("Il tuo carrello è ancora vuoto!") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = { showEmpty = false }
                ) {
                    Text("Continua")
                }
            }
        )

    }
}








