package it.polito.laib_3.registration

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick


//per scegliere il ruolo (cliente o commerciante) al momneto della registrazione
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectRoleScreen(navController: NavController, viewModel: PurchaseViewModel) {


    Scaffold(
        /*topBar = {
            TopAppBar(
                title = { Text(text = "Registrazione") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    //containerColor = Color.Black,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.LoginScreen.route) }) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },*/
        /*bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },*/

        ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
                ) {

                Spacer(modifier = Modifier.height(70.dp))
                Image(
                    modifier=Modifier.height(150.dp).width(150.dp),
                    painter = painterResource(id = R.drawable.logo_scritta_goodbuy),
                    contentDescription = null,
                )
                Spacer(modifier = Modifier.height(35.dp))
                Row() {
                    Text(
                        text = "Registrazione",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }
                Spacer(modifier = Modifier.height(35.dp))
                Row() {
                    Text(
                        text = "Scegli come vuoi utilizzare l'app:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }
                /*Row() {
                    Text(
                        text = "GoodBuy come...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }*/

                Spacer(modifier = Modifier.height(20.dp))

                Row() {
                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(150.dp),
                        shape = RoundedCornerShape(10.dp),
                        //border = BorderStroke(2.dp, Color.Black),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                        //   shape = RoundedCornerShape(10.dp),
                        onClick = { navController.navigate(Screen.RegisterSellerScreen.route) },
                    ) {
                        Text(text = "Commerciante",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.width(30.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(150.dp),
                        shape = RoundedCornerShape(10.dp),
                        //border = BorderStroke(2.dp, colorResource(id = R.color.green)),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                        //   shape = RoundedCornerShape(10.dp),
                        onClick = { navController.navigate(Screen.RegisterUserScreen.route) },
                    ) {
                        Text(text = "Cliente",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(105.dp))
                Text(
                    text = "Hai già un account?",
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "Accedi",
                    textDecoration = TextDecoration.Underline,
                    modifier = Modifier.clickable { navController.navigate(Screen.LoginScreen.route) },
                    color = colorResource(id = R.color.green)
                )

                }
            }


        }
    }
