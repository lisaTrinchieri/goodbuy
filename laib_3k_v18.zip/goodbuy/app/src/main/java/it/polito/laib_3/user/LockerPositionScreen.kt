package it.polito.laib_3.user

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LockerPositionScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    Log.d("cccc", "locker: "+viewModel.currentLocker.value)


    var selected by remember { mutableStateOf((false)) }
    var program by remember { mutableStateOf((false)) }
    var error by remember { mutableStateOf((false)) }
    var closed by remember { mutableStateOf((false)) }

    var isExpanded by remember { mutableStateOf((false)) }

    var inputError by remember { mutableStateOf((false)) }
    var day by remember { mutableStateOf("Oggi") }
    var hh by remember { mutableStateOf("") }
    var mm by remember { mutableStateOf("") }

    var back by remember { mutableStateOf((false)) }
    var route by remember { mutableStateOf("") }
//    var selected by remember { mutableStateOf((false)) }


    val address by viewModel.currentAddress.collectAsState()
    val choice by viewModel.currentHourChoice.collectAsState()



    val context = LocalContext.current

    if(viewModel.currentLocker.value?.id_locker ?:"" !="")
        selected=true
    else
        selected= false


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text="Mappa"
                ) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        navController.navigate(Screen.CartScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { route = ""+Screen.HomeUserScreen.route
                            if(viewModel.cart.isEmpty()) {
                                viewModel.clearCurrentCatProds()
                                navController.navigate(""+route)
                            }
                            viewModel.clearCurrentCatProds()
                            viewModel.clearCurrentProds()
                            back = true}) {
                            Image(
                                painter = painterResource(id = R.drawable.home),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(
                            onClick = {
                                route = ""+ Screen.UserSearchScreen.route
                                if(viewModel.cart.isEmpty()) {
                                    viewModel.clearCurrentCatProds()
                                    navController.navigate(""+route)
                                }
                                viewModel.clearCurrentCatProds()
                                viewModel.clearCurrentProds()

                                back = true
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { route = ""+Screen.OrdersUserScreen.route
                                if(viewModel.cart.isEmpty()) {
                                    viewModel.clearCurrentCatProds()
                                    navController.navigate(""+route)
                                }

                                back = true
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { route=""+Screen.UserProfileScreen.route
                            if(viewModel.cart.isEmpty()) {
                                viewModel.clearCurrentCatProds()
                                navController.navigate(""+route)
                            }
                            viewModel.clearCurrentCatProds()
                            viewModel.clearCurrentProds()
                            back = true  }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(bottom=10.dp)

        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 5.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.carrello),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.White),
                            modifier = Modifier.size(23.dp)
                        )

                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight/2),
                                end = Offset(x = 0f, y = canvasHeight/2),
                                color = Color.White,
                                strokeWidth = 3F
                            )
                        }

                            Image(
                                painter = painterResource(id = R.drawable.pin),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )

                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight/2),
                                end = Offset(x = 0f, y = canvasHeight/2),
                                color = Color.Gray,
                                strokeWidth = 1F
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.wallet),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.Gray),
                            modifier = Modifier.size(23.dp)
                        )

                    }

                    Spacer(modifier = Modifier.height(15.dp))

                    Text(
                        text = "Seleziona un locker dalla mappa",
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(modifier = Modifier.height(10.dp))


                    viewModel.lockersList.forEach(){lock->
                        var address = lock.spaces[0].address

                        if(viewModel.currentShop.value?.lockers?.contains(address) == true && !viewModel.actualLockers.contains(lock))
                            viewModel.addActualLocker(lock)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Box()
                    {

                        Image(
                            painter = painterResource(id = R.drawable.mappa),
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(250.dp)

                        )

                        viewModel.actualLockers.forEach { lock ->

                            var available = false
                            var piccola = 0
                            var media = 0
                            var grande = 0

                            viewModel.cart.forEach() { prod ->

                                if (prod.key.dimension == "Piccola")
                                    piccola = piccola + prod.value
                                if (prod.key.dimension == "Media")
                                    media = media + prod.value
                                if (prod.key.dimension == "Grande")
                                    grande = grande + prod.value

                            }


                            if (piccola < 10 && media == 0 && grande == 0)
                                viewModel.currentDimension.value = "Piccola"
                            else if (piccola < 4 && media > 0 && media < 4 && grande == 0)
                                viewModel.currentDimension.value = "Media"
                            else
                                viewModel.currentDimension.value = "Grande"

                            Log.d(
                                "delivery",
                                "locker screen delivery : " + (viewModel.currentDimension.value
                                    ?: "")
                            )


                            //implementare anche per le dimensioni
                            lock.spaces.forEach() { space ->
                                if (space.delivery=="") {
                                    if (space.dimension == viewModel.currentDimension.value)
                                        available = true
                                }
                            }

                            if (available) {
                             //   Row()
                             //   {
                                    IconToggleButton(
                                        modifier = Modifier.padding(
                                            top = lock.spaces[0].positionX.dp,
                                            start = lock.spaces[0].positionY.dp
                                        ),
                                        checked = if(viewModel.currentLocker.value == lock) true else false,
                                        //viewModel.lockersChecked.getValue(lock),
                                        onCheckedChange = { _checked ->
                                            viewModel.resetLockers()
                                            viewModel.changeSelectedLocker(lock, _checked)

                                            if (_checked) {
                                                viewModel.currentLocker.value = lock
                                                selected = true
                                                viewModel.changeAddress(lock.spaces?.get(0)?.address ?: "")

                                                Log.d("cccc", "locker: "+viewModel.currentLocker.value)

                                            } else
                                                selected = false
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.LocationOn,
                                            contentDescription = "Favorite Item",
                                            tint = if (viewModel.lockersChecked.getValue(lock)) colorResource(id = R.color.green) else Color.DarkGray // icon color
                                        )
                                    }
                              //  }
                            } else {
                             //   Row()
                             //   {
                                    IconButton(
                                        modifier = Modifier.padding(
                                            top = lock.spaces[0].positionX.dp,
                                            start = lock.spaces[0].positionY.dp
                                        ),
                                        onClick = {
                                            Toast.makeText(
                                                context,
                                                "Nessuno spazio libero",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.LocationOn,
                                            contentDescription = "Favorite Item",
                                            tint = Color.LightGray // icon color
                                        )
                                    }
                                }
                           // }

                        }
                    }


                    Spacer(modifier = Modifier.height(15.dp))

                 //   if(viewModel.currentLocker.value?.id_locker ?: "" != "")
                    if(selected){
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically

                        ) {

                            /*     viewModel.lockersList.forEach() { lock ->
                                if (lock.id_locker == viewModel.currentLocker.value?.id_locker ?: "")
                                 //   address = lock.spaces[0].address
                                  address= viewModel.currentLocker.value?.spaces?.get(0)?.address ?: ""
                            } */

                            Text(
                                text = "L'ordine sarà spedito presso il locker in: ",
                                fontSize = 16.sp,
                                //fontWeight = FontWeight.Bold
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically

                        ) {
                            Text(
                                text = "${address}.",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically

                        ) {
                            Text(
                                text = "Nessun locker selezionato al momento.",
                                fontSize = 16.sp,
                            )
                        }
                    }
                    }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement
                        .spacedBy(
                            space = 20.dp,
                            alignment = Alignment.CenterHorizontally
                        ),
                    verticalAlignment = Alignment.CenterVertically
                )
                { Box(
                        modifier = Modifier
                            .bounceClick()
                            //  .wrapContentSize(Alignment.Center)
                            .height(60.dp)
                            .width(150.dp)
                            .border(1.dp, if (choice == 1) Color.Black else Color.DarkGray)
                            .background(
                                if (choice == 1) colorResource(id = R.color.green) else Color.White,

                                )
                            .clickable {
                                viewModel.changeChoice(1)
                                program = false

                                val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
                                val current = LocalDateTime
                                    .now()
                                    .format(formatter)

                                val parts = current.split(" | ")
                                val d = parts[0]
                                val t = parts[1]


                                viewModel.currentDate.value = d

                                val tom = LocalDateTime
                                    .now()
                                    .plusMinutes(45)
                                    .format(formatter)
                                val parts2 = tom.split(" | ")
                                val timeNext = parts2[1]
                                viewModel.currentTime.value = timeNext
                            }
                    )
                {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight()
                    )
                    {
                        Row(horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth())
                        {
                            Text(
                                text = "45-60 min",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (choice==1) Color.Black else Color.DarkGray
                            )
                        }
                            Spacer(modifier = Modifier.height(2.dp))
                        Row(horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically)
                        {
                            Text(
                                text = "Il prima possibile",
                                fontSize = 11.sp,
                                color = if (choice==1) Color.Black else Color.DarkGray
                            )
                        }
                    }
                }

                    Box(
                        modifier = Modifier
                            // .wrapContentSize(Alignment.Center)
                            .bounceClick()
                            .height(60.dp)
                            .width(150.dp)
                            .border(
                                1.dp,
                                if (choice == 2 && closed) Color.Black else Color.DarkGray
                            )
                            .clickable {
                                program = true
                                closed = false
                                viewModel.changeChoice(2)
                            }
                            .background(
                                if (choice == 2 && closed) colorResource(id = R.color.green) else Color.White,
                            )

                    )
                    {
                        if((choice!=2 && !closed) || (choice!=2 && closed) || (choice==2 && !closed)) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight()
                            )
                            {
                                Row(
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxWidth()
                                )
                                {

                                    Text(
                                        text = "Programma l'ordine",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.DarkGray
                                    )
                                }
                            }
                        }
                       else if(choice==2 && closed)
                               { val orario = LocalTime.of(hh.toInt(), mm.toInt())  // 10:30

                                     val plus = orario.minusMinutes(15)  // 10:15
                                     val minus = orario.plusMinutes(15)

                                   viewModel.currentTimeChoice.value = ""+minus+" - "+plus

                                   Column(
                                       horizontalAlignment = Alignment.CenterHorizontally,
                                       verticalArrangement = Arrangement.Center,
                                       modifier = Modifier
                                           .fillMaxWidth()
                                           .fillMaxHeight()
                                   )
                                   {
                                       Row(
                                           horizontalArrangement = Arrangement.Center,
                                           verticalAlignment = Alignment.CenterVertically,
                                           modifier = Modifier.fillMaxWidth()
                                       )

                                       {
                                           Text(
                                               text = ""+viewModel.currentTimeChoice.value,
                                               fontSize = 12.sp,
                                               fontWeight = FontWeight.Bold,
                                               color = if (choice==2 && closed) Color.Black else Color.DarkGray
                                           )
                                       }
                                       Spacer(modifier = Modifier.height(2.dp))
                                       Row(
                                           horizontalArrangement = Arrangement.Center,
                                           verticalAlignment = Alignment.CenterVertically,
                                           modifier = Modifier.fillMaxWidth()
                                       )
                                       {
                                           Text(
                                               text = "" + day,
                                               fontSize = 11.sp,
                                               color = if (choice==2 && closed) Color.Black else Color.DarkGray
                                           )
                                       }
                                   }
                        }

                    }



                }



                    Spacer(modifier = Modifier.height(40.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(120.dp),
                        onClick = {

                           // if(!selected || (!highlighted1 && !highlighted2))
                            if(choice!=1 && choice!=2)
                                error =true

                       /*     var currentLocker=""
                            currentLocker = viewModel.currentLocker.value?.id_locker ?: ""

                            if(currentLocker=="")
                                error = true */
                            if(viewModel.currentLocker.value?.id_locker ?: "" == "")
                                error=true

                            if(!error)
                            {

                                var found = false

                                viewModel.currentLocker.value?.spaces?.forEach() { space ->
                                  if (space.delivery =="" && space.dimension == viewModel.currentDimension.value) {
                                    if (!found) {
                                        viewModel.currentLockerSpace.value = space
                                        found = true
                                    }
                                  }
                                }

                                navController.navigate(Screen.PaymentScreen.route)
                           }
                                  },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                        content = { Text( text="Avanti",
                            fontSize = 16.sp ) }
                    )


                }
            }
        }
    if (error) {
        AlertDialog(
            onDismissRequest = { error = false },
            text = {
                var currentLocker=""
                currentLocker = viewModel.currentLocker.value?.id_locker ?: ""

                if(viewModel.currentLocker.value?.id_locker ?: "" == "" && (choice==1 || choice==2))
                    Text("Nessun locker selezionato")

                if(choice!=1 && choice!=2 && viewModel.currentLocker.value?.id_locker ?: "" != "")
                    Text("Nessun orario selezionato")

                if(viewModel.currentLocker.value?.id_locker ?: "" == "" && choice!=1 && choice!=2)
                    Text("Nessun locker e orario selezionato")


                 },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = { error = false }
                ) {
                    Text("OK")
                }
            }
        )

    }

    if (program) {
        AlertDialog(
            modifier = Modifier.wrapContentSize(),
            onDismissRequest = { program = false },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Programma l'ordine",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                    )
                    Spacer(modifier = Modifier.height(30.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 2.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                        verticalAlignment = Alignment.CenterVertically,
                    )
                    {
                        ExposedDropdownMenuBox(
                            modifier = Modifier
                                .width(142.dp)
                                .padding(end = 15.dp),
                            expanded = isExpanded,
                            onExpandedChange = { isExpanded = !isExpanded }
                        ) {
                            TextField(
                                value = day,
                                onValueChange = { },
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                },
                                placeholder = {
                                    Text(text = "Oggi")
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier
                                    .menuAnchor()
                                    .width(142.dp),
                            )
                            ExposedDropdownMenu(
                                expanded = isExpanded,
                                onDismissRequest = { isExpanded = !isExpanded }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(text = "Oggi") },
                                    onClick = {
                                        day = "Oggi"
                                        isExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(text = "Domani") },
                                    onClick = {
                                        day = "Domani"
                                        isExpanded = false

                                    }
                                )


                            }

                        }


                        OutlinedTextField(
                            modifier = Modifier.width(63.dp),
                            value = hh,
                            onValueChange = { newText ->
                                if (newText.length <= 2) { // Limite massimo di 10 caratteri
                                    hh = newText
                                }
                            },
                            placeholder = { Text(text = "00", color = Color.LightGray) },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                        )
                        Text(
                            text = ":",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                        )

                        OutlinedTextField(
                            modifier = Modifier.width(63.dp),
                            value = mm,
                            onValueChange = { newText ->
                                if (newText.length <= 2) { // Limite massimo di 10 caratteri
                                    mm = newText
                                }
                            },
                            placeholder = { Text(text = "00", color = Color.LightGray) },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                        )


                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }

            },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = {
                        if (hh.length == 1)
                            hh = "0" + hh
                        if (mm.length == 1)
                            mm = "0" + mm

                        if (mm.toInt() > 59 || hh.toInt() > 23) {
                            inputError = true
                            Toast.makeText(context, "Errore orario inserito", Toast.LENGTH_SHORT)
                                .show()
                        }

                        if(!inputError) {
                            val orarioCorrente = LocalTime.now()
                            val orarioInserito = LocalTime.of(hh.toInt(), mm.toInt())
                            val isPrecedente = orarioInserito.isBefore(orarioCorrente)
                            if (isPrecedente && day == "Oggi") {
                                inputError = true
                                Toast.makeText(
                                    context,
                                    "Orario inserito precedente",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        if (!inputError) {
                            program = false

                            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
                            val current = LocalDateTime.now().format(formatter)

                            val parts = current.split(" | ")
                            val d = parts[0]
                            val t = parts[1]

                            if (day == "Oggi")
                                viewModel.currentDate.value = d
                            else {
                                val tom = LocalDateTime.now().plusDays(1).format(formatter)
                                val parts2 = tom.split(" | ")
                                val dateTom = parts2[0]
                                viewModel.currentDate.value = dateTom
                            }

                            viewModel.currentTime.value = hh + ":" + mm
                            closed = true

                        }
                        inputError = false
                    }
                ) {
                    Text("Conferma")
                }
            },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = {
                        program = false
                        inputError = false
                        day = "Oggi"
                        hh = "00"
                        mm = "00"
                        viewModel.changeChoice(0)
                        closed = true
                    }
                ) {
                    Text("Annulla")
                }
            }

        )
    }
    }

    if (back && !viewModel.cart.isEmpty()) {
        AlertDialog(
            onDismissRequest = { back = false },
            text = { Text("Sei sicuro di voler tornare indietro? Il tuo carrello non verrà salvato") },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = { back = false }
                ) {
                    Text("Annulla")
                }
            },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = { back = false
                        viewModel.clearCart()
                        viewModel.clearActualLockers()
                        viewModel.clearCurrentCatProds()

                        viewModel.currentDimension.value = ""
                        viewModel.totalPrice.value = 0.0
                        viewModel.currentShop.value=null
                        viewModel.currentLocker.value = null
                        viewModel.currentLockerSpace.value=null
                        viewModel.currentDate.value = ""
                        viewModel.currentTime.value = ""
                        viewModel.currentTimeChoice.value = ""
                        viewModel.currentDelivery.value=null
                        viewModel.credit.value=false

                        viewModel.changeChoice(0)
                        viewModel.changeAddress("")


                        navController.navigate(""+route)
                    }
                ) {
                    Text("OK")
                }
            }
        )

    }
}
