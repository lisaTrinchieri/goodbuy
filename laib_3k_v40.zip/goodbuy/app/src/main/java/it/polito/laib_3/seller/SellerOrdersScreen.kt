package it.polito.laib_3.seller


import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.Consegna
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.dateFormat
import it.polito.laib_3.formatCurrency
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SellerOrdersScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    subscribeSeller(viewModel)

    var show by remember { mutableStateOf(false) }

    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
    val current = LocalDateTime.now().format(formatter)

    val parts1 = current.split(" | ")
    val date = parts1[0]
    val time = parts1[1]
    val primetime = FontFamily(Font(R.font.primetime))

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "GOODBUY", fontFamily = primetime) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                actions = {
                    var count = 0
                    viewModel.deliveries.forEach(){del ->
                        if(del.status == "started" && del.id_mittente== viewModel.currentSeller.value?.name ?: "")
                            count++
                    }
                    if(count > 0)
                    {
                        BadgedBox(
                            modifier = Modifier.wrapContentSize().padding(end=20.dp),
                            badge = { Badge(
                                containerColor = Color.Red,
                                contentColor = Color.White
                            ) { Text("$count") } })
                        {
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                modifier = Modifier.clickable { navController.navigate(Screen.OrdersStartedScreen.route) },
                                tint = Color.White,)
                        }
                    }
                    else
                    {
                        IconButton(onClick = { navController.navigate(Screen.OrdersStartedScreen.route) }) {
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                tint = Color.White,)
                        }
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(  modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),)
                    {

                        IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerLockerScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.lock),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerOrdersScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.SellerProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        //   .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Storico ordini",
                            fontWeight = FontWeight.Bold,
                            fontSize = 25.sp,
                        )

                    }

                    Spacer(modifier = Modifier.height(10.dp))


                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                    var empty = true

                    viewModel.deliveries.forEach() { del ->
                        if ((del.status == "leftInLocker" || del.status == "taken" || del.status == "rejected") && del.id_mittente == viewModel.currentSeller.value?.name ?: "")
                            empty = false

                        if (del.rejected == "superato tempo massimo" && del.date_Due != date && del.status!="leftInLocker") {
                            var code = ""

                            viewModel.deliveriesComplete.forEach() { delivery ->
                                if (delivery.value == del)
                                    code = delivery.key
                            }

                            //   var del = viewModel.currentDelivery.value
                            var updatedDel = del?.let {
                                Consegna(
                                    "rejected",
                                    it.date_Start,
                                    del.time_Start,
                                    date,
                                    time,
                                    del.date_Due,
                                    del.time_Due,
                                    del.id_mittente,
                                    del.id_destinatario,
                                    del.locker,
                                    del.locker_space,
                                    del.code_inserimento,
                                    del.code_sblocco,
                                    del.products,
                                    del.price,
                                    del.payment,
                                    "superato tempo massimo"
                                )
                            }

                            db.child("deliveries").child("" + code).setValue(updatedDel)
                        }
                    }

                    if (empty) {
                        Row(
                            modifier = Modifier.fillMaxWidth().background(Color.Gray),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                modifier = Modifier.padding(16.dp),
                                text = "Non sono ancora presenti ordini nello storico.",
                                fontSize = 18.sp,
                                //  textAlign = TextAlign.Left,
                            )
                        }
                    } else {
                        viewModel.deliveries.forEach() { del ->
                            if ((del.status == "leftInLocker" || del.status == "taken" || del.status == "rejected") && del.id_mittente== viewModel.currentSeller.value?.name ?: "") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Start,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Box(
                                        modifier = Modifier
                                            .height(90.dp)
                                            .background(Color.Gray)
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.currentDelivery.value = del
                                                show = true
                                            },
                                    ) {
                                        Row() {
                                            Spacer(modifier = Modifier.width(15.dp))
                                            Box(
                                                modifier = Modifier.fillMaxHeight()
                                                    .width(35.dp)
                                                    .wrapContentSize(Alignment.TopStart)
                                            ) {
                                                Image(
                                                    painter = painterResource(
                                                        id =
                                                        if (del.status == "leftInLocker" && del.rejected == "") R.drawable.armadietto
                                                        else if (del.status == "taken") R.drawable.check
                                                        else if (del.status == "leftInLocker" && del.rejected=="superato tempo per il ritiro") R.drawable.errore
                                                        else R.drawable.errore
                                                    ),
                                                    contentDescription = "confermato",
                                                    colorFilter = ColorFilter.tint(Color.Black),
                                                    modifier = Modifier.size(40.dp).padding(top=16.dp)
                                                )
                                            }

                                            Spacer(modifier = Modifier.width(12.dp))

                                            Box(
                                                modifier = Modifier.fillMaxHeight()
                                                    .width(270.dp)
                                                    .wrapContentSize(Alignment.TopStart)
                                                    .padding(16.dp)
                                            ) {
                                                Column() {
                                                    Row() {
                                                        Text(
                                                            text = if(del.id_destinatario.length>15) "" +del.id_destinatario.substring(0, minOf(15, del.id_destinatario.length)) +"..." else "" + del.id_destinatario,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 18.sp,
                                                        )
                                                    }
                                                    Row() {
                                                        if(del.status == "leftInLocker" && del.rejected=="") {
                                                            Text(
                                                                text = "Portato al locker il "+ dateFormat(del.date_Update),
                                                                fontSize = 16.sp,
                                                            )
                                                        }
                                                        else if(del.status == "leftInLocker" && del.rejected=="superato tempo per il ritiro") {
                                                            Text(
                                                                text = "Superato tempo massimo per...",
                                                                fontSize = 16.sp,
                                                            )
                                                        }
                                                        else if(del.status == "taken") {
                                                            Text(
                                                                text = "Ritirato il "+ dateFormat(del.date_Update),
                                                                fontSize = 16.sp,
                                                            )
                                                        }
                                                        else {
                                                            Text(
                                                                text = "Ordine rifiutato",
                                                                fontSize = 16.sp,
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                        }

                                    }
                                }
                                Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)
                            }

                        }
                    }
                }
            }
        }
    }


    if (show) {
        AlertDialog(
            onDismissRequest = { show = false })
        {
            Column() {
                /*Button(
                    modifier = Modifier.align(Alignment.End),
                    onClick = { show = false },
                ) {
                    Text("X")
                }*/

                Surface(
                    modifier = Modifier.wrapContentWidth().wrapContentHeight(),
                    shape = MaterialTheme.shapes.large
                ) {

                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Button(
                            onClick = { show = false },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = colorResource(id = R.color.green),
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.sizeIn(maxWidth = 120.dp, maxHeight = 50.dp).align(Alignment.End),
                        ) {
                            Text(
                                text = "Close",
                                modifier = Modifier.padding(2.dp),
                                fontSize = 15.sp,
                            )
                        }
                        Spacer(modifier = Modifier.height(15.dp))
                        val del = viewModel.currentDelivery.value

                        if (del != null) {
                            Text(
                                text = "Ordine di ${del.id_destinatario}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        var address = ""
                        viewModel.lockersList.forEach() { lock ->
                            if (del != null) {
                                if (lock.id_locker == del.locker)
                                    address = lock.spaces[0].address
                            }
                        }

                        Text(
                            text = "Locker in " + address,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                        )

                        var isPrecedente = false
                        var left=false
                        if (del != null) {
                            if ((del.status == "rejected" || del.rejected == "superato tempo massimo") && del.status!="leftInLocker")
                                isPrecedente = true
                            else if(del.status=="leftInLocker" && del.rejected=="superato tempo per il ritiro")
                                left=true
                        }


                        if (!isPrecedente && !left ) {
                            Spacer(modifier = Modifier.height(10.dp))
                            if (del != null) {
                                if (del.status == "leftInLocker") {
                                    Text(
                                        text = "Ordine in attesa di ritiro",
                                        fontSize = 16.sp,
                                    )
                                } else if (del.status == "taken") {
                                    Text(
                                        text = "Ordine ritirato il " + dateFormat(del.date_Update),
                                        fontSize = 16.sp,
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            if (del != null) {
                                val prods: Map<String, Int> = del.products.split(',')
                                    .map { it.split(':') }
                                    .associate { it[0] to it[1].toInt() }

                                prods.forEach() { item ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Text(
                                            text = "  - " + item.key + " x " + item.value,
                                            fontSize = 16.sp,
                                            textAlign = TextAlign.Start,
                                            modifier = Modifier.padding(end = 20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(5.dp))

                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            if (del != null) {
                                Text(
                                    text = "Totale:    ${formatCurrency(del.price)} €",
                                    fontSize = 16.sp,
                                )
                            }
                        } else if(isPrecedente && !left){
                            Spacer(modifier = Modifier.height(10.dp))
                            if (del != null) {
                                Text(
                                    text = "Ordine rifiutato",
                                    fontSize = 18.sp,
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            if (del != null) {
                                Text(
                                    text = ""+del.rejected,
                                    fontSize = 16.sp,
                                )
                            }
                        }
                        else if(left)
                        {
                            Spacer(modifier = Modifier.height(10.dp))
                            if (del != null) {
                                Text(
                                    text = "Consegnato il " + dateFormat(
                                        del.date_Update
                                    ),
                                    fontSize = 18.sp,
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            if (del != null) {
                                Text(
                                    //text = "Codice di ritiro: "+del.code_sblocco,
                                    text = "Superato tempo massimo per il ritiro",
                                    fontSize = 16.sp,
                                )
                            }

                        }

                    }
                }
            }
        }
        }
    }
}