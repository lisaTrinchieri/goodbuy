package it.polito.laib_3.screen

import android.annotation.SuppressLint
import android.media.MediaPlayer
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.android.volley.RequestQueue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.getValue
import it.polito.laib_3.Consegna
import it.polito.laib_3.LockerSpace
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.sendNotification
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

//schermata finale di apertura locker
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "StateFlowValueCalledInComposition")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, FCM_API:String, serverKey:String, contentType:String, requestQueue: RequestQueue, mediaPlayer: MediaPlayer) {


    val primetime = FontFamily(Font(R.font.primetime))

    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
    val current = LocalDateTime.now().format(formatter)

    val parts = current.split(" | ")
    val date = parts[0]
    val time = parts[1]

    val close by viewModel.close.collectAsState()
    val already2 by viewModel.already2.collectAsState()

    var alarmStop by remember { mutableStateOf(false) }

   // var mediaPlayer = MediaPlayer()
  //  mediaPlayer = MediaPlayer.create(LocalContext.current, R.raw.alarm)

    if(viewModel.played.value==false)
        viewModel.startAlarm(mediaPlayer, navController, ""+Screen.StopAlarm.route)



    if (viewModel.current.value != null) {
        val databaseReference: DatabaseReference =
            db.child("lockers").child("" + viewModel.current.value!!.id_locker)
        viewModel.startListening(databaseReference, mediaPlayer)
    }





    Log.d("cccc", "listener close : " + close)

    if (close && !already2) {
        if (viewModel.status.value == "left") {

            db.child("deliveries").child("" + (viewModel.currentDel.value ?: ""))
                .setValue(viewModel.actualDel.value)

            val topic =
                "/topics/USER${viewModel.currentDel.value?.drop(1)}" //topic has to match what the receiver subscribed to

            val notification = JSONObject()
            val notifcationBody = JSONObject()


            try {
                notifcationBody.put("title", "Goodbuy")
                notifcationBody.put(
                    "message",
                    "Il tuo ordine presso ${viewModel.actualDel.value?.id_mittente} è stato portato al " +
                            "locker di ${viewModel.current.value!!.spaces[0].address}."
                )

                notification.put("to", topic)
                notification.put("data", notifcationBody)
                Log.e("ccccccccc", "try")
            } catch (e: JSONException) {
                Log.e("ccccccc", "onCreate: " + e.message)
            }

            sendNotification(notification, FCM_API, serverKey, contentType, requestQueue)
            viewModel.already2.value = true

            navController.navigate(Screen.EndScreen.route)
            viewModel.played.value=true



        }
/////////////////////////////////////////////////
        if (viewModel.status.value == "taken") {

            db.child("deliveries").child("" + viewModel.currentDel.value)
                .setValue(viewModel.actualDel.value)

            val topic = "/topics/SELLER${viewModel.currentDel.value?.drop(1)}"

            val notification = JSONObject()
            val notifcationBody = JSONObject()

            try {
                notifcationBody.put("title", "Goodbuy")
                notifcationBody.put(
                    "message",
                    "L'ordine è stato ritirato dal " + "locker di ${viewModel.current.value!!.spaces[0].address}."
                )
                notification.put("to", topic)
                notification.put("data", notifcationBody)
                Log.e("ccccccccc", "try")
            } catch (e: JSONException) {
                Log.e("ccccccc", "onCreate: " + e.message)
            }

            sendNotification(notification, FCM_API, serverKey, contentType, requestQueue)
            viewModel.already2.value = true


            navController.navigate(Screen.EndScreen.route)
            viewModel.played.value=true

        }
    }


    Scaffold(
        /*topBar = {
            TopAppBar(
                title = { Text(text = "GOODBUY", fontFamily = primetime) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
            )

        },*/


    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
            Column(
                modifier = Modifier
                    .padding(innerPadding),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Favorite Item",
                        )
                        Spacer(modifier = Modifier.width(25.dp))
                        Text(
                            text = "" + (viewModel.current.value?.spaces?.get(0)?.address ?: ""),
                            fontSize = 22.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }
                    Spacer(modifier = Modifier.height(20.dp))

                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)
                    Spacer(modifier = Modifier.height(60.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        Text(
                            text = "A breve il tuo sportello si aprirà, fai un passo indietro",
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }


                }

                Spacer(modifier = Modifier.height(50.dp))

                if (viewModel.currentSpace.value?.name != "") {
                    Row(
                        modifier = Modifier.height(150.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            modifier = Modifier
                                .height(150.dp)
                                .width(150.dp),
                            painter = painterResource(
                                id = if (viewModel.currentSpace.value?.name ?: "" == "slot1") R.drawable.slot1
                                else if (viewModel.currentSpace.value?.name ?: "" == "slot2") R.drawable.slot2
                                else R.drawable.slot3
                            ),
                            contentDescription = null,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(50.dp))

                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ricordati di chiudere lo sportello",
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }

                }


                }
            }
        }
    }
