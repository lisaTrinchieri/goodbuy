package it.polito.laib_3

import android.annotation.SuppressLint
import android.app.Activity
import android.media.MediaPlayer
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.android.volley.RequestQueue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.screen.EndScreen
import it.polito.laib_3.screen.KeypadScreen
import it.polito.laib_3.screen.LoginScreen
import it.polito.laib_3.screen.ResultScreen
import it.polito.laib_3.screen.SplashScreen
import it.polito.laib_3.screen.StartScreen
import it.polito.laib_3.screen.StopAlarm


@RequiresApi(Build.VERSION_CODES.O)
@Composable
//fun Navigation(db: DatabaseReference) {
fun Navigation(viewModel : PurchaseViewModel, db: DatabaseReference, auth:FirebaseAuth, FCM_API:String, serverKey:String, contentType:String, requestQueue: RequestQueue, mediaPlayer: MediaPlayer) {
    val navController = rememberNavController()
    val valid by viewModel.valid.collectAsState()


    NavHost(navController = navController, startDestination = Screen.SplashScreen.route) {


        composable(Screen.SplashScreen.route) {
            SplashScreen(
                valid = valid,
                // onStart = viewModel::trackSplashScreenStarted,
                onSplashEndedValid = {

                    if(viewModel.loggedIn.value == true)
                       navController.navigate(Screen.StartScreen.route)
                    else
                        navController.navigate(Screen.LoginScreen.route)
                },
            )
        }

        composable(Screen.LoginScreen.route) { LoginScreen(navController = navController, viewModel, auth, db) }
        composable(Screen.StartScreen.route) { StartScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.KeypadScreen.route) { KeypadScreen(navController = navController, viewModel, db, auth, FCM_API, serverKey, contentType, requestQueue) }
        composable(Screen.ResultScreen.route) { ResultScreen(navController = navController, viewModel, db, FCM_API, serverKey, contentType, requestQueue, mediaPlayer) }
        composable(Screen.StopAlarm.route) { StopAlarm(navController = navController, viewModel, mediaPlayer, db, FCM_API, serverKey, contentType, requestQueue) }

        composable(Screen.EndScreen.route) { EndScreen(navController = navController, viewModel) }

    }

}


@Composable
fun InputDots(numbers: String) {  //= listOf(1, 2, 3, 4),
    //1st way
    Row(
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        for (i in 0..3) {
            PinIndicator(
                filled = when (i) {
                    0 -> numbers.isNotEmpty()
                    else -> numbers.length > i
                }
            )
        }
    }
}

@Composable
private fun PinIndicator(filled: Boolean, ) {
    Box(
        modifier = Modifier
            .padding(15.dp)
            .size(15.dp)
            .clip(CircleShape)
            .background(if (filled) Color.Black else Color.Transparent)
            .border(2.dp, Color.Black, CircleShape)
    )
}


@Composable
fun buttonShape(viewModel: PurchaseViewModel, content : String, navController: NavController) {

        OutlinedButton(
            modifier = Modifier
                .height(75.dp)
                .width(75.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor =  Color.Black),
            shape = CircleShape,
            border= BorderStroke(1.dp, Color.DarkGray),
            onClick = { viewModel.code = viewModel.code + ""+content
                        viewModel.stopTimer()
                        viewModel.startTimer(navController, ""+Screen.StartScreen.route)
                      Log.d("AAA", "VIEWMODELCODE : "+viewModel.code)},
            content = {
                Text(
                    text = ""+content,
                    fontSize = 20.sp
                )
            }
        )

}


