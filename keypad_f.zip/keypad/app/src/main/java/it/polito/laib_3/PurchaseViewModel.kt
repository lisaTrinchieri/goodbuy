package it.polito.laib_3

import android.annotation.SuppressLint
import android.os.CountDownTimer
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PurchaseViewModel : ViewModel() {

    private val _valid : MutableStateFlow<Boolean?> = MutableStateFlow(null)
    val valid : StateFlow<Boolean?> = _valid

    var loggedIn= MutableLiveData<Boolean>()

    var code by mutableStateOf("")

    var open = MutableStateFlow(false)

    var already2 = MutableStateFlow(false)


    var current= MutableLiveData<Locker>()
    var currentSpace= MutableLiveData<LockerSpace>()
    var status= MutableLiveData<String>()
    var currentDel= MutableLiveData<String>()
    var newDel= MutableLiveData<Consegna>()
    var actualDel= MutableLiveData<Consegna>()
    var correct= MutableLiveData<Boolean>()

    fun clearNewDel(){
        actualDel.value = null
    }

    private var _deliveries: MutableMap<String, Consegna> = mutableStateMapOf()
    val deliveries: Map<String, Consegna> = _deliveries


    var close = MutableStateFlow(false)
    fun checkClose()
    {
        current.value?.spaces?.forEach() { space ->
            if(space.name == currentSpace.value?.name ?: "")
                if(!space.open)
                    close.value = true
        }
    }



    fun addDel(id: String, del: Consegna){
        _deliveries.put(id, del)
    }

    fun clearDel() {
        _deliveries.clear()
    }

    fun startThreadLogin() {
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                delay(3000)
            }
            closeDialogLogin()
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private fun closeDialogLogin() {
        open.value = false
    }

    fun startThread(route : String, navController: NavController) {
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                delay(6000)
            }

            closeDialog(route, navController)
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private fun closeDialog(route : String, navController: NavController) {

        Log.d("cccc", "vmstarted")
        navController.navigate(""+route)

        code = ""
        status.value = ""
        clearDel()
        currentDel.value=""
        currentSpace.value=null
        current.value = null
        already2.value = false

        close.value=false
    }




fun startListening(db:DatabaseReference) {
    // Avvia un'attività di coroutine per ascoltare lo stato dei dati ogni tot di tempo
    viewModelScope.launch {
        // Aggiungi un listener per i cambiamenti dei figli del nodo "locker1"
        db.addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                // Nessuna azione necessaria qui, ma puoi gestire l'aggiunta di nuovi figli se necessario
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                // Il valore di un figlio è cambiato
             //   Log.d("cccc", "snapshot "+snapshot.key)
             //   Log.d("cccc", "snapshot "+ (currentSpace.value?.name ?: "aaa"))
                if (snapshot.key == currentSpace.value?.name) {
                    // Controlla se il figlio è "slot1"
                    var openValue : Boolean
                    openValue= snapshot.child("open").getValue(Boolean::class.java) == true
                    // Aggiorna lo stato con il nuovo valore di "open"
                    Log.d("cccc", "snapshot open "+ openValue)
                    if(openValue)
                       openState(openValue)
                    else
                        closeState(openValue)
               }
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
            }

            override fun onCancelled(error: DatabaseError) {
            }
        })
    }
   }

    private fun closeState(openValue: Boolean?) {

   // Log.d("cccc", "open viewModel : "+openValue)
    close.value = true
}
    fun openState(openValue: Boolean?) {
        close.value = false
    }


    private var countDownTimer: CountDownTimer? = null
    var already= MutableLiveData<Boolean>(false)


    fun startTimer(navController: NavController, route: String) {
        countDownTimer = object : CountDownTimer(15000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                // Ogni secondo
            }

            override fun onFinish() {
                // Se il timer finisce senza interazioni dall'utente, torna alla schermata di benvenuto
                if(!already.value!!)
                {    navController.navigate(""+route)
                     already.value = true
                     stopTimer()
                }
            }
        }.start()
    }

    fun stopTimer() {
        countDownTimer?.cancel()
    }

}





