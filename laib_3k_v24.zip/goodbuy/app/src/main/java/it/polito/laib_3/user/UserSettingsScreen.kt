package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.User
import it.polito.laib_3.bounceClick


@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSettingsScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    var changeP by remember { mutableStateOf((false)) }
    var changeN by remember { mutableStateOf((false)) }
    var error by remember { mutableStateOf((false)) }

    val context = LocalContext.current

    var tel by remember { mutableStateOf(("")) }
    var pwd by remember { mutableStateOf(("")) }

    var correct by remember { mutableStateOf((false)) }
    var already by remember { mutableStateOf((false)) }


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Impostazioni") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    //email
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            text = "${viewModel.currentUser.value?.email}",
                            fontSize = 17.sp,
                            textAlign = TextAlign.Start,
                        )
                    }


                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            text = "Credito:  €${viewModel.currentUser.value?.credito}",
                            fontSize = 17.sp,
                            textAlign = TextAlign.Start,
                        )
                    }

                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                    //telefono
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.fillMaxHeight().width(290.dp),
                            contentAlignment = Alignment.CenterStart
                        )
                        {
                            Text(
                                text = "Modifica numero di telefono",
                                fontSize = 16.sp,
                                fontWeight = if (changeN) FontWeight.Bold else FontWeight.Normal,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                        val arrowIcon =
                            if (changeN) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown
                        Spacer(modifier = Modifier.width(30.dp))
                        Box(
                            modifier = Modifier.fillMaxHeight().width(40.dp),
                            contentAlignment = Alignment.CenterStart
                        )
                        {
                            Icon(
                                imageVector = arrowIcon,
                                contentDescription = null,
                                modifier = Modifier.clickable {
                                    changeN = !changeN
                                    changeP = false
                                }
                            )
                        }

                    }
                    AnimatedVisibility(
                        visible = changeN,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            //    horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically

                            ) {
                                Text(
                                    text = "Inserisci nuovo numero di telefono: ",
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Start,
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                OutlinedTextField(
                                    value = tel,
                                    onValueChange = { newText ->
                                        tel = newText
                                    },
                                    placeholder = {
                                        Text(text = "Es. 011145678", color = Color.LightGray)
                                    },
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Phone,
                                        imeAction = ImeAction.Done
                                    ),
                                )

                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                OutlinedButton(
                                    modifier = Modifier.wrapContentSize(),
                                    onClick = {

                                        if (tel != "") {
                                            if (tel == viewModel.currentUser.value?.number ?: "")
                                                already = true

                                            if (!already) {
                                                val user = viewModel.currentUser.value
                                                var id = ""

                                                viewModel.usersComplete.forEach() { u ->
                                                    if (u.value == viewModel.currentUser.value)
                                                        id = u.key
                                                }

                                                val newUser = user?.let {
                                                    User(
                                                        user.username,
                                                        it.password,
                                                        user.email,
                                                        tel,
                                                        user.credito
                                                    )
                                                }

                                                db.child("users").child(id).setValue(newUser)
                                                    .addOnCompleteListener { task ->
                                                        if (task.isSuccessful) {
                                                            correct = true
                                                            changeN = false
                                                        } else {
                                                            error = true
                                                        }
                                                    }

                                                tel = ""
                                            }


                                        }
                                    },
                                    shape = RectangleShape,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = colorResource(id = R.color.green),
                                        contentColor = Color.Black
                                    ),
                                ) {

                                    Text(
                                        text = "Conferma",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Start,
                                    )
                                }
                            }

                        }
                    }

                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.fillMaxHeight().width(290.dp),
                            contentAlignment = Alignment.CenterStart
                        )
                        {
                            Text(
                                text = "Modifica password",
                                fontSize = 16.sp,
                                fontWeight = if (changeP) FontWeight.Bold else FontWeight.Normal,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(30.dp))
                        val arrowIcon =
                            if (changeP) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown
                        Box(
                            modifier = Modifier.fillMaxHeight().width(40.dp),
                            contentAlignment = Alignment.CenterStart
                        )
                        {
                            Icon(
                                imageVector = arrowIcon,
                                contentDescription = null,
                                modifier = Modifier.clickable {
                                    changeP = !changeP
                                    changeN = false
                                }
                            )
                        }

                    }
                    AnimatedVisibility(
                        visible = changeP,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            //    horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Inserisci nuova password: ",
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Start,
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                OutlinedTextField(
                                    value = pwd,
                                    onValueChange = { newText ->
                                        pwd = newText
                                    },
                                    placeholder = {
                                        Text(text = "")
                                    },
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Password,
                                        imeAction = ImeAction.Done
                                    ),
                                )

                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                OutlinedButton(
                                    modifier = Modifier.wrapContentSize(),
                                    onClick = {

                                        if (pwd != "") {

                                            if (pwd == viewModel.currentUser.value?.password ?: "")
                                                already = true

                                            if (!already) {
                                                Toast.makeText(
                                                    context,
                                                    "Aggiornamento...",
                                                    Toast.LENGTH_SHORT
                                                ).show()

                                                val user = viewModel.currentUser.value
                                                var id = ""

                                                viewModel.usersComplete.forEach() { u ->
                                                    if (u.value == viewModel.currentUser.value)
                                                        id = u.key
                                                }

                                                val newUser = user?.let {
                                                    User(
                                                        user.username,
                                                        pwd,
                                                        user.email,
                                                        it.number,
                                                        user.credito
                                                    )
                                                }


                                                //  db.child("users").child(id).setValue(newUser)
                                                /*    authentic.currentUser?.updatePassword(pwd)
                                                ?.addOnCompleteListener { task ->

                                                    if (task.isSuccessful) {
                                                        Log.d("aaa", "FIREbase update success")
                                                        db.child("users").child(id).setValue(newUser)
                                                    } else {


                                                    }
                                                }  */
                                                val credential =
                                                    viewModel.currentUser.value?.let {
                                                        EmailAuthProvider.getCredential(
                                                            it.email + ".user",
                                                            viewModel.currentUser.value!!.password
                                                        )
                                                    }
                                                if (credential != null) {
                                                    authentic.currentUser?.reauthenticate(credential)
                                                        ?.addOnCompleteListener() { task ->
                                                            if (task.isSuccessful) {
                                                                authentic.currentUser?.updatePassword(
                                                                    pwd
                                                                )
                                                                    ?.addOnCompleteListener { task ->
                                                                        Log.d(
                                                                            "aaa",
                                                                            "FIREbase reath success success"
                                                                        )

                                                                        if (task.isSuccessful) {
                                                                            Log.d(
                                                                                "aaa",
                                                                                "FIREbase update success"
                                                                            )
                                                                            db.child("users")
                                                                                .child(id)
                                                                                .setValue(newUser)
                                                                            correct = true
                                                                            pwd = ""
                                                                            changeP = false
                                                                        } else {
                                                                            error=true
                                                                            Log.d(
                                                                                "aaa",
                                                                                "FIREbase password update NOT success"
                                                                            )
                                                                        }
                                                                    }
                                                            } else {

                                                                Log.d(
                                                                    "aaa",
                                                                    "FIREbase reauth update NOT success"
                                                                )
                                                            }

                                                        }
                                                }
                                            }
                                        }
                                    },
                                    shape = RectangleShape,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = colorResource(id = R.color.green),
                                        contentColor = Color.Black
                                    ),
                                ) {

                                    Text(
                                        text = "Conferma",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Start,
                                    )
                                }
                            }

                        }
                    }
                    Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                }


            }
        }

        if(error)
        {
            AlertDialog(
                onDismissRequest = { error = false },
                text = { Text("Non è stato possibile effettuare la modifica. Si prega di riprovare più tardi") },
                confirmButton = {
                    Button(
                        modifier = Modifier.bounceClick(),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                        onClick = {

                            error = false

                            pwd = ""
                            tel=""
                            changeP=false
                            changeN=false
                        }
                    ) {
                        Text("OK")
                    }
                }
            )

        }

        if (correct) {
            AlertDialog(
                onDismissRequest = { correct = false },
                text = { Text("Aggiornamento avvenuto correttamente") },
                confirmButton = {
                    Button(
                        modifier = Modifier.bounceClick(),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = colorResource(id = R.color.green),
                            contentColor = Color.Black
                        ),
                        onClick = { correct = false }
                    ) {
                        Text("OK")
                    }
                }
            )

        }
        if (already) {
            AlertDialog(
                onDismissRequest = { already = false },
                text = { Text("Nessuna modifica è stata effettuata") },
                confirmButton = {
                    Button(
                        modifier = Modifier.bounceClick(),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = colorResource(id = R.color.green),
                            contentColor = Color.Black
                        ),
                        onClick = { already = false }
                    ) {
                        Text("OK")
                    }
                }
            )

        }
    }
}
