package it.polito.laib_3.seller

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.DismissDirection
import androidx.compose.material.DismissValue
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.FractionalThreshold
import androidx.compose.material.SwipeToDismiss
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.rememberDismissState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.Consegna
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.formatCurrency
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersStartedScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
    val current = LocalDateTime.now().format(formatter)

    val parts1 = current.split(" | ")
    val date = parts1[0]
    val time = parts1[1]

    val tom = LocalDateTime.now().plusDays(1).format(formatter)
    val parts2 = tom.split(" | ")
    val dateTom = parts2[0]




    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Ordini da confermare") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                        Icon(
                            imageVector =  Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(  modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),)
                    {

                        IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerLockerScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.lock),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.SellerOrdersScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.SellerProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.LightGray)
                        )
                        {
                            Text(
                                text = "OGGI",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                            )
                        }

                    }

                    Divider(color = Color.DarkGray, thickness = 2.dp)

                    var empty = true

                    viewModel.deliveries.forEach() { del ->
                        if(del.status == "started" && del.date_Due==date && del.id_mittente == viewModel.currentSeller.value?.name ?: "")
                            empty = false
                    }

                    if(empty)
                    {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ){
                            Text(
                                text = "Non sono presenti ordini da preparare per oggi." ,
                                fontSize = 16.sp,
                                //  textAlign = TextAlign.Left,
                            )
                        }
                    }
                    else {
                        viewModel.deliveries.forEach() { del ->
                            //   if(del.id_mittente== viewModel.currentSeller.value?.name ?: "")
                            //   {
                            if (del.status == "started" && del.date_Due == date && del.id_mittente == viewModel.currentSeller.value?.name ?: "") {

                                val oraActual = LocalTime.now()
                                val delHour = del.time_Due.split(":")
                                val hh = delHour[0]
                                val mm = delHour[1]

                                val delHour2 = LocalTime.of(hh.toInt(), mm.toInt())
                                val isPrecedente = delHour2.isBefore(oraActual)


                                deliveryItem(
                                    del = del,
                                    viewModel = viewModel,
                                    date,
                                    time,
                                    db,
                                    "oggi", isPrecedente
                                )
                                Divider(color = Color.DarkGray, thickness = 2.dp)  }
                        }
                    }


                    //DOMANI
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.LightGray)

                        )
                        {
                            Text(
                                text = "DOMANI",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                            )
                        }
                    }

                    Divider(color = Color.DarkGray, thickness = 2.dp)


                    var emptyTom = true

                    viewModel.deliveries.forEach() { del ->
                        if(del.status == "started" && del.date_Due==dateTom && del.id_mittente == viewModel.currentSeller.value?.name ?: "")
                            emptyTom = false
                    }

                    if(emptyTom) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Non sono presenti ordini da preparare per domani.",
                                fontSize = 16.sp,
                                //  textAlign = TextAlign.Left,
                            )
                        }
                    }
                    else {

                        viewModel.deliveries.forEach() { del ->

                            if (del.status == "started" && del.date_Due == dateTom && del.id_mittente == viewModel.currentSeller.value?.name ?: "") {
                                deliveryItem(
                                    del = del,
                                    viewModel = viewModel,
                                    date,
                                    time,
                                    db,
                                    "domani", false
                                )

                                Divider(color = Color.DarkGray, thickness = 2.dp)
                            }
                        }
                    }



                }
            }

        }
    }

/*
    if (showDetail) {
        AlertDialog(
            modifier = Modifier.wrapContentSize(),
            onDismissRequest = { showDetail = false },
            text = {
                Column(){
                    var username = ""
                    viewModel.users.forEach(){u ->
                        if(u.email == viewModel.currentDelivery.value?.id_destinatario ?: "")
                            username = u.username

                    }

                    Text(text="Ordine di ${username}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,)
                    Spacer(modifier = Modifier.height(5.dp))

                    var address = ""
                    viewModel.lockersList.forEach() { lock ->
                        if (lock.id_locker == viewModel.currentDelivery.value?.locker ?: "")
                            address = lock.spaces[0].address
                    }
                    Text(text="Locker in ${address}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text="Ordine da consegnare ${viewModel.currentDay.value} entro le ${viewModel.currentDelivery.value?.time_Due}",
                        fontSize = 16.sp,)

                    Spacer(modifier = Modifier.height(5.dp))
                    Text(text="Articoli ordinati: ",
                        fontSize = 16.sp,)

                    val prods: Map<String, Int> = viewModel.currentDelivery.value?.products!!.split(',')
                        .map { it.split(':') }
                        .associate { it[0] to it[1].toInt() }


                    prods.forEach(){ item->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(
                                    text = "  - " + item.key + " x " + item.value,
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Start,
                                    modifier = Modifier.padding(end = 20.dp)
                                )
                            }

                    }

                    Spacer(modifier = Modifier.height(5.dp))
                    Text(text="Totale: ${viewModel.currentDelivery.value?.price} €",
                        fontSize = 16.sp,)

                }
            },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = { showDetail = false }

                ) {
                    Text("Annulla") }
                },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                        showDetail = false

                        var code = ""

                        viewModel.deliveriesComplete.forEach(){ delivery ->
                            if(delivery.value == viewModel.currentDelivery.value)
                                code = delivery.key
                        }

                        var del = viewModel.currentDelivery.value
                        var updatedDel = del?.let {
                            Consegna("inProgress", it.date_Start, del.time_Start, date, time, del.date_Due, del.time_Due,
                                del.id_mittente, del.id_destinatario, del.locker, del.locker_space, del.code_inserimento, del.code_sblocco, del.products,
                                del.price, del.payment)
                        }

                        db.child("deliveries").child(""+code).setValue(updatedDel)

                    }

                ) {
                    Text("Conferma")
                }
            },

        )

    } */
}


//item della shopping list da visualizzare
@SuppressLint("SuspiciousIndentation")
@OptIn(ExperimentalMaterialApi::class, ExperimentalMaterial3Api::class)
@Composable
fun deliveryItem(del: Consegna, viewModel: PurchaseViewModel, date: String, time: String, db: DatabaseReference, day: String, isPrecedente:Boolean) {

    // var removed by remember { mutableStateOf(false) }
    //  var enabled by remember { mutableStateOf(true) }
    var showAlert by remember { mutableStateOf(false) }
    var pressCancel by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    val dismissState = rememberDismissState()
    var showMotivation by remember { mutableStateOf((false)) }

    var opt1 by remember { mutableStateOf((false)) }
    var opt2 by remember { mutableStateOf((false)) }
    var opt3 by remember { mutableStateOf((false)) }
    var motivation by remember { mutableStateOf("") }

    if (dismissState.currentValue != DismissValue.Default && showAlert && pressed) {

        LaunchedEffect(Unit) {
            dismissState.reset()
            showAlert=false
            pressed = false
         //   pressed=false
        }

    }
    if (dismissState.isDismissed(DismissDirection.EndToStart) || dismissState.isDismissed((DismissDirection.StartToEnd))) {
        showAlert = true
    }

    SwipeToDismiss(
        state = dismissState,
        background = {
            val color by animateColorAsState(
                when (dismissState.targetValue) {
                    DismissValue.Default -> Color.White
                    else -> Color.LightGray
                }
            )

            val alpha: Float by animateFloatAsState(if (dismissState.targetValue == DismissValue.Default) 1f else 0.5f)


            val alignment = Alignment.CenterEnd
            val icon = Icons.Default.ArrowForward

            val scale by animateFloatAsState(
                if (dismissState.targetValue == DismissValue.Default) 1f else 1.20f
            )

            Box(
                Modifier
                    .fillMaxSize()
                    .background(color)
                    .graphicsLayer(alpha = alpha)
                    .padding(horizontal = 20.dp),
                contentAlignment = alignment
            ) {
                Icon(
                    icon,
                    contentDescription = "Delete Icon",
                    modifier = Modifier.scale(scale)
                )
            }
        },
        dismissThresholds = { FractionalThreshold(0.5f) },
        dismissContent = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ){
                Button(
                    modifier = Modifier
                        .height(105.dp)
                        .fillMaxWidth(),
                    onClick = {
                        showAlert = true
                        viewModel.currentDelivery.value = del
                        viewModel.currentDay.value = "domani"
                    },
                    shape = RectangleShape,
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                ) {

                    Box(
                        modifier = Modifier
                            .height(105.dp)
                            .width(250.dp)
                    ) {
                        Column() {
                            Spacer(modifier = Modifier.height(5.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "Favorite Item",
                                )
                                Spacer(modifier = Modifier.width(25.dp))

                                var address = ""
                                viewModel.lockersList.forEach() { lock ->
                                    if (lock.id_locker == del.locker)
                                        address = lock.spaces[0].address
                                }


                                Text(
                                    text = "" + address,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    //  textAlign = TextAlign.Left,
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                Spacer(modifier = Modifier.width(20.dp))
                                Box(
                                    modifier = Modifier
                                        .size(15.dp)
                                        .clip(CircleShape)
                                        .background(Color.Red)
                                )
                                Spacer(modifier = Modifier.width(35.dp))

                                var username = ""
                                viewModel.users.forEach(){u ->
                                    if(u.email == del.id_destinatario)
                                        username = u.username

                                }

                                Text(
                                    text = "" + username,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    //  textAlign = TextAlign.Left,
                                )
                            }
                            Row() {

                                Spacer(modifier = Modifier.width(70.dp))

                                if(!isPrecedente) {
                                    Text(
                                        text = "entro le " + del.time_Due,
                                        fontSize = 16.sp,
                                        //  textAlign = TextAlign.Left,
                                    )
                                }
                                else
                                {
                                    Text(
                                        text = "orario superato",
                                        fontSize = 16.sp,
                                        color = Color.Red
                                    )
                                }
                            }
                        }
                    }


                }
            }
        }
    )


    if (showAlert) {
        AlertDialog(
            modifier = Modifier.wrapContentSize(),
            onDismissRequest = { showAlert = false },
            text = {
                Column(){
                    var username = ""
                    viewModel.users.forEach(){u ->
                        if(u.email == del.id_destinatario)
                            username = u.username

                    }

                    Text(text="Ordine di ${username}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,)
                    Spacer(modifier = Modifier.height(5.dp))

                    var address = ""
                    viewModel.lockersList.forEach() { lock ->
                        if (lock.id_locker == del.locker)
                            address = lock.spaces[0].address
                    }
                    Text(text="Locker in ${address}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text="Ordine da consegnare ${day} entro le ${del.time_Due}",
                        fontSize = 16.sp,)

                    Spacer(modifier = Modifier.height(5.dp))
                    Text(text="Articoli ordinati: ",
                        fontSize = 16.sp,)

                    val prods: Map<String, Int> = del.products.split(',')
                        .map { it.split(':') }
                        .associate { it[0] to it[1].toInt() }


                    prods.forEach(){ item->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = "  - "+item.key+" x "+item.value,
                                fontSize = 16.sp,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.padding(end=20.dp)
                            )
                        }

                    }

                    Spacer(modifier = Modifier.height(5.dp))
                    Text(text="Totale: ${formatCurrency(del.price)} €",
                        fontSize = 16.sp,)

                    if(isPrecedente) {
                        Spacer(modifier = Modifier.height(5.dp))
                        Text(
                            text = "Ordine non più confermabile",
                            fontSize = 17.sp,
                            color = Color.Red
                        )
                    }

                }
            },


                dismissButton = {
                    if(!isPrecedente)
                    {
                    Button(
                        modifier = Modifier.bounceClick(),
                        onClick = {
                            showAlert = false
                            showMotivation = true
                        }

                    ) {
                        Text("Rifiuta")
                    }
                }
                    else
                    {
                        Button(
                            modifier = Modifier.bounceClick(),
                            onClick = {
                                showAlert = false
                                pressed = true

                                var code = ""

                                viewModel.deliveriesComplete.forEach() { delivery ->
                                    if (delivery.value == del)
                                        code = delivery.key
                                }

                                //   var del = viewModel.currentDelivery.value
                                var updatedDel = del?.let {
                                    Consegna(
                                        "rejected",
                                        it.date_Start,
                                        del.time_Start,
                                        date,
                                        time,
                                        del.date_Due,
                                        del.time_Due,
                                        del.id_mittente,
                                        del.id_destinatario,
                                        del.locker,
                                        del.locker_space,
                                        del.code_inserimento,
                                        del.code_sblocco,
                                        del.products,
                                        del.price,
                                        del.payment,
                                        "superato tempo massimo"
                                    )
                                }

                                db.child("deliveries").child("" + code).setValue(updatedDel)

                            }

                        ) {
                            Text("OK")
                        }
                    }
            },
            confirmButton = {
                if(!isPrecedente) {
                    Button(
                        modifier = Modifier.bounceClick(),
                        onClick = {
                            showAlert = false
                            pressed = true

                            var code = ""

                            viewModel.deliveriesComplete.forEach() { delivery ->
                                if (delivery.value == del)
                                    code = delivery.key
                            }

                            //   var del = viewModel.currentDelivery.value
                            var updatedDel = del?.let {
                                Consegna(
                                    "inProgress",
                                    it.date_Start,
                                    del.time_Start,
                                    date,
                                    time,
                                    del.date_Due,
                                    del.time_Due,
                                    del.id_mittente,
                                    del.id_destinatario,
                                    del.locker,
                                    del.locker_space,
                                    del.code_inserimento,
                                    del.code_sblocco,
                                    del.products,
                                    del.price,
                                    del.payment,
                                    ""
                                )
                            }

                            db.child("deliveries").child("" + code).setValue(updatedDel)

                        }

                    ) {
                        Text("Conferma")
                    }
                }
            },

            )

    }

    if (showMotivation) {
        var values = mutableListOf<Int>()
        AlertDialog(
            modifier = Modifier.wrapContentSize(),
            onDismissRequest = { showMotivation = false },
            text = {
                Column() {
                    var username = ""
                    viewModel.users.forEach() { u ->
                        if (u.email == del.id_destinatario)
                            username = u.username

                    }

                    Text(
                        text = "Perchè stai rifiutando l'ordine di ${username}?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                    )
                    Spacer(modifier = Modifier.height(5.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .clickable(onClick = {
                                opt1 = !opt1
                                opt2= false
                            opt3= false
                            motivation = ""
                            viewModel.clearAvailable()}),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier.width(220.dp)
                        )
                        {
                            Text(
                                text = "Alcuni articoli non sono disponibili",
                                fontSize = 13.sp,
                                color = if(opt1) Color.Black else Color.DarkGray,
                                fontWeight = if(opt1) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                        Box(
                            modifier = Modifier.width(50.dp)
                        )
                        {
                            val arrowIcon =
                                if (opt1) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown
                            Icon(
                                imageVector = arrowIcon,
                                contentDescription = null,
                            )
                        }
                    }
                    AnimatedVisibility(
                        visible = opt1,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                               // .padding(16.dp)
                                .fillMaxWidth(),
                            //    horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {

                            val prods: Map<String, Int> = del.products.split(',')
                                .map { it.split(':') }
                                .associate { it[0] to it[1].toInt() }


                            prods.forEach() { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement
                                        .spacedBy(
                                            space = 10.dp,
                                            alignment = Alignment.Start
                                        ),
                                    verticalAlignment = Alignment.CenterVertically

                                ) {
                                    Checkbox(
                                        checked = viewModel.availables.contains(item.key),
                                        onCheckedChange = { isChecked ->
                                            if (isChecked) {
                                                viewModel.addToAvailable(item.key)
                                            } else {
                                                viewModel.removeToAvailable(item.key)
                                            }
                                        },
                                    )

                                    Text(
                                        text = "" + item.key+" x "+item.value,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Start,
                                        modifier = Modifier.padding(end = 20.dp)
                                    )
                                }

                            }
                        }

                    }
                    Divider(color = Color.DarkGray, thickness = 1.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .clickable(onClick = {
                                opt2 = !opt2
                                opt1= false
                                opt3= false
                                motivation = ""
                                viewModel.clearAvailable()}),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier.width(300.dp)
                        )
                        {
                            Text(
                                text = "Servizio attualmente non disponibile",
                                fontSize = 13.sp,
                                color = if(opt2) Color.Black else Color.DarkGray,
                                fontWeight = if(opt2) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                    Divider(color = Color.DarkGray, thickness = 1.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .clickable(onClick = {
                                opt3 = !opt3
                                opt1 = false
                                opt2 = false
                                motivation = ""
                                viewModel.clearAvailable()
                            }),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier.width(220.dp)
                        )
                        {
                            Text(
                                text = "Altro",
                                fontSize = 13.sp,
                                color = if(opt3) Color.Black else Color.DarkGray,
                                fontWeight = if(opt3) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                        Box(
                            modifier = Modifier.width(50.dp)
                        )
                        {
                            val arrowIcon =
                                    if (opt3) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown
                                Icon(
                                    imageVector = arrowIcon,
                                    contentDescription = null,
                                )

                        }
                    }

                  /*  AnimatedVisibility(
                        visible = opt3,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) { */
                    if(opt3){
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            //    horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {

                            OutlinedTextField(
                                modifier = Modifier.fillMaxWidth(),
                                value = motivation,
                                onValueChange = { newText ->
                                    motivation = newText
                                },
                                placeholder = {
                                    Text(text = "Spiega la motivazione al cliente:")
                                },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                maxLines = 3,
                                //  modifier = Modifier.width(330.dp)
                            )
                       }
                    }
                    Divider(color = Color.DarkGray, thickness = 1.dp)
                }

            },

            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                        showMotivation = false

                        var code = ""

                        viewModel.deliveriesComplete.forEach(){ delivery ->
                            if(delivery.value == del)
                                code = delivery.key
                        }

                        //   var del = viewModel.currentDelivery.value
                        var updatedDel = del?.let {
                            Consegna("rejected", it.date_Start, del.time_Start, date, time, del.date_Due, del.time_Due,
                                del.id_mittente, del.id_destinatario, del.locker, del.locker_space, del.code_inserimento, del.code_sblocco, del.products,
                                del.price, del.payment, "")
                        }

                        db.child("deliveries").child(""+code).setValue(updatedDel)}

                ) {
                    Text("Avanti senza motivare") }
            },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                        showMotivation = false
                        pressed=true

                        var code = ""

                        viewModel.deliveriesComplete.forEach(){ delivery ->
                            if(delivery.value == del)
                                code = delivery.key
                        }

                        val prods: Map<String, Int> = del.products.split(',')
                            .map { it.split(':') }
                            .associate { it[0] to it[1].toInt() }

                        var rej = ""
                        if(opt2)
                            rej="Il servizio non è attualmente disponibile."
                        if(motivation != "")
                            rej = motivation+"."
                        if(!viewModel.availables.isEmpty())
                        {  rej="Alcuni prodotti non sono attualmente disponibili:"
                            viewModel.availables.forEach() {prod->
                                rej = rej +" "+ prod+" x "+prods.get(prod)+","
                            }
                        }
                        //   var del = viewModel.currentDelivery.value
                        var updatedDel = del?.let {
                            Consegna("rejected", it.date_Start, del.time_Start, date, time, del.date_Due, del.time_Due,
                                del.id_mittente, del.id_destinatario, del.locker, del.locker_space, del.code_inserimento, del.code_sblocco, del.products,
                                del.price, del.payment, rej.dropLast(1))
                        }

                        db.child("deliveries").child(""+code).setValue(updatedDel)

                    }

                ) {
                    Text("Invia motivazione")
                }
            },

            )

    }
}
