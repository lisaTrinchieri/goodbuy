package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserFavouriteScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage: StorageReference) {


    val favs = db.child("favourites")
    favs.addValueEventListener(object : ValueEventListener {
        override fun onDataChange(dataSnapshot: DataSnapshot){

            var id=""

            dataSnapshot.children.forEach(){u ->

                id = u.key.toString()


                if(id== viewModel.currentUser.value?.username ?: "") {
                    u.children.forEach() { shop ->
                        val name = shop.getValue().toString()
                        if(!viewModel.favs.contains(name))
                            viewModel.addFav(name)
                    }
                }
            }


        }
        override fun onCancelled(databaseError: DatabaseError){
            println("The read failed: " + databaseError.code)
        }
    })

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Goodbuy") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(  modifier = Modifier.fillMaxWidth()
                        .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),)
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            //  item {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "I tuoi preferiti",
                        fontWeight = FontWeight.Bold,
                        fontSize = 25.sp,
                    )

                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyVerticalGrid(
                    modifier = Modifier.fillMaxSize(),
                    columns = GridCells.Fixed(count = 2)
                ) {
                    items(count = viewModel.sellers.size) { index ->

                        if(viewModel.favs.contains(viewModel.sellers[index].name))
                        {
                           Box(
                            modifier = Modifier.fillMaxHeight()
                                .width(190.dp)
                                .wrapContentSize(Alignment.TopStart)
                                .padding(bottom = 15.dp)
                           ) {

                            Column() {
                                OutlinedCard(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                    ),

                                    border = BorderStroke(1.dp, Color.Black),
                                    modifier = Modifier
                                        .size(width = 165.dp, height = 140.dp)
                                        // .padding(16.dp)
                                        .clickable(onClick = {
                                            viewModel.currentShop.value =
                                                viewModel.sellers[index]
                                            navController.navigate(Screen.ShopScreen.route)
                                        })
                                ) {
                                    Column {
                                        Box()
                                        {

                                            val bitmap =
                                                remember { mutableStateOf<Bitmap?>(null) }
                                            val image = viewModel.sellers[index].image
                                            storage.child("images/$image")
                                                .getBytes(Long.MAX_VALUE)
                                                .addOnSuccessListener { bytes ->

                                                    bitmap.value =
                                                        BitmapFactory.decodeByteArray(
                                                            bytes,
                                                            0,
                                                            bytes.size
                                                        )

                                                }.addOnFailureListener {}

                                            bitmap?.value.let { btm ->
                                                if (btm != null) {
                                                    Image(
                                                        bitmap = btm.asImageBitmap(),
                                                        contentDescription = null,
                                                        modifier = Modifier
                                                            .width(width = 250.dp)
                                                            .clip(
                                                                shape = RoundedCornerShape(
                                                                    size = 12.dp
                                                                )
                                                            ),
                                                        contentScale = ContentScale.Crop
                                                    )
                                                }
                                            }

                                            Text(
                                                modifier = Modifier.padding(
                                                    start = 6.dp,
                                                    top = 70.dp,
                                                    bottom = 10.dp
                                                ),
                                                text = "" + viewModel.sellers[index].category,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.Black
                                            )
                                            IconToggleButton(
                                                modifier = Modifier.padding(start = 110.dp),
                                                checked = viewModel.favs.contains(viewModel.sellers[index].name),
                                                onCheckedChange = { _checked ->

                                                    if (_checked) {
                                                        viewModel.addFav(viewModel.sellers[index].name)
                                                        db.child("favourites").child(""+ (viewModel.currentUser.value?.username
                                                            ?: "")).child(viewModel.sellers[index].name).setValue(viewModel.sellers[index].name)

                                                    } else {
                                                        viewModel.removeFav(viewModel.sellers[index].name)
                                                        Log.d(
                                                            "aaaa",
                                                            "FirebaseUtentifavs shop  " + viewModel.favs.size
                                                        )
                                                        // db.child("favourites").child("user1").removeValue(shop.name)
                                                        db.getRef().child("favourites")
                                                            .child(""+(viewModel.currentUser.value?.username ?: "")).removeValue()
                                                        viewModel.favs.forEach() { f ->
                                                            db.child("favourites")
                                                                .child(""+(viewModel.currentUser.value?.username ?: "")).child(f).setValue(f)
                                                            // Log.d("aaaa", "FirebaseUtentifavs shop  " + f)
                                                        }

                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Favorite,
                                                    contentDescription = "Favorite Item",
                                                    tint = if (viewModel.favs.contains(viewModel.sellers[index].name)) Color.Red else Color.LightGray // icon color
                                                )
                                            }
                                        }
                                    }
                                }
                                Text(
                                    text = "" + viewModel.sellers[index].name,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(top = 10.dp, start = 5.dp),
                                    textAlign = TextAlign.Center,
                                )


                            }
                        }
                    }

                    }
                }

            }
        }


    }
}
