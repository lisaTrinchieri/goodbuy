package it.polito.laib_3.user

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SearchBar
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.Seller
import kotlin.random.Random

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "SuspiciousIndentation")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSearchScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage:StorageReference) {

    val keyboardController = LocalSoftwareKeyboardController.current

    val configuration = LocalConfiguration.current

    val show by viewModel.showSearchingResults.collectAsState()
    val first by viewModel.firstResearch.collectAsState()


    val screenHeight = configuration.screenHeightDp.dp
    val screenWidth = configuration.screenWidthDp.dp

    //Collecting states from ViewModel
   // val searchText by viewModel.searchText.collectAsState()
    val searchText by viewModel.searchTextStateFlow.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    //val sellersList by viewModel.sellersList.collectAsState()

    val searchResultsSellers by viewModel.searchResultsSellers.collectAsStateWithLifecycle()
    val searchResultsProds by viewModel.searchResultsProductsText.collectAsStateWithLifecycle() //

    var isSellers by remember { mutableStateOf((true)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text="") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.serach_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            SearchBar(
                query = searchText,//text showed on SearchBar
                onQueryChange = viewModel::setSearchText, //onSearchTextChange, //update the value of searchText
                onSearch = {viewModel::setSearchText
                           // if(searchText.isNotEmpty())
                           var cat = ""
                           if(!isSellers)
                              cat = "prod"
                           else
                              cat = "sell"

                           viewModel.interruptSearch(cat, searchText)

                            keyboardController?.hide() }, //onSearchTextChange, //the callback to be invoked when the input service triggers the ImeAction.Search action
                active = isSearching, //whether the user is searching or not
                onActiveChange = { viewModel.onToogleSearch() }, //the callback to be invoked when this search bar's active state is changed
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = {
                    Text(text = "inizia ricerca")
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        tint = MaterialTheme.colorScheme.onSurface,
                        contentDescription = null
                    )
                },
             /*   trailingIcon = {
                    if(isSearching) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            modifier = Modifier.clickable { viewModel.onResetSearch()
                                 },
                            tint = MaterialTheme.colorScheme.onSurface,
                            contentDescription = null
                        )
                    }
                },  */
                trailingIcon = {
                    if (searchText.isNotEmpty() || isSearching) {
                        IconButton(onClick = { viewModel.setSearchText("")
                                                viewModel.onResetSearch()}) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                tint = MaterialTheme.colorScheme.onSurface,
                                contentDescription = "Clear search"
                            )
                        }
                    }
                },
                content = {

                    if ((isSellers && searchResultsSellers.isEmpty() && first)
                             || (!isSellers && searchResultsProds.isEmpty() && first) ) {
                        MovieListEmptyState()
                    }
                    else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(32.dp),
                            contentPadding = PaddingValues(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(
                                count = if (isSellers) searchResultsSellers.size else searchResultsProds.size,
                                key = { index -> if (isSellers) searchResultsSellers[index].name+Random.nextInt(3000) else searchResultsProds[index]+Random.nextInt(3000) },
                                itemContent = { index ->

                                    var sell = Seller("", "", "", "", "", "", "", "", "")
                                    // var prod = Product("","",0,"","","","", false, false, "")

                                    var prod = ""

                                    if (isSellers)
                                        sell = searchResultsSellers[index]
                                    else
                                        prod = searchResultsProds[index]

                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (isSellers) {
                                                    viewModel.currentShop.value = sell
                                                    navController.navigate(Screen.ShopScreen.route)
                                                    viewModel.firstResearch.value = false
                                                } else {
                                                    viewModel.filterForProduct(prod) //prod.name
                                                    viewModel.showSearchingResults.value = true
                                                    viewModel.setSearchText(prod)
                                                    viewModel.firstResearch.value = false
                                                }
                                            }
                                            .height(30.dp)
                                    ) {

                                        Text(
                                            text = if (isSellers) sell.name else prod,  //prod.name,
                                            fontSize = 15.sp,
                                        )
                                    }


                                }
                            )
                        }
                    }
                },
              )

            Row(){


                Button(
                    modifier = Modifier
                        .height(60.dp)
                        .width(screenWidth / 2)
                        .drawBehind {

                            var strokeWidth = 0.0

                            if (isSellers)
                                strokeWidth = 3.dp
                                    .toPx()
                                    .toDouble()
                            else
                                strokeWidth = 1.dp
                                    .toPx()
                                    .toDouble()


                            drawLine(
                                color = Color.DarkGray,
                                start = Offset(0f, size.height),
                                end = Offset(size.width, size.height),
                                strokeWidth = strokeWidth.toFloat()
                            )

                        }
                        .padding(vertical = 10.dp) ,
                    shape = RectangleShape,
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                    //   shape = RoundedCornerShape(10.dp),
                    onClick = { isSellers=true
                                viewModel.clearSellersSearch()
                               viewModel.onResetSearch() },
                ) {
                    Text(text = "Attività",
                        fontWeight = if(isSellers)FontWeight.Bold else FontWeight.Normal,
                        fontSize = 15.sp)
                }


                Button(
                    modifier = Modifier
                        .height(60.dp)
                        .width(screenWidth / 2)
                        .drawBehind {

                            var strokeWidth = 0.0

                            if (!isSellers)
                                strokeWidth = 3.dp
                                    .toPx()
                                    .toDouble()
                            else
                                strokeWidth = 1.dp
                                    .toPx()
                                    .toDouble()


                            drawLine(
                                color = Color.DarkGray,
                                start = Offset(0f, size.height),
                                end = Offset(size.width, size.height),
                                strokeWidth = strokeWidth.toFloat()
                            )

                        }
                        .padding(vertical = 10.dp) ,
                    shape = RectangleShape,
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                    //   shape = RoundedCornerShape(10.dp),
                    onClick = { isSellers=false },
                ) {
                    Text(text = "Prodotti",
                        fontWeight = if(!isSellers)FontWeight.Bold else FontWeight.Normal,
                        fontSize = 15.sp)
                }

            }

            if(show)
            {
                Column(
                    modifier = Modifier
                        .padding(start = 16.dp, end = 16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LazyVerticalGrid(
                        modifier = Modifier.fillMaxSize(),
                        columns = GridCells.Fixed(count = 2)
                    ) {
                        items(count = viewModel.sellersSearch.size) { index ->

                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(195.dp)
                                    .wrapContentSize(Alignment.TopStart)
                                    .padding(bottom = 15.dp)
                            ) {

                                Column() {
                                    OutlinedCard(
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.surface,
                                        ),

                                        border = BorderStroke(1.dp, Color.Black),
                                        modifier = Modifier
                                            .size(width = 165.dp, height = 140.dp)
                                            // .padding(16.dp)
                                            .clickable(onClick = {
                                                viewModel.currentShop.value =
                                                    viewModel.sellers[index]
                                                navController.navigate(Screen.ShopScreen.route)
                                            })
                                    ) {
                                        Column {
                                            Box()
                                            {

                                                val bitmap =
                                                    remember { mutableStateOf<Bitmap?>(null) }
                                                val image = viewModel.sellers[index].image
                                                storage.child("images/$image")
                                                    .getBytes(Long.MAX_VALUE)
                                                    .addOnSuccessListener { bytes ->

                                                        bitmap.value =
                                                            BitmapFactory.decodeByteArray(
                                                                bytes,
                                                                0,
                                                                bytes.size
                                                            )

                                                    }.addOnFailureListener {}

                                                bitmap?.value.let { btm ->
                                                    if (btm != null) {
                                                        Image(
                                                            bitmap = btm.asImageBitmap(),
                                                            contentDescription = null,
                                                            modifier = Modifier
                                                                .width(width = 250.dp)
                                                                .clip(
                                                                    shape = RoundedCornerShape(
                                                                        size = 12.dp
                                                                    )
                                                                ),
                                                            contentScale = ContentScale.Crop
                                                        )
                                                    }
                                                }

                                                Text(
                                                    modifier = Modifier.padding(
                                                        start = 6.dp,
                                                        top = 70.dp,
                                                        bottom = 10.dp
                                                    ),
                                                    text = "" + viewModel.sellers[index].category,
                                                    fontSize = 16.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Black
                                                )

                                            }
                                        }
                                    }
                                    Text(
                                        text = "" + viewModel.sellers[index].name,
                                        fontSize = 15.sp,
                                        modifier = Modifier
                                            .padding(top = 10.dp, start = 5.dp),
                                        textAlign = TextAlign.Center,
                                    )


                                }
                            }

                        }
                    }
                }
            }

        }

    }
    }


@Composable
fun MovieListEmptyState(
    modifier: Modifier = Modifier
) {
    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.fillMaxSize()
    ) {
        Text(
            text = "Nessun risultato trovato",
            style = MaterialTheme.typography.titleSmall
        )
        Text(
            text = "Inserisci un nuovo testo",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}



