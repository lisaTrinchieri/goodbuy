package it.polito.laib_3.registration

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.User
import it.polito.laib_3.bounceClick

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterUserScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic :FirebaseAuth, storage: StorageReference) {

    val context = LocalContext.current

    var username by remember { mutableStateOf(("")) }
    var pwd by remember { mutableStateOf(("")) }
    var email by remember { mutableStateOf(("")) }
    var telephone by remember { mutableStateOf(("")) }

    var missing by remember { mutableStateOf(("")) }

    var error by remember { mutableStateOf((false)) }
    var confirm by remember { mutableStateOf((false)) }
    var already by remember { mutableStateOf((false)) }


     Scaffold(
          topBar = {
              TopAppBar(
                  title = {},
                  colors = TopAppBarDefaults.smallTopAppBarColors(
                      containerColor = MaterialTheme.colorScheme.primary,
                      titleContentColor = Color.White,
                  ),
                  navigationIcon = {
                      IconButton(onClick = { navController.navigate(Screen.SelectRoleScreen.route) }) {
                          Icon(

                              imageVector = Icons.Filled.ArrowBack,
                              contentDescription = "to show",
                              tint = Color.White,
                          )
                      }
                  },
              )
          },
          bottomBar = {
              BottomAppBar(
                  modifier = Modifier.height(20.dp),
                  containerColor = MaterialTheme.colorScheme.primary,
                  contentColor = MaterialTheme.colorScheme.primary,
              ) {
              }
          },

          ) { innerPadding ->

          LazyColumn(
              modifier = Modifier
                  .padding(innerPadding),
              verticalArrangement = Arrangement.spacedBy(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally
          ) {
              item {
                  Column(
                      modifier = Modifier
                          .padding(16.dp)
                          .fillMaxWidth(),
                      // horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                      Spacer(modifier = Modifier.height(30.dp))
                      Row() {
                          Text(
                              text = "Registrazione",
                              fontWeight = FontWeight.Bold,
                              fontSize = 30.sp,
                              modifier = Modifier.align(alignment = Alignment.CenterVertically)
                          )
                      }
                      Spacer(modifier = Modifier.height(30.dp))


                      Row() {
                          if(!missing.contains("username"))
                          {
                              Text(
                              text = "Username",
                              fontSize = 16.sp,
                              )
                          }
                          else
                          {
                              Text(
                                  text = "Username *",
                                  color= Color.Red,
                                  fontSize = 16.sp,
                              )
                          }
                      }
                      Spacer(modifier = Modifier.height(5.dp))
                      OutlinedTextField(
                          value = username,
                          onValueChange = { newText ->
                              username = newText
                          },
                          placeholder = {
                              Text(text = "Es. Mario_rossi", color= Color.LightGray)
                          },
                          keyboardOptions = KeyboardOptions(
                              keyboardType = KeyboardType.Text,
                              imeAction = ImeAction.Done
                          ),
                      )
                      Spacer(modifier = Modifier.height(15.dp))

                      Row() {
                          if(!missing.contains("telephone"))
                          {
                              Text(
                                  text = "Numero di telefono",
                                  fontSize = 16.sp,
                              )
                          }
                          else
                          {
                              Text(
                                  text = "Numero di telefono *",
                                  color= Color.Red,
                                  fontSize = 16.sp,
                              )
                          }
                      }
                      Spacer(modifier = Modifier.height(5.dp))
                      OutlinedTextField(
                          value = telephone,
                          onValueChange = { newText ->
                              telephone = newText
                          },
                          placeholder = {
                              Text(text = "Es. 332788937", color= Color.LightGray)
                          },
                          keyboardOptions = KeyboardOptions(
                              keyboardType = KeyboardType.Phone,
                              imeAction = ImeAction.Done
                          ),
                      )
                      Spacer(modifier = Modifier.height(15.dp))

                      Row() {
                          if(!missing.contains("email"))
                          {
                              Text(
                                  text = "Email",
                                  fontSize = 16.sp,
                              )
                          }
                          else
                          {
                              Text(
                                  text = "Email *",
                                  color= Color.Red,
                                  fontSize = 16.sp,
                              )
                          }
                      }
                      Spacer(modifier = Modifier.height(5.dp))
                      OutlinedTextField(
                          value = email,
                          onValueChange = { newText ->
                              email = newText
                          },
                          placeholder = {
                              Text(text = "Es. Mario@gmail.com", color= Color.LightGray)
                          },
                          keyboardOptions = KeyboardOptions(
                              keyboardType = KeyboardType.Email,
                              imeAction = ImeAction.Done
                          ),
                      )
                      Spacer(modifier = Modifier.height(15.dp))


                      Row() {
                          if(!missing.contains("pwd"))
                          {
                              Text(
                                  text = "Password",
                                  fontSize = 16.sp,
                              )
                          }
                          else
                          {
                              Text(
                                  text = "Password *",
                                  color= Color.Red,
                                  fontSize = 16.sp,
                              )
                          }

                      }
                      Spacer(modifier = Modifier.height(5.dp))
                      OutlinedTextField(
                          value = pwd,
                          onValueChange = { newText ->
                              pwd = newText
                          },
                          placeholder = {
                              Text(text = "Password", color= Color.LightGray)
                          },
                          keyboardOptions = KeyboardOptions(
                              keyboardType = KeyboardType.Password,
                              imeAction = ImeAction.Done
                          ),
                      )
                      Spacer(modifier = Modifier.height(20.dp))



                      Row(
                          modifier = Modifier.fillMaxWidth(),
                          horizontalArrangement = Arrangement
                              .spacedBy(
                                  space = 20.dp,
                                  alignment = Alignment.CenterHorizontally
                              ),
                          verticalAlignment = Alignment.CenterVertically
                      )
                      {
                          Button(
                              modifier = Modifier
                                  .bounceClick()
                                  .height(45.dp)
                                  .width(130.dp),
                              shape = RoundedCornerShape(10.dp),
                              onClick = {

                                  if (username == "" || pwd == "" || email == "" || telephone == "")
                                  {    error = true }
                                  else {

                                      val user = User(username.replace(" ", ""), pwd.replace(" ", ""),
                                              email.replace(" ", ""), telephone.replace(" ", ""))

                                      viewModel.users.forEach(){ u ->

                                          if(u.email == email)
                                              already = true
                                      }



                                      if (!already) {


                                          db.child("users").push().setValue(user)
                                          viewModel.currentUser.value = user

                                          authentic.createUserWithEmailAndPassword(email, pwd)
                                              .addOnCompleteListener { task ->
                                                  if (task.isSuccessful) {
                                                      // Sign in success, update UI with the signed-in user's information
                                                      Log.d("aaaaa", "createUserWithEmail:success")

                                                      val user = authentic.currentUser
                                                      confirm = true

                                                      Log.d("aaaaa", "currentUser registration : "+authentic.currentUser)

                                                  } else {
                                                      Log.w("aaa", "createUserWithEmail:failure", task.exception)
                                                  }
                                              }
                                      }
                                  }


                              },
                              content = {
                                  Text(
                                      text = "Conferma",
                                      fontSize = 16.sp
                                  )
                              }
                          )

                          Button(
                              modifier = Modifier
                                  .bounceClick()
                                  .height(45.dp)
                                  .width(130.dp),
                              shape = RoundedCornerShape(10.dp),
                              onClick = {

                                  pwd = ""
                                  username = ""
                                  email = ""
                                  telephone = ""
                                  missing = ""
                              },
                              content = {
                                  Text(
                                      text = "Svuota",
                                      fontSize = 16.sp
                                  )
                              }
                          )

                      }


                      if (error) {
                          AlertDialog(
                              onDismissRequest = { error = false },
                              text = { Text("E' necessario riempire tutti i campi prima di procede alla registrazione") },
                              confirmButton = {
                                  Button(
                                      modifier = Modifier.bounceClick(),
                                      onClick = {
                                          error = false
                                          missing = ""

                                          if(username == "")
                                              missing = missing+"username"
                                          if(pwd == "")
                                              missing = missing+"pwd"
                                          if(email == "")
                                              missing = missing+"email"
                                          if(telephone == "")
                                              missing = missing+"telephone" }
                                  ) {
                                      Text("OK")
                                  }
                              }
                          )

                      }

                      if (confirm) {
                          AlertDialog(
                              onDismissRequest = { confirm = false },
                              text = { Text("Registrazione avvenuta con successo") },
                              confirmButton = {
                                  Button(
                                      modifier = Modifier.bounceClick(),
                                      onClick = {
                                          missing = ""
                                          confirm = false
                                          navController.navigate(Screen.HomeUserScreen.route)
                                      }
                                  ) {
                                      Text("OK")
                                  }
                              }
                          )

                      }

                      if (already) {
                          AlertDialog(
                              onDismissRequest = { already = false },
                              text = { Text("Indirizzo email già associato ad un altro profilo") },
                              confirmButton = {
                                  Button(
                                      modifier = Modifier.bounceClick(),
                                      onClick = { already = false
                                                  missing = ""}
                                  ) {
                                      Text("OK")
                                  }
                              }
                          )

                      }

                  }

              }
          }
          //}
      }
}

