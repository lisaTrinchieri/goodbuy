package it.polito.laib_3

data class User(
    val username: String,
    val password: String,
    val email: String,
    val number: String,
  //  val favourites: List<String>,

)
