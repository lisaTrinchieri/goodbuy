package it.polito.laib_3.user

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import it.polito.laib_3.Consegna
import it.polito.laib_3.LockerSpace
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.Seller
import it.polito.laib_3.bounceClick
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LockerPositionScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    var selected by remember { mutableStateOf((false)) }
    var error by remember { mutableStateOf((false)) }
    val context = LocalContext.current

    Log.d("bbbb", "Numero di carrello "+viewModel.cart.size)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text="Mappa"
                ) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.CartScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },
    ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 5.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.carrello),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.Black),
                            modifier = Modifier.size(23.dp)
                        )

                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight/2),
                                end = Offset(x = 0f, y = canvasHeight/2),
                                color = Color.Black,
                                strokeWidth = 2F
                            )
                        }
                        OutlinedIconButton(
                            onClick = { },
                            enabled = false,
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.pin),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight/2),
                                end = Offset(x = 0f, y = canvasHeight/2),
                                color = Color.DarkGray,
                                strokeWidth = 1F
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.wallet),
                            contentDescription = "confermato",
                            colorFilter = ColorFilter.tint(Color.Black),
                            modifier = Modifier.size(23.dp)
                        )

                    }

                    Spacer(modifier = Modifier.height(15.dp))

                    Text(
                        text = "Seleziona un locker dalla mappa",
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(modifier = Modifier.height(10.dp))



                    viewModel.lockersList.forEach { lock ->

                        var available = false
                        var piccola = 0
                        var media = 0
                        var grande = 0

                        viewModel.cart.forEach() {prod->

                            if (prod.key.dimension == "Piccola")
                                piccola = piccola + prod.value
                            if (prod.key.dimension == "Media")
                                media = media + prod.value
                            if (prod.key.dimension == "Grande")
                                grande = grande + prod.value

                        }


                        if(piccola<10 && media==0 && grande==0)
                         viewModel.currentDimension.value = "Piccola"
                        else if(piccola<4 && media>0 && media<4 && grande==0)
                         viewModel.currentDimension.value = "Media"
                        else
                          viewModel.currentDimension.value = "Grande"

                        Log.d("delivery", "locker screen delivery : "+ (viewModel.currentDimension.value
                            ?: ""))




                        //implementare anche per le dimensioni
                        lock.spaces.forEach() {space->
                            if(space.free)
                            {    if(space.dimension == viewModel.currentDimension.value)
                                        available = true
                            }
                        }

                        if(available)
                        {
                            Row()
                            {
                                IconToggleButton(
                                    checked = viewModel.lockersChecked.getValue(lock),
                                    onCheckedChange = { _checked ->
                                        viewModel.resetLockers()
                                        viewModel.changeSelectedLocker(lock, _checked)

                                        if(_checked)
                                        {   viewModel.currentLocker.value = lock
                                            selected=true

                                            // qui vedere lo spazio per le dimensioni del pacco
                                        }
                                        else
                                            selected=false
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "Favorite Item",
                                        tint = if (viewModel.lockersChecked.getValue(lock)) Color.Red else Color.LightGray // icon color
                                    )
                                }
                            }
                        }
                        else
                        {   Row()
                            {
                                IconButton(
                                    onClick = { Toast.makeText(context,"Nessuno spazio libero con le giuste dimensioni per questo locker", Toast.LENGTH_SHORT).show()}
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "Favorite Item",
                                        tint = Color.LightGray // icon color
                                    )
                                }
                            }
                        }

                    }


                    Spacer(modifier = Modifier.height(15.dp))

                    if(selected) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically

                        ) {
                            Text(
                                text = "Hai selezionato il ${viewModel.currentLocker.value?.id_locker}",
                                fontSize = 18.sp,
                            )
                        }
                    }
                    }



                    Spacer(modifier = Modifier.height(40.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(120.dp),
                        onClick = {

                            var currentLocker=""
                            currentLocker = viewModel.currentLocker.value?.id_locker ?: ""

                            if(currentLocker=="")
                                error = true

                            if(!error)
                            {
                                var found = false

                                viewModel.currentLocker.value?.spaces?.forEach() { space ->
                                  if (space.free && space.dimension == viewModel.currentDimension.value) {
                                    if (!found) {
                                        viewModel.currentLockerSpace.value = space
                                        found = true
                                    }
                                  }
                                }

                                navController.navigate(Screen.PaymentScreen.route)

                            }
                                  },
                        content = { Text( text="Avanti",
                            fontSize = 16.sp ) }
                    )


                }
            }
        }
    if (error) {
        AlertDialog(
            onDismissRequest = { error = false },
            text = { Text("Nessun locker selezionato") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = { error = false }
                ) {
                    Text("OK")
                }
            }
        )

    }
}
