package it.polito.laib_3


class PurchasableItem(
    val description: String,
    val category: String,
    val status: String
) {
    // Puoi aggiungere ulteriori funzioni o logica qui, se necessario
}

fun main() {
    // Esempio di creazione di un'istanza di PurchasableItem
    val item = PurchasableItem("Smartphone", "Elettronica", "Disponibile")

    // Accesso alle proprietà dell'oggetto
    println("Descrizione: ${item.description}")
    println("Categoria: ${item.category}")
    println("Stato: ${item.status}")
}