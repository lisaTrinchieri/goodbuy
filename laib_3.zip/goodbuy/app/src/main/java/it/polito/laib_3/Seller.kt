package it.polito.laib_3

data class Seller (

    val password:String,
    val name: String,
    val address: String,
    val category: String,
    val number: String,
    val email: String,
  /*  val start:String,
    val stop: String,
    val hourStart:String,
    val hourEnd: String,
    val startEx:String,
    val stopEx: String,
    val hourStartEx:String,
    val hourEndEx: String, */
    val orari:String
)