package it.polito.laib_3

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PurchaseViewModel : ViewModel() {

    private val _valid : MutableStateFlow<Boolean?> = MutableStateFlow(null)
    val valid : StateFlow<Boolean?> = _valid

    var loggedIn= MutableLiveData<Boolean>()

    var code by mutableStateOf("")


    var current= MutableLiveData<Locker>()
    var currentSpace= MutableLiveData<LockerSpace>()
    var status= MutableLiveData<String>()
    var currentDel= MutableLiveData<String>()

    private var _deliveries: MutableMap<String, Consegna> = mutableStateMapOf()
    val deliveries: Map<String, Consegna> = _deliveries

    var open = MutableStateFlow(false)



    fun addDel(id: String, del: Consegna){
        _deliveries.put(id, del)
    }

    fun clearDel() {
        _deliveries.clear()
    }

    fun startThreadLogin() {
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                delay(3000)
            }
            closeDialogLogin()
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private fun closeDialogLogin() {
        open.value = false
    }

}


