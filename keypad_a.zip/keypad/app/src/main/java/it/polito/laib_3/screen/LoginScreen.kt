package it.polito.laib_3.screen

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import it.polito.laib_3.Consegna
import it.polito.laib_3.Locker
import it.polito.laib_3.LockerSpace
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick


//per autenticazione con username e password
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController, viewModel: PurchaseViewModel, authentic : FirebaseAuth, db:DatabaseReference) {

    var username by remember {
        mutableStateOf((""))
    }

    var pwd by remember {
        mutableStateOf((""))
    }
    var error by remember { mutableStateOf((false)) }

    val openLoading by viewModel.open.collectAsState()

    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Locker manager",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )

        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(70.dp))
                Row() {
                    Text(
                        text = "Login",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                OutlinedTextField(
                    modifier = Modifier.focusRequester(focusRequester),
                    value = username,
                    onValueChange = { newText ->
                        username = newText
                    },
                    label = {
                        Text(text = "Username")
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Done
                    ),
                )
                Spacer(modifier = Modifier.height(5.dp))
                OutlinedTextField(
                    modifier = Modifier.focusRequester(focusRequester),
                    value = pwd,
                    onValueChange = { newText ->
                        pwd = newText
                    },
                    label = {
                        Text(text = "Password")
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                )

                Spacer(modifier = Modifier.height(30.dp))

                Button(
                    modifier = Modifier
                        .bounceClick()
                        .height(45.dp)
                        .width(120.dp),
                    shape = RoundedCornerShape(20.dp),
                    onClick = {

                        if (username != "" && pwd != "") {
                            viewModel.open.value = true
                            viewModel.startThreadLogin()

                            authentic.signInWithEmailAndPassword(username, pwd)
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        Log.w(
                                            "cccc",
                                            "signInWithEmail:ok",

                                        )
                                        navController.navigate(Screen.StartScreen.route)

                                        if(username.contains("lock1"))
                                            getLocker("locker1", db, viewModel)
                                        if(username.contains("lock2"))
                                            getLocker("locker2", db, viewModel)
                                        if(username.contains("locker3"))
                                            getLocker("lock3", db, viewModel)

                                        viewModel.loggedIn.value = false

                                    } else {
                                        Log.w("cccc", "signInWithEmail:failure", task.exception)
                                        error = true
                                    }
                                }


                        }
                    },
                    content = {
                        Text(
                            text = "Accedi",
                            fontSize = 16.sp
                        )
                    }
                )

                Spacer(modifier = Modifier.height(30.dp))


              if (error) {
                    AlertDialog(
                        onDismissRequest = {
                            error = false
                            viewModel.open.value = false
                        },
                        text = { Text("Errore username e/o password") },
                        confirmButton = {
                            Button(
                                modifier = Modifier.bounceClick(),
                                onClick = {
                                    error = false

                                    username = ""
                                    pwd = ""
                                    viewModel.open.value = false

                                    focusManager.clearFocus()
                                }
                            ) {
                                Text("OK")
                            }
                        }
                    )

                }
            }
        }
    }

    if (openLoading) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            properties = DialogProperties(
                usePlatformDefaultWidth = false // disable the default size so that we can customize it
            ),
            text = {
                Column(
                    modifier = Modifier
                        .padding(start = 42.dp, end = 42.dp) // margin
                        .background(
                            color = Color.White,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(top = 36.dp, bottom = 36.dp), // inner padding
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ProgressIndicatorLoading(
                        progressIndicatorSize = 80.dp,
                        progressIndicatorColor = Color(0xFF35898f)
                    )

                    // Gap between progress indicator and text
                    Spacer(modifier = Modifier.height(32.dp))
                    Text(
                        text = "Attendere...",
                        style = TextStyle(
                            color = Color.Black,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Normal
                        )
                    )
                }
            }
        ) /*{
            Column(
                modifier = Modifier
                    .padding(start = 42.dp, end = 42.dp) // margin
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(top = 36.dp, bottom = 36.dp), // inner padding
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                ProgressIndicatorLoading(
                    progressIndicatorSize = 80.dp,
                    progressIndicatorColor = Color(0xFF35898f)
                )

                // Gap between progress indicator and text
                Spacer(modifier = Modifier.height(32.dp))

                // Please wait text
                Text(
                    text = "Attendere...",
                    style = TextStyle(
                        color = Color.Black,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Normal
                    )
                )
            }
        }*/
    }
}



@Composable
private fun ProgressIndicatorLoading(
    progressIndicatorSize: Dp,
    progressIndicatorColor: Color
) {
    val infiniteTransition = rememberInfiniteTransition()

    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 600 // animation duration
            }
        )
    )

    CircularProgressIndicator(
        progress = 1f,
        modifier = Modifier
            .size(progressIndicatorSize)
            .rotate(angle)
            .border(
                12.dp,
                brush = Brush.sweepGradient(
                    listOf(
                        Color.White, // add background color first
                        progressIndicatorColor.copy(alpha = 0.1f),
                        progressIndicatorColor
                    )
                ),
                shape = CircleShape
            ),
        strokeWidth = 1.dp,
        color = Color.White // Set background color
    )
}

fun getLocker(lock: String, db:DatabaseReference, viewModel: PurchaseViewModel){

    val lockers = db.child("lockers").child(""+lock)
    lockers.addValueEventListener(object : ValueEventListener {
        override fun onDataChange(dataSnapshot: DataSnapshot){


                val lockerSpaces = ArrayList<LockerSpace>()
                val id_lock = dataSnapshot.key.toString()

                dataSnapshot.children.forEach() {space->
                    val id = space.key.toString()
                    val idSpace = space.child("name").getValue().toString()
                    val isFree = space.child("free").getValue().toString().toBoolean()
                    val codeIns = space.child("code_ins").getValue().toString().toInt()
                    val codeRit = space.child("code_rit").getValue().toString().toInt()
                    val dimension = space.child("dimension").getValue().toString()
                    val address = space.child("address").getValue().toString()
                    val positionX = space.child("positionX").getValue().toString().toInt()
                    val positionY = space.child("positionY").getValue().toString().toInt()
                    val open = space.child("open").getValue().toString().toBoolean()
                    val del = space.child("delivery").getValue().toString()

                    val lockerSpace = LockerSpace(idSpace, isFree, codeIns, codeRit, dimension, address, positionX, positionY, open, del)

                    lockerSpaces.add(lockerSpace)
            //    }


                val locker = Locker(id_lock, lockerSpaces)
                viewModel.current.value = locker

            }

        }
        override fun onCancelled(databaseError: DatabaseError){
            println("FIREBASE The read failed: " + databaseError.code)
        }
    })

    //AGGIUNTA DELLE CONSEGNE
    val deliveries = db.child("deliveries")
    deliveries.addValueEventListener(object : ValueEventListener {
        override fun onDataChange(dataSnapshot: DataSnapshot) {

           viewModel.clearDel()

            dataSnapshot.children.forEach() { del ->
                val id = del.key.toString()
                val status = del.child("status").getValue().toString()
                val dateStart = del.child("date_Start").getValue().toString()
                val timeStart = del.child("time_Start").getValue().toString()
                val dateUpdate = del.child("date_Update").getValue().toString()
                val timeUpdate = del.child("time_Update").getValue().toString()
                val dateDue = del.child("date_Due").getValue().toString()
                val timeDue = del.child("time_Due").getValue().toString()
                val mittente = del.child("id_mittente").getValue().toString()
                val destinatario = del.child("id_destinatario").getValue().toString()
                val locker = del.child("locker").getValue().toString()
                val space = del.child("locker_space").getValue().toString()
                val inserimento = del.child("code_inserimento").getValue().toString().toInt()
                val sblocco = del.child("code_sblocco").getValue().toString().toInt()
                val prodsString = del.child("products").getValue().toString()
                val price = del.child("price").getValue().toString().toDouble()
                val payment = del.child("payment").getValue().toString()
                val rejected = del.child("rejected").getValue().toString()

                val delivery = Consegna(
                    status,
                    dateStart,
                    timeStart,
                    dateUpdate,
                    timeUpdate,
                    dateDue,
                    timeDue,
                    mittente,
                    destinatario,
                    locker,
                    space,
                    inserimento,
                    sblocco,
                    prodsString,
                    price,
                    payment,
                    rejected
                )

               if(delivery.locker == lock)
                 if (!viewModel.deliveries.containsKey(id))
                    viewModel.addDel(id, delivery)

            }

        }

        override fun onCancelled(databaseError: DatabaseError) {
            println("The read failed: " + databaseError.code)
        }
    })

}