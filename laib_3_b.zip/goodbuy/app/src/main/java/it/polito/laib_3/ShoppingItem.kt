package it.polito.laib_3

data class ShoppingItem(val name: String, val category: String, var isChecked: Boolean = false)