package it.polito.laib_3

data class Recipe(val name: String, val time: Int, var cooking: String,
    val category: String, val ingredients : List<String> )