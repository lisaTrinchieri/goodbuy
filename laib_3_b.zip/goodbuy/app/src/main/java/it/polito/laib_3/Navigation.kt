package it.polito.laib_3

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.MutableLiveData
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.registration.RegisterProductScreen
import it.polito.laib_3.registration.RegisterSellerScreen
import it.polito.laib_3.registration.RegisterUserScreen
import it.polito.laib_3.registration.SelectRoleScreen
import it.polito.laib_3.seller.HomeSellerScreen
import it.polito.laib_3.seller.OrderDetailSeller
import it.polito.laib_3.seller.OrdersStartedScreen
import it.polito.laib_3.seller.SellerLockerScreen
import it.polito.laib_3.seller.SellerOrdersScreen
import it.polito.laib_3.seller.SellerProfileScreen
import it.polito.laib_3.user.CartScreen
import it.polito.laib_3.user.HomeUserScreen
import it.polito.laib_3.user.LockerPositionScreen
import it.polito.laib_3.user.OrderDetailUser
import it.polito.laib_3.user.OrdersUserScreen
import it.polito.laib_3.user.PaymentScreen
import it.polito.laib_3.user.ShopScreen
import it.polito.laib_3.user.UserFavouriteScreen
import it.polito.laib_3.user.UserProfileScreen
import it.polito.laib_3.user.UserSearchScreen
import it.polito.laib_3.user.UserSettingsScreen


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun Navigation(viewModel: PurchaseViewModel, db: DatabaseReference, auth: FirebaseAuth, storage: StorageReference) {


    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Screen.HomeUserScreen.route
                        // if(auth.currentUser?.email!="")
                        //     Screen.HomeUserScreen.route
                        //   else
                        //     Screen.LoginScreen.route
           ) {

        //REGISTRATION
        composable(Screen.LoginScreen.route) { LoginScreen(navController = navController, viewModel, auth) }

       composable(Screen.SelectRoleScreen.route) { SelectRoleScreen(navController = navController, viewModel) }

       composable(Screen.RegisterUserScreen.route) { RegisterUserScreen(navController = navController, viewModel, db, auth, storage) }
       composable(Screen.RegisterSellerScreen.route) {RegisterSellerScreen(navController = navController, viewModel, db, auth, storage) }
       composable(Screen.RegisterProductScreen.route) { RegisterProductScreen(navController = navController, viewModel, db, auth, storage) }


        //USER
        composable(Screen.HomeUserScreen.route) { HomeUserScreen(navController = navController, viewModel, db, auth, storage) }
        composable(Screen.ShopScreen.route) { viewModel.currentShop.value?.let { it1 ->
            ShopScreen(navController = navController, viewModel, db, auth,
                it1, storage
            )
        } }
        composable(Screen.CartScreen.route) { CartScreen(navController = navController, viewModel, db, auth, storage) }
        composable(Screen.LockerPositionScreen.route) { LockerPositionScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.PaymentScreen.route) { PaymentScreen(navController = navController, viewModel, db, auth) }
        //
       composable(Screen.UserSearchScreen.route) { UserSearchScreen(navController = navController, viewModel, db, auth) }
        //
       composable(Screen.OrdersUserScreen.route) { OrdersUserScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.OrderDetailUser.route) { viewModel.currentDelivery.value?.let { it1 ->
            OrderDetailUser(navController = navController, viewModel, db, auth,
                it1, storage
            )
        } }
        //
        composable(Screen.UserProfileScreen.route) { UserProfileScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.UserSettingsScreen.route) { UserSettingsScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.UserFavouriteScreen.route) { UserFavouriteScreen(navController = navController, viewModel, db, auth, storage) }

        //SELLER
        composable(Screen.HomeSellerScreen.route) { HomeSellerScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.OrderDetailSeller.route) { viewModel.currentDelivery.value?.let { it1 ->
            OrderDetailSeller(navController = navController, viewModel, db, auth,
                it1
            )
        } }
        composable(Screen.OrdersStartedScreen.route) { OrdersStartedScreen(navController = navController, viewModel, db, auth) }


        composable(Screen.SellerLockerScreen.route) { SellerLockerScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.SellerOrdersScreen.route) { SellerOrdersScreen(navController = navController, viewModel, db, auth) }
        composable(Screen.SellerProfileScreen.route) { SellerProfileScreen(navController = navController, viewModel, db, auth) }

    }

}

//per autneticazione in anonimo
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StartScreen(navController: NavController, viewModel: PurchaseViewModel, authAnon: FirebaseAuth) {


    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Locker manager",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )

        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(150.dp))
                Row() {
                    Text(
                        text = "Benvenuto!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }

                Spacer(modifier = Modifier.height(40.dp))

                Button(
                    modifier = Modifier
                        .bounceClick()
                        .height(45.dp)
                        .width(120.dp),
                    shape = RoundedCornerShape(20.dp),
                    onClick = {

                        authAnon.signInAnonymously()
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d("aaa", "FIREBASEAUTH sign InAnonymously:success")
                               //     navController.navigate(Screen.SelectScreen.route)
                                    val user = authAnon.currentUser?.uid
                                    viewModel.userUid.value = user

                                    Log.d("aaa", "FIREBASEAUTH sign InAnonymously USER "+viewModel.userUid.value)
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.d("aaa", " FUREBASEAUTH signInAnonymously:failure", task.exception)

                                }
                            }

                    },
                    content = { Text( text="Entra",
                        fontSize = 16.sp ) }
                )
            }
        }
    }
}

/*
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectScreen(navController: NavController, viewModel: PurchaseViewModel, db:DatabaseReference) {

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Locker manager",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Spacer(modifier = Modifier.height(150.dp))
                    Row() { Text(
                        text = "Come vuoi accedere?",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold ) }
                    Spacer(modifier = Modifier.height(40.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(200.dp),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(2.dp, Color.Black),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),

                        onClick = {

                            var current : User? = null
                            var key : String = ""
                            viewModel.usersComplete.forEach(){user ->
                                if(user.value.role == "seller")
                                {    current = user.value
                                     key=user.key
                                }
                            }

                            viewModel.userKey.value = key

                            if(current != null)
                            {   val newUser = viewModel.userUid.value?.let {
                                User(it, current!!.role, current!!.username, current!!.password, current!!.number, current!!.email) }
                                db.child("users").child(""+ key).setValue(newUser)
                            }

                            navController.navigate(Screen.HomeSellerScreen.route)

                        },
                    ) {
                        Text(text = "seller  ",
                             fontWeight = FontWeight.Bold,
                             fontSize = 20.sp)
                        Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                        Icon(
                            Icons.Filled.ArrowForward,
                            contentDescription = "Favorite",
                            modifier = Modifier.size(ButtonDefaults.IconSize),
                            tint = Color.Black
                        )
                    }
                    Spacer(modifier = Modifier.height(30.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(200.dp),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(2.dp, Color.Black),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),

                        onClick = {

                            var current : User? = null
                            var key : String = ""
                            viewModel.usersComplete.forEach(){user ->
                                if(user.value.role == "user")
                                {    current = user.value
                                    key=user.key
                                }
                            }

                            viewModel.userKey.value = key

                            if(current != null)
                            {   val newUser = viewModel.userUid.value?.let {
                                User(it, current!!.role, current!!.username, current!!.password, current!!.number, current!!.email) }
                                db.child("users").child(""+ key).setValue(newUser)
                            }
                            navController.navigate(Screen.HomeUserScreen.route)
                        },
                    ) {
                        Text(text = "user   ",
                             fontSize = 20.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                        Icon(
                            Icons.Filled.ArrowForward,
                            contentDescription = "Favorite",
                            modifier = Modifier.size(ButtonDefaults.IconSize),
                            tint = Color.Black
                        )
                    }

            }
            }
        }
    }
}  */

//per autenticazione con username e password
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController, viewModel: PurchaseViewModel, authentic :FirebaseAuth) {

    var username by remember {
        mutableStateOf((""))
    }

    var pwd by remember {
        mutableStateOf((""))
    }
    var error by remember {
        mutableStateOf((false))
    }

    var auth by remember {
        mutableStateOf((false))
    }



    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Locker manager",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )

        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(70.dp))
                    Row() {
                        Text(
                        text = "Login",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }
                    Spacer(modifier = Modifier.height(20.dp))
                    OutlinedTextField(
                        value = username,
                        onValueChange = { newText ->
                            username = newText
                        },
                        label = {
                            Text(text = "Email")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(5.dp))
                    OutlinedTextField(
                        value = pwd,
                        onValueChange = { newText ->
                            pwd = newText
                        },
                        label = {
                            Text(text = "Password")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    Button(
                        modifier = Modifier
                            .bounceClick()
                            .height(45.dp)
                            .width(120.dp),
                        shape = RoundedCornerShape(20.dp),
                        onClick = {

                            if (username != "" && pwd != "") {

                                authentic.signInWithEmailAndPassword(username, pwd)
                                    .addOnCompleteListener { task ->
                                        if (task.isSuccessful) {

                                            var role = ""

                                            viewModel.users.forEach(){item->
                                                if(item.email==username && item.password==pwd)
                                                {   role = "user"
                                                    viewModel.currentUser.value = item
                                                    viewModel.currentRole.value = "user"
                                                }
                                            }

                                            viewModel.sellers.forEach(){item->
                                                if(item.email==username && item.password==pwd)
                                                {    role = "seller"
                                                     viewModel.currentSeller.value = item
                                                     viewModel.currentRole.value = "seller"
                                                }
                                            }

                                            if(role=="seller")
                                               navController.navigate(Screen.HomeSellerScreen.route)
                                            else
                                                navController.navigate(Screen.HomeUserScreen.route)

                                            viewModel.user = MutableLiveData(authentic.currentUser)
                                            viewModel.userKey.value = username

                                            Log.w("Login", "username "+viewModel.userKey.value)
                                            val user = authentic.currentUser

                                        } else {
                                            Log.w("Login", "signInWithEmail:failure", task.exception)
                                            error = true
                                        }
                                    }
                            } else {
                                error = true
                            }
                        },
                        content = { Text( text="Login",
                                          fontSize = 16.sp ) }
                    )

                    Spacer(modifier = Modifier.height(30.dp))

                    ClickableText(
                        text = AnnotatedString("Registrati"),

                        onClick = { navController.navigate(Screen.RegisterUserScreen.route)
                            Log.d("aaaaa", "currentuserfirebase : "+authentic.currentUser)
                            //navController.navigate(Screen.RegisterSellerScreen.route)

                       /*     viewModel.users.forEach(){u->
                                Log.d("aaaa", "FirebaseUtenti : "+ u)

                            }
                            viewModel.sellers.forEach(){s->
                                Log.d("aaaa", "FirebaseUtentiSell : "+ s)

                            }
                            viewModel.products.forEach(){p->
                                Log.d("aaaa", "FirebaseUtentiProd : "+ p)

                            }  */

                     /*      Log.d("aaaa", "FirebaseUtentifavs size at  pt1 "+ viewModel.favsComplete.get("user1"))
                            Log.d("aaaa", "FirebaseUtentifavs numero "+viewModel.favsComplete.keys.size)
                            viewModel.favsComplete.forEach(){f->

                                Log.d("aaaa", "FirebaseUtentifavs keys "+ f.key)
                                Log.d("aaaa", "FirebaseUtentifavs size values "+ f.value.size)

                                f.value.forEach() {v->
                                    Log.d("aaaa", "FirebaseUtentifavs values "+ v)
                                }

                              //  var shops = viewModel.favsComplete[f]


                        /*      if (shops != null) {
                                    shops.forEach(){s->
                                        Log.d("aaaa", "FirebaseUtentifavs "+f+": "+s)
                                    }
                                } */

                            } */
                        } ,

                    )

                    if (error) {
                            AlertDialog(
                                onDismissRequest = { error = false },
                                text = { Text("Errore username e/o password") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        onClick = {
                                            error = false
                                            username = ""
                                            pwd = ""
                                        }
                                    ) {
                                        Text("OK")
                                    }
                                }
                            )

                    }
                }
            }
        }
    }



/*
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeSellerScreen(navController: NavController, viewModel: PurchaseViewModel, db:DatabaseReference) {

    var isExpanded by remember {
        mutableStateOf(false)
    }

    var showAlert by remember {
        mutableStateOf(false)
    }

    var added by remember {
        mutableStateOf(false)
    }
    var found by remember {
        mutableStateOf(false)
    }

    var locker by remember {
        mutableStateOf("")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "   Nuova consegna",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.HistorySellerScreen.route) }) {
                        Icon(
                            imageVector =  Icons.Filled.DateRange,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Spacer(modifier = Modifier.height(100.dp))
                    Row() { Text(
                        text = "Nuova consegna:",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold ) }
                    Spacer(modifier = Modifier.height(30.dp))
                    ExposedDropdownMenuBox(
                        expanded = isExpanded,
                        onExpandedChange = {
                            isExpanded = !isExpanded
                        }
                    ) {
                        TextField(
                            value = locker,
                            onValueChange = { },
                            readOnly = true,
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                            },
                            placeholder = {
                                    Text(text = "scegli un locker")
                            },
                            colors = ExposedDropdownMenuDefaults.textFieldColors(),
                            modifier = Modifier.menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = isExpanded,
                            onDismissRequest = {
                                isExpanded = !isExpanded
                            }
                        ) {
                             viewModel.lockersList.forEach { lock ->

                                 var available = false

                                 lock.spaces.forEach() {space->
                                     if(space.free)
                                        available = true
                                 }

                                 if(available)
                                 {
                                     DropdownMenuItem(
                                         text = { Text(text = "" + lock.id_locker) },
                                         onClick = {
                                             locker = "" + lock.id_locker
                                             isExpanded = false

                                         }
                                     )
                                 }
                            }

                            if(viewModel.lockersList.isEmpty())
                            {
                                DropdownMenuItem(
                                    text = { Text(text = "nessun locker libero") },
                                    onClick = {}
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.height(30.dp))
                    //ADD BUTTON
                    FloatingActionButton(
                        containerColor = MaterialTheme.colorScheme.primary,
                        elevation = FloatingActionButtonDefaults.elevation(),
                        modifier = Modifier.bounceClick(),
                        onClick = {
                            if(locker!="")
                            {
                               viewModel.lockersList.forEach() {lTemp ->
                                   if(lTemp.id_locker == ""+locker && !found)
                                   {
                                       lTemp.spaces.forEach() {space ->
                                           if(space.free && !found)
                                           {
                                               found = true

                                               val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
                                               val current = LocalDateTime.now().format(formatter)

                                               val parts = current.split(" | ")
                                               val date = parts[0]
                                               val time = parts[1]

                                               val delivery = Consegna("iniziata", date, time, date, time, ""+viewModel.userKey.value, "user@polito.it",
                                                   ""+locker, space.name, space.code_ins, space.code_rit)
                                               val lockerNew = LockerSpace(space.name, false, space.code_ins, space.code_rit)

                                             //  db.child("delivery").push().setValue(delivery)
                                            //   db.child("lockers").child(""+locker).child(""+space.name).setValue(lockerNew)

                                               db.child("lockers").child(""+locker) //.child(""+space.name)
                                                   .runTransaction(object : Transaction.Handler {
                                                       override fun doTransaction(p0: MutableData): Transaction.Result {
                                                           //any operation
                                                           db.child("lockers").child(""+locker).child(""+space.name).setValue(lockerNew)
                                                           return Transaction.success(p0)
                                                       }

                                                       override fun onComplete(error: DatabaseError?, p1: Boolean, snapshot: DataSnapshot?) {
                                                           Log.d("aaa", "FIREBASE TRANS COMPLETATA")
                                                           db.child("delivery").push().setValue(delivery)
                                                       }
                                                   })

                                               showAlert = true
                                               added = true
                                           }
                                       }
                                   }
                               }
                            }
                            else
                                showAlert = true

                        },
                        content = {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                    )
                }

                if (showAlert) {
                        AlertDialog(
                            onDismissRequest = { showAlert = false },
                            text = {
                                if(added)
                                  Text("Consegna aggiunta correttamente!")
                                else
                                    Text("Scegli un locker tra quelli nel menu!") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    onClick = {
                                        showAlert = false
                                        found=false
                                        added = false
                                        locker = ""

                                    }
                                ) {
                                    Text("OK")
                                }
                            }
                        )
                }

            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistorySellerScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference) {

    // per far comparire la scitta "nessuna" nel caso in cui i pacchi vengano consegnati
    viewModel.deliveriesComplete.forEach(){del ->

        if (del.value.status == "iniziata" && del.value.id_mittente==viewModel.userKey.value)
            viewModel.addInProg(del.key, del.value)
    }

    var progclicked by remember { mutableStateOf(true) }

    var endclicked by remember { mutableStateOf(false) }

    var emptyEnd by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "   I miei ordini",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                        Icon(
                            imageVector = Icons.Filled.Create,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {}
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {

                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Spacer(modifier = Modifier.height(25.dp))
                    Row() {
                        Text(
                            text = "Storico delle consegne",
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(50.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            modifier = Modifier
                                .bounceClick()
                                .height(40.dp)
                                .width(130.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = if(progclicked) Color.LightGray else Color.Transparent, contentColor = Color.Black),

                            onClick = {
                                viewModel.clearDeliveriesOrder()
                                viewModel.orderDeliveries("In corso")
                                progclicked = true
                                endclicked = false
                            },
                            content = { Text("In corso") }
                        )

                        OutlinedButton(
                            modifier = Modifier
                                .bounceClick()
                                .height(40.dp)
                                .width(130.dp),
                            shape = RoundedCornerShape(20.dp),

                            colors = ButtonDefaults.outlinedButtonColors(containerColor = if(endclicked) Color.LightGray else Color.Transparent, contentColor = Color.Black),
                            onClick = {
                                viewModel.clearDeliveriesOrder()
                                viewModel.orderDeliveries("Terminate")
                                progclicked = false
                                endclicked = true
                            },
                            content = { Text("Terminate") }
                        )
                    }

                    Spacer(modifier = Modifier.height(25.dp))

                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalAlignment = Alignment.Start,
                    )
                    {

                        viewModel.deliveries.forEach() { del ->

                            if (del.status != "iniziata" && del.id_mittente == viewModel.userKey.value)
                                emptyEnd = false
                        }
                        if (viewModel.inProgress.isEmpty() && progclicked) {
                            Row() {
                                Text(text = "Al momento non sono presenti consegne in corso")
                            }
                        } else if (emptyEnd && endclicked) {
                            Row() {
                                Text(text = "Al momento non sono presenti consegne terminate")
                            }
                        }


                        viewModel.deliveriesOrdered.forEach { del ->
                            if (del.value.id_mittente == viewModel.userKey.value) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .drawBehind {

                                            if (!viewModel.expanded.contains(del.key)) {
                                                val strokeWidth = 1.dp.toPx()

                                                drawLine(
                                                    color = Color.LightGray,
                                                    start = Offset(0f, size.height),
                                                    end = Offset(size.width, size.height),
                                                    strokeWidth = strokeWidth
                                                )
                                            }
                                        }
                                        .padding(vertical = 10.dp)

                                ) {

                                    Text(
                                        text = del.key + "      ",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp
                                    )
                                    if (viewModel.deliveriesOrdered.isNotEmpty() == true) {

                                        val isExpanded =
                                            del.key in viewModel.expanded//expandedCategories

                                        val arrowIcon =
                                            if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown

                                        Icon(
                                            imageVector = arrowIcon,
                                            contentDescription = null,


                                            modifier = Modifier.clickable {
                                                if (isExpanded) {
                                                    viewModel.removeExpanded(del.key)
                                                } else {
                                                    viewModel.addExpanded(del.key)
                                                }
                                            }
                                        )
                                    } else {
                                        if (viewModel.expanded.contains(del.key))
                                            viewModel.removeExpanded(del.key)
                                    }

                                }
                                AnimatedVisibility(
                                    visible = del.key in viewModel.expanded,
                                    enter = fadeIn() + expandVertically(),
                                    exit = fadeOut() + shrinkVertically()
                                ) {
                                    Column() {
                                        DeliveryItem(del.key, del.value, db, viewModel, false)
                                    }
                                }

                            }
                        }
                    }
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeUserScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference) {

    //per far comparire la scritta "nessuna" nel caso in cui tutte le consegne vengano ritirate
    viewModel.deliveriesComplete.forEach(){del ->

        if (del.value.status == "pacco depositato" && del.value.id_destinatario==viewModel.userKey.value)
            viewModel.addInProg(del.key, del.value)
    }

    //non serve fare accesso al viewmodel per questo perche quando si cambia pagina vengono distrutte
    var expandedCategories by remember { mutableStateOf(setOf<String>()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "   Le tue consegne",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.HistoryUserScreen.route) }) {
                        Icon(
                            imageVector = Icons.Filled.DateRange,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {}
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {

                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Spacer(modifier = Modifier.height(20.dp))
                    Row() {
                        Text(
                            text = "Consegne in corso",
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }
                    Spacer(modifier = Modifier.height(35.dp))

                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalAlignment = Alignment.Start,
                    )
                    {

                        if (viewModel.inProgress.isEmpty()) {
                            Row() { Text(text = "Al momento non sono presenti consegne da ritirare") }
                        }
                        else {
                            viewModel.deliveriesComplete.forEach { del ->
                                if (del.value.id_destinatario == viewModel.userKey.value) {
                                    if (del.value.status == "pacco depositato") {

                                        /*    OutlinedCard(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                    ),
                                    border = BorderStroke(1.dp, Color.Black),
                                    modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
                                ) {

                             */
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .drawBehind {

                                                    if (!expandedCategories.contains(del.key)) {
                                                        val strokeWidth = 1.dp.toPx()

                                                        drawLine(
                                                            color = Color.LightGray,
                                                            start = Offset(0f, size.height),
                                                            end = Offset(size.width, size.height),
                                                            strokeWidth = strokeWidth
                                                        )
                                                    }
                                                }
                                                .padding(vertical = 10.dp)

                                        ) {

                                            Text(
                                                text = "" + del.key + "        ",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 20.sp
                                            )
                                            if (viewModel.deliveriesComplete.isNotEmpty() == true) {

                                                val isExpanded = del.key in expandedCategories
                                                val arrowIcon =
                                                    if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown

                                                Icon(
                                                    imageVector = arrowIcon,
                                                    contentDescription = null,


                                                    modifier = Modifier.clickable {
                                                        expandedCategories = if (isExpanded) {
                                                            expandedCategories - del.key
                                                        } else {
                                                            expandedCategories + del.key
                                                        }
                                                    }
                                                )
                                            } else {
                                                if (expandedCategories.contains(del.key))
                                                    expandedCategories =
                                                        expandedCategories - del.key

                                            }

                                            //  }
                                        }

                                        AnimatedVisibility(
                                            visible = del.key in expandedCategories,
                                            enter = fadeIn() + expandVertically(),
                                            exit = fadeOut() + shrinkVertically()
                                        ) {
                                            Column() {
                                                DeliveryItem(
                                                    del.key,
                                                    del.value,
                                                    db,
                                                    viewModel,
                                                    true
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryUserScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference) {

    var expandedCategories by remember { mutableStateOf(setOf<String>()) }

    var empty by remember { mutableStateOf(true) }

    //qui non è necessario tracciare se le consegne cambiano di stato

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "   Le tue consegne",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                        Icon(
                            imageVector = Icons.Filled.Menu,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {}
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {

                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Spacer(modifier = Modifier.height(25.dp))
                    Row() {
                        Text(
                            text = "Storico delle consegne",
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }
                    Spacer(modifier = Modifier.height(35.dp))

                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalAlignment = Alignment.Start,
                    )
                    {

                        viewModel.deliveries.forEach() { del ->
                            if (del.id_destinatario == viewModel.userKey.value) {
                                if (del.status == "pacco ritirato" || del.status == "superato tempo massimo")
                                    empty = false
                            }
                        }
                                if (empty) {
                                    Row() {
                                        Text(text = "Al momento non sono presenti consegne completate")
                                    }
                                } else {
                                    viewModel.deliveriesComplete.forEach { del ->
                                        if (del.value.id_mittente == viewModel.userKey.value) {
                                        if (del.value.status == "pacco ritirato" || del.value.status == "superato tempo massimo") {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .drawBehind {

                                                        if (!expandedCategories.contains(del.key)) {
                                                            val strokeWidth = 1.dp.toPx()

                                                            drawLine(
                                                                color = Color.LightGray,
                                                                start = Offset(0f, size.height),
                                                                end = Offset(
                                                                    size.width,
                                                                    size.height
                                                                ),
                                                                strokeWidth = strokeWidth
                                                            )
                                                        }
                                                    }
                                                    .padding(vertical = 10.dp)

                                            ) {
                                                Text(
                                                    text = del.key + "      ",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 20.sp
                                                )
                                                if (viewModel.deliveriesComplete.isNotEmpty()) {

                                                    val isExpanded = del.key in expandedCategories
                                                    val arrowIcon =
                                                        if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown

                                                    Icon(
                                                        imageVector = arrowIcon,
                                                        contentDescription = null,


                                                        modifier = Modifier.clickable {
                                                            expandedCategories = if (isExpanded) {
                                                                expandedCategories - del.key
                                                            } else {
                                                                expandedCategories + del.key
                                                            }
                                                        }
                                                    )
                                                } else {
                                                    if (expandedCategories.contains(del.key))
                                                        expandedCategories =
                                                            expandedCategories - del.key

                                                }

                                            }

                                            AnimatedVisibility(
                                                visible = del.key in expandedCategories,
                                                enter = fadeIn() + expandVertically(),
                                                exit = fadeOut() + shrinkVertically()
                                            ) {
                                                Column() {
                                                    DeliveryItem(
                                                        del.key,
                                                        del.value,
                                                        db,
                                                        viewModel,
                                                        true
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                    }
                }
            }
        }
    }
}

private fun mToast(context: Context, text: String){
    Toast.makeText(context, ""+text, Toast.LENGTH_LONG).show()
}


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun DeliveryItem(id: String, del : Consegna, db : DatabaseReference, viewModel: PurchaseViewModel, isUser : Boolean) {

    var showAlert by remember {
        mutableStateOf(false)
    }

    val mContext = LocalContext.current

    Column() {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        )
        {
            Text(
                text = "Stato consegna: ",
                fontWeight = FontWeight.Bold )
            Text( text = "" + del.status)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        )
        { Text(text = "Inizio: ",
            fontWeight = FontWeight.Bold )
            Text(text = "" + del.date_Start + ", " + del.time_Start) }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        )
        { Text(text = "Aggiornamento: ",
            fontWeight = FontWeight.Bold )
            Text(text = "" + del.date_Update + ", " + del.time_Update) }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        )
        { Text(text = "Locker: ",
            fontWeight = FontWeight.Bold )
            Text(text = "" + del.locker+ ", " + del.locker_space) }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        )
        {
            if(isUser)
            { Text(
                text = "Mittente: ",
                fontWeight = FontWeight.Bold )
            Text( text = "" + del.id_mittente) }
            else
            { Text(
                text = "Destinatario: ",
                fontWeight = FontWeight.Bold )
                Text( text = "" + del.id_destinatario) }
        }

        if(!isUser && del.status=="iniziata")
        {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            )
            {
                    Text(
                        text = "Codice di inserimento: ",
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = "" + del.code_inserimento) }
        }
        if (isUser && del.status == "pacco depositato")
        {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            )
            {
                Text(
                    text = "Codice di sblocco: ",
                    fontWeight = FontWeight.Bold
                )
                Text(text = "" + del.code_inserimento) }
        }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        val strokeWidth = 1.dp.toPx()

                        drawLine(
                            color = Color.LightGray,
                            start = Offset(0f, size.height),
                            end = Offset(size.width, size.height),
                            strokeWidth = strokeWidth
                        )
                    }
                    .padding(vertical = 10.dp)

            ) {

                if(!isUser && del.status == "iniziata") {
                OutlinedButton(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                    onClick = { showAlert = true },
                    content = { Text("Pacco in consegna") }
                )
            }
                else if(isUser && del.status == "pacco depositato") {
                        OutlinedButton(
                            modifier = Modifier.bounceClick(),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = Color.Black),
                            onClick = { showAlert = true },
                            content = { Text("Pacco in ritiro") }
                        )
                    }
        }
    }

    if (showAlert) {
        AlertDialog(
            onDismissRequest = {
                showAlert = false
            },
            text = {
                if(!isUser)
                   Text("Confermi che la consegna è stata effettuata?")
                else
                    Text("Confermi che il pacco è stato ritirato?") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                      //  showAlert = false

                        
                       //    mToast(mContext, "Consegna terminata")

                        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
                        val current = LocalDateTime.now().format(formatter)

                        val parts = current.split(" | ")
                        val date = parts[0]
                        val time = parts[1]


                        var deliveryNew : Consegna? = null

                        if(!isUser)
                          deliveryNew = Consegna("pacco depositato", del.date_Start, del.time_Start, date, time, del.id_mittente, del.id_destinatario,
                            ""+del.locker, del.locker_space, del.code_inserimento, del.code_sblocco)
                        else
                          deliveryNew = Consegna("pacco ritirato", del.date_Start, del.time_Start, date, time, del.id_mittente, del.id_destinatario,
                            ""+del.locker, del.locker_space, del.code_inserimento, del.code_sblocco)


                        db.child("delivery").child(""+id).setValue(deliveryNew)

                        viewModel.removeExpanded(id)
                        viewModel.removeInProg(id, del)

                    //    viewModel.removeOrder(id, del)

                     //   viewModel.clearDeliveriesOrder()
                     //   viewModel.orderDeliveries("In corso")

                    }
                ) {
                    Text("OK!")
                }
            },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                        showAlert = false
                    }
                ) {
                    Text("Annulla")
                }
            },
        )
    }
}
*/













