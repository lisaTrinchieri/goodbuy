package it.polito.laib_3.registration

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.User
import it.polito.laib_3.bounceClick
import it.polito.laib_3.saveImageToInternalStorage

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterUserScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic :FirebaseAuth, storage: StorageReference) {

    val context = LocalContext.current

    var username by remember { mutableStateOf(("")) }
    var pwd by remember { mutableStateOf(("")) }
    var email by remember { mutableStateOf(("")) }
    var telephone by remember { mutableStateOf(("")) }
    var imageName by remember { mutableStateOf(("")) }

    var error by remember { mutableStateOf((false)) }
    var confirm by remember { mutableStateOf((false)) }
    var already by remember { mutableStateOf((false)) }

    var alreadyUploaded by remember { mutableStateOf(false) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    val bitmap = remember { mutableStateOf<Bitmap?>(null) }


    val launcher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            saveImageToInternalStorage(context, it)
        }
        imageUri = uri
    }



     Scaffold(
          topBar = {
              TopAppBar(
                  title = {},
                  colors = TopAppBarDefaults.smallTopAppBarColors(
                      containerColor = MaterialTheme.colorScheme.primary,
                      titleContentColor = Color.White,
                  ),
                  navigationIcon = {
                      IconButton(onClick = { navController.navigate(Screen.SelectRoleScreen.route) }) {
                          Icon(

                              imageVector = Icons.Filled.ArrowBack,
                              contentDescription = "to show",
                              tint = Color.White,
                          )
                      }
                  },
              )
          },
          bottomBar = {
              BottomAppBar(
                  modifier = Modifier.height(20.dp),
                  containerColor = MaterialTheme.colorScheme.primary,
                  contentColor = MaterialTheme.colorScheme.primary,
              ) {
              }
          },

          ) { innerPadding ->

          LazyColumn(
              modifier = Modifier
                  .padding(innerPadding),
              verticalArrangement = Arrangement.spacedBy(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally
          ) {
              item {
                  Column(
                      modifier = Modifier
                          .padding(16.dp)
                          .fillMaxWidth(),
                      // horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                      Spacer(modifier = Modifier.height(40.dp))
                      Row() {
                          Text(
                              text = "Registrazione",
                              fontWeight = FontWeight.Bold,
                              fontSize = 30.sp,
                              modifier = Modifier.align(alignment = Alignment.CenterVertically)
                          )
                      }
                      Spacer(modifier = Modifier.height(30.dp))


                      Row() {
                          Text(
                              text = "Username",
                              fontSize = 15.sp,
                          )
                      }

                      OutlinedTextField(
                          value = username,
                          onValueChange = { newText ->
                              username = newText
                          },
                          placeholder = {
                              Text(text = "Es. Mario_rossi")
                          },
                          keyboardOptions = KeyboardOptions(
                              keyboardType = KeyboardType.Text,
                              imeAction = ImeAction.Done
                          ),
                      )
                      Spacer(modifier = Modifier.height(15.dp))

                      Row() {
                          Text(
                              text = "Numero di telefono",
                              fontSize = 15.sp,
                          )
                      }
                      OutlinedTextField(
                          value = telephone,
                          onValueChange = { newText ->
                              telephone = newText
                          },
                          placeholder = {
                              Text(text = "Es. 332788937")
                          },
                          keyboardOptions = KeyboardOptions(
                              keyboardType = KeyboardType.Number,
                              imeAction = ImeAction.Done
                          ),
                      )
                      Spacer(modifier = Modifier.height(15.dp))

                      Row() {
                          Text(
                              text = "Email",
                              fontSize = 15.sp,
                          )
                      }
                      OutlinedTextField(
                          value = email,
                          onValueChange = { newText ->
                              email = newText
                          },
                          placeholder = {
                              Text(text = "Es. Mario@gmail.com")
                          },
                          keyboardOptions = KeyboardOptions(
                              keyboardType = KeyboardType.Text,
                              imeAction = ImeAction.Done
                          ),
                      )
                      Spacer(modifier = Modifier.height(15.dp))


                      Row() {
                          Text(

                              text = "Password",
                              fontSize = 15.sp,
                          )
                      }
                      OutlinedTextField(
                          value = pwd,
                          onValueChange = { newText ->
                              pwd = newText
                          },
                          placeholder = {
                              Text(text = "Password")
                          },
                          keyboardOptions = KeyboardOptions(
                              keyboardType = KeyboardType.Text,
                              imeAction = ImeAction.Done
                          ),
                      )
                      Spacer(modifier = Modifier.height(20.dp))



                      Row(
                          modifier = Modifier.fillMaxWidth(),
                          horizontalArrangement = Arrangement
                              .spacedBy(
                                  space = 20.dp,
                                  alignment = Alignment.CenterHorizontally
                              ),
                      )
                      {
                          Button(
                              modifier = Modifier
                                  .bounceClick()
                                  .height(45.dp)
                                  .width(130.dp),
                              shape = RoundedCornerShape(10.dp),
                              onClick = {

                                  if (username == "" || pwd == "" || email == "" || telephone == "")
                                      error = true
                                  else {

                                      val user = User(username.replace(" ", ""), pwd.replace(" ", ""),
                                              email.replace(" ", ""), telephone.replace(" ", ""))

                                      viewModel.users.forEach(){ u ->

                                          if(u.email == email)
                                              already = true
                                      }



                                      if (!already) {

                                        //  uploadImageToFirebase(imageUri!!)

                                          db.child("users").push().setValue(user)
                                          viewModel.currentUser.value = user

                                          authentic.createUserWithEmailAndPassword(email, pwd)
                                              .addOnCompleteListener { task ->
                                                  if (task.isSuccessful) {
                                                      // Sign in success, update UI with the signed-in user's information
                                                      Log.d("aaaaa", "createUserWithEmail:success")

                                                      val user = authentic.currentUser
                                                      confirm = true

                                                      Log.d("aaaaa", "currentUser registration : "+authentic.currentUser)
                                                      //  navController.navigate(Screen.HomeUserScreen.route)

                                                  } else {
                                                      Log.w("aaa", "createUserWithEmail:failure", task.exception)
                                                  }
                                              }
                                      }
                                  }


                              },
                              content = {
                                  Text(
                                      text = "Conferma",
                                      fontSize = 16.sp
                                  )
                              }
                          )

                          Button(
                              modifier = Modifier
                                  .bounceClick()
                                  .height(45.dp)
                                  .width(130.dp),
                              shape = RoundedCornerShape(10.dp),
                              onClick = {

                                  pwd = ""
                                  username = ""
                                  email = ""
                                  telephone = ""
                              },
                              content = {
                                  Text(
                                      text = "Svuota",
                                      fontSize = 16.sp
                                  )
                              }
                          )

                      }


                      if (error) {
                          AlertDialog(
                              onDismissRequest = { error = false },
                              text = { Text("E' necessario riempire tutti i campi prima di procede alla registrazione") },
                              confirmButton = {
                                  Button(
                                      modifier = Modifier.bounceClick(),
                                      onClick = { error = false }
                                  ) {
                                      Text("OK")
                                  }
                              }
                          )

                      }

                      if (confirm) {
                          AlertDialog(
                              onDismissRequest = { confirm = false },
                              text = { Text("Registrazione avvenuta con successo") },
                              confirmButton = {
                                  Button(
                                      modifier = Modifier.bounceClick(),
                                      onClick = {
                                          confirm = false
                                          navController.navigate(Screen.HomeUserScreen.route)
                                      }
                                  ) {
                                      Text("OK")
                                  }
                              }
                          )

                      }

                      if (already) {
                          AlertDialog(
                              onDismissRequest = { already = false },
                              text = { Text("Indirizzo email già associato ad un altro profilo") },
                              confirmButton = {
                                  Button(
                                      modifier = Modifier.bounceClick(),
                                      onClick = { already = false }
                                  ) {
                                      Text("OK")
                                  }
                              }
                          )

                      }

                  }

              }
          }
          //}
      }
}

