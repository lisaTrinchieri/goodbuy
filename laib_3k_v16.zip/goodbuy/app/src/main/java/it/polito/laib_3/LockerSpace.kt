package it.polito.laib_3

data class LockerSpace(

    val name: String,
    var free: Boolean,
    val code_ins: Int,
    val code_rit: Int,
    val dimension:String,
    val address: String,
    val positionX: Int,
    val positionY: Int,
    val open: Boolean,
    val delivery: String

)
