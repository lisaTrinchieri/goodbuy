package it.polito.laib_3.seller

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.BottomAppBarDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.messaging.FirebaseMessaging
import it.polito.laib_3.Consegna
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.User
import it.polito.laib_3.formatCurrency
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeSellerScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {

    subscribeSeller(viewModel)

    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
    val current = LocalDateTime.now().format(formatter)

    val parts1 = current.split(" | ")
    val date = parts1[0]
    val time = parts1[1]

    val tom = LocalDateTime.now().plusDays(1).format(formatter)
    val parts2 = tom.split(" | ")
    val dateTom = parts2[0]

    Log.d("cccc", "current seller : " + viewModel.currentSeller.value)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Goodbuy") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                actions = {
                    var count = 0
                    viewModel.deliveries.forEach() { del ->
                        if (del.status == "started" && del.id_mittente == viewModel.currentSeller.value?.name ?: "")
                            count++
                    }
                    if (count > 0) {
                        BadgedBox(
                            modifier = Modifier
                                .wrapContentSize()
                                .padding(end = 20.dp),
                            badge = { Badge() { Text("$count") } })
                        {
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                modifier = Modifier.clickable { navController.navigate(Screen.OrdersStartedScreen.route) },
                                tint = Color.White,
                            )
                        }
                    } else {
                        IconButton(onClick = { navController.navigate(Screen.OrdersStartedScreen.route) }) {
                            Icon(
                                imageVector = Icons.Filled.Notifications,
                                contentDescription = "to show",
                                tint = Color.White,
                            )
                        }
                    }
                },
            )
        },

        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {

                        IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.SellerLockerScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.lock),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.SellerOrdersScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.SellerProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                item {
                    Column(
                        modifier = Modifier
                            //   .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Ordini da preparare",
                                fontWeight = FontWeight.Bold,
                                fontSize = 25.sp,
                            )

                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(colorResource(id = R.color.green))
                            )
                            {
                                Text(
                                    modifier = Modifier.padding(
                                        horizontal = 16.dp,
                                        vertical = 4.dp
                                    ),
                                    text = "OGGI",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                )
                            }

                        }

                        Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                        var empty = true

                        viewModel.deliveries.forEach() { del ->
                            if (del.status == "inProgress" && (del.rejected == "" || del.rejected == "superato tempo massimo")
                                && del.date_Due == date && del.id_mittente == viewModel.currentSeller.value?.name ?: ""
                            )
                                empty = false
                        }

                        if (empty) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Gray),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    modifier = Modifier.padding(16.dp),
                                    color = Color.Black,
                                    text = "Non sono presenti ordini da preparare per oggi.",
                                    fontSize = 18.sp,
                                )
                            }

                        } else {
                            viewModel.deliveries.forEach() { del ->
                                if (del.status == "inProgress" && (del.rejected == "" || del.rejected == "superato tempo massimo")
                                    && del.date_Due == date && del.id_mittente == viewModel.currentSeller.value?.name ?: ""
                                ) {

                                    val oraActual = LocalTime.now()
                                    val delHour = del.time_Due.split(":")
                                    val hh = delHour[0]
                                    val mm = delHour[1]

                                    val delHour2 = LocalTime.of(hh.toInt(), mm.toInt())
                                    val isPrecedente = delHour2.isBefore(oraActual)


                                    val halfHourBeforeNow = oraActual.minusMinutes(30)
                                    val mins =
                                        if (delHour2.isBefore(halfHourBeforeNow)) true else false

                                    if (isPrecedente && del.status == "inProgress" && mins && del.rejected == "") {
                                        var code = ""

                                        viewModel.deliveriesComplete.forEach() { delivery ->
                                            if (delivery.value == del)
                                                code = delivery.key
                                        }

                                        //   var del = viewModel.currentDelivery.value
                                        var updatedDel = del?.let {
                                            Consegna(
                                                "inProgress",
                                                it.date_Start,
                                                del.time_Start,
                                                date,
                                                time,
                                                del.date_Due,
                                                del.time_Due,
                                                del.id_mittente,
                                                del.id_destinatario,
                                                del.locker,
                                                del.locker_space,
                                                del.code_inserimento,
                                                del.code_sblocco,
                                                del.products,
                                                del.price,
                                                del.payment,
                                                "superato tempo massimo"
                                            )
                                        }

                                        db.child("deliveries").child("" + code).setValue(updatedDel)

                                        var id = ""
                                        var user: User = User("", "", "", "", "")

                                        viewModel.usersComplete.forEach() { u ->
                                            if (u.value.email == del.id_destinatario) {
                                                id = u.key
                                                user = u.value
                                            }
                                        }


                                        var credito = user.credito.toDouble() + del.price


                                        var updated = false

                                        val newUser = user?.let {
                                            User(
                                                user.username,
                                                it.password,
                                                user.email,
                                                user.number,
                                                formatCurrency(credito).toString()
                                            )
                                        }

                                        if (!updated) {
                                            db.child("users").child(id).setValue(newUser)
                                            updated = true
                                        }
                                    }

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.LightGray)
                                            .padding(16.dp),
                                        horizontalArrangement = Arrangement.Start,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Button(
                                            modifier = Modifier
                                                .height(105.dp)
                                                .fillMaxWidth(),
                                            onClick = {
                                                navController.navigate(Screen.OrderDetailSeller.route)
                                                viewModel.currentDelivery.value = del
                                                viewModel.currentDay.value = "oggi"
                                            },
                                            enabled = if (mins) false else true,
                                            shape = RectangleShape,
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = Color.LightGray,
                                                contentColor = Color.White
                                            ),
                                        ) {

                                            Box(
                                                modifier = Modifier
                                                    .height(105.dp)
                                                    .width(250.dp)
                                            ) {
                                                Column() {
                                                    Spacer(modifier = Modifier.height(5.dp))
                                                    Row() {
                                                        Icon(
                                                            imageVector = Icons.Default.LocationOn,
                                                            contentDescription = "Favorite Item",
                                                            tint = Color.Black
                                                        )
                                                        Spacer(modifier = Modifier.width(25.dp))

                                                        var address = ""
                                                        viewModel.lockersList.forEach() { lock ->
                                                            if (lock.id_locker == del.locker)
                                                                address = lock.spaces[0].address
                                                        }


                                                        Text(
                                                            text = "" + address,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 18.sp,
                                                            color = Color.Black
                                                            //  textAlign = TextAlign.Left,
                                                        )
                                                    }

                                                    Spacer(modifier = Modifier.height(3.dp))
                                                    Row() {

                                                        val parti1 = time.split(":")
                                                        val startTime = LocalTime.of(
                                                            parti1[0].toInt(),
                                                            parti1[1].toInt()
                                                        ) // Esempio: 09:00

                                                        val parti2 = del.time_Due.split(":")
                                                        val endTime = LocalTime.of(
                                                            parti2[0].toInt(),
                                                            parti2[1].toInt()
                                                        )

                                                        val duration =
                                                            Duration.between(startTime, endTime)

                                                        // Ottieni il numero di ore e minuti dalla durata
                                                        val hours = duration.toHours()
                                                        val minutes = duration.toMinutes() % 60

                                                        if (hours.toInt() != 0) {
                                                            Spacer(modifier = Modifier.width(60.dp))

                                                            var username = ""
                                                            viewModel.users.forEach() { u ->
                                                                if (u.email == del.id_destinatario)
                                                                    username = u.username

                                                            }

                                                            Text(
                                                                text = "" + username,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 18.sp,
                                                                //  textAlign = TextAlign.Left,
                                                            )
                                                        } else {
                                                            Text(
                                                                text = "orario superato",
                                                                fontSize = 16.sp,
                                                                color = Color.Red
                                                            )
                                                        }

                                                    }
                                                    Spacer(modifier = Modifier.height(3.dp))
                                                    Row() {

                                                        val parti1 = time.split(":")
                                                        val startTime = LocalTime.of(
                                                            parti1[0].toInt(),
                                                            parti1[1].toInt()
                                                        ) // Esempio: 09:00

                                                        val parti2 = del.time_Due.split(":")
                                                        val endTime = LocalTime.of(
                                                            parti2[0].toInt(),
                                                            parti2[1].toInt()
                                                        )

                                                        val duration =
                                                            Duration.between(startTime, endTime)

                                                        // Ottieni il numero di ore e minuti dalla durata
                                                        val hours = duration.toHours()
                                                        val minutes = duration.toMinutes() % 60

                                                        if (hours.toInt() != 0) {
                                                            Spacer(modifier = Modifier.width(60.dp))

                                                            var username = ""
                                                            viewModel.users.forEach() { u ->
                                                                if (u.email == del.id_destinatario)
                                                                    username = u.username

                                                            }

                                                            Text(
                                                                text = "Ordine di: " + username,
                                                                //fontWeight = FontWeight.Bold,
                                                                fontSize = 15.sp,
                                                                color = Color.Black
                                                                //  textAlign = TextAlign.Left,
                                                            )
                                                        } else {
                                                            Image(
                                                                painter = painterResource(id = R.drawable.errore),
                                                                contentDescription = "confermato",
                                                                colorFilter = if (isPrecedente) ColorFilter.tint(
                                                                    Color.Red
                                                                ) else ColorFilter.tint(Color.Black),
                                                                modifier = Modifier.size(20.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(15.dp))

                                                            var username = ""
                                                            viewModel.users.forEach() { u ->
                                                                if (u.email == del.id_destinatario)
                                                                    username = u.username

                                                            }

                                                            Text(
                                                                text = "Ordine di: " + username,
                                                                //fontWeight = FontWeight.Bold,
                                                                fontSize = 15.sp,
                                                                color = Color.Black
                                                                //  textAlign = TextAlign.Left,
                                                            )
                                                        }
                                                    }
                                                    Row() {

                                                        Spacer(modifier = Modifier.width(60.dp))

                                                        if (!isPrecedente) {
                                                            Text(
                                                                text = "entro le " + del.time_Due,
                                                                fontSize = 16.sp,
                                                                //  textAlign = TextAlign.Left,
                                                            )
                                                        } else {
                                                            if (!mins) {
                                                                Text(
                                                                    text = "preparazione in ritardo",
                                                                    fontSize = 16.sp,
                                                                    color = Color.Red
                                                                )
                                                            } else {
                                                                Text(
                                                                    text = "orario superato",
                                                                    fontSize = 16.sp,
                                                                    color = Color.Red
                                                                )
                                                            }
                                                        }

                                                    }

                                                }
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .height(105.dp)
                                                    .width(70.dp)
                                                    .wrapContentSize(Alignment.Center)

                                            ) {
                                                if (!mins) {
                                                    Icon(
                                                        Icons.Filled.ArrowForward,
                                                        contentDescription = "Favorite",
                                                        modifier = Modifier.size(ButtonDefaults.IconSize),
                                                        tint = Color.Black
                                                    )


                                                }

                                            }
                                        }
                                        //Divider(color = Color.Black, thickness = 2.dp)
                                    }
                                }
                            }

                            Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                            //DOMANI
                            //Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(colorResource(id = R.color.green))
                                )
                                {
                                    Text(
                                        modifier = Modifier.padding(
                                            horizontal = 16.dp,
                                            vertical = 4.dp
                                        ),
                                        text = "DOMANI",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                    )
                                }
                            }

                            Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                            var emptyTom = true

                            viewModel.deliveries.forEach() { del ->
                                if (del.status == "inProgress" && del.date_Due == dateTom && del.id_mittente == viewModel.currentSeller.value?.name ?: "")
                                    emptyTom = false
                            }

                            if (emptyTom) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color.Gray),
                                    horizontalArrangement = Arrangement.Start,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        modifier = Modifier.padding(16.dp),
                                        text = "Non sono presenti ordini da preparare per domani.",
                                        color = Color.Black,
                                        fontSize = 18.sp,
                                        //  textAlign = TextAlign.Left,
                                    )
                                }
                                Divider(color = colorResource(id = R.color.bar), thickness = 2.dp)

                            } else {

                                viewModel.deliveries.forEach() { del ->
                                    if (del.status == "inProgress" && del.date_Due == dateTom) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.LightGray)
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.Start,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Button(
                                                modifier = Modifier
                                                    .height(105.dp)
                                                    .fillMaxWidth(),
                                                onClick = {
                                                    navController.navigate(Screen.OrderDetailSeller.route)
                                                    viewModel.currentDelivery.value = del
                                                    viewModel.currentDay.value = "domani"
                                                },
                                                shape = RectangleShape,
                                                colors = ButtonDefaults.outlinedButtonColors(
                                                    containerColor = Color.LightGray,
                                                    contentColor = Color.White
                                                ),
                                            ) {

                                                Box(
                                                    modifier = Modifier
                                                        .height(105.dp)
                                                        .width(250.dp)
                                                ) {
                                                    Column() {
                                                        Spacer(modifier = Modifier.height(5.dp))
                                                        Row() {
                                                            Icon(
                                                                imageVector = Icons.Default.LocationOn,
                                                                contentDescription = "Favorite Item",
                                                                tint = Color.Black
                                                            )
                                                            Spacer(modifier = Modifier.width(25.dp))

                                                            var address = ""
                                                            viewModel.lockersList.forEach() { lock ->
                                                                if (lock.id_locker == del.locker)
                                                                    address = lock.spaces[0].address
                                                            }


                                                            Text(
                                                                text = "" + address,
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 18.sp,
                                                                //  textAlign = TextAlign.Left,
                                                            )
                                                        }
                                                        Spacer(modifier = Modifier.height(3.dp))
                                                        Row() {

                                                            Spacer(modifier = Modifier.width(50.dp))

                                                            Text(
                                                                text = "entro le " + del.time_Due,
                                                                fontSize = 16.sp,
                                                                color = Color.Black
                                                                //  textAlign = TextAlign.Left,
                                                            )
                                                        }
                                                        Spacer(modifier = Modifier.height(3.dp))
                                                        Row() {

                                                            Spacer(modifier = Modifier.width(50.dp))

                                                            var username = ""
                                                            viewModel.users.forEach() { u ->
                                                                if (u.email == del.id_destinatario)
                                                                    username = u.username

                                                            }

                                                            Text(
                                                                text = "Ordine di: " + username,
                                                                //fontWeight = FontWeight.Bold,
                                                                fontSize = 18.sp,
                                                                color = Color.Black
                                                                //  textAlign = TextAlign.Left,
                                                            )
                                                        }

                                                    }
                                                }

                                                Box(
                                                    modifier = Modifier
                                                        .height(105.dp)
                                                        .width(70.dp)
                                                        .wrapContentSize(Alignment.Center)

                                                ) {
                                                    Icon(
                                                        Icons.Filled.ArrowForward,
                                                        contentDescription = "Favorite",
                                                        modifier = Modifier.size(ButtonDefaults.IconSize),
                                                        tint = Color.White
                                                    )

                                                }

                                            }
                                        }
                                        Divider(
                                            color = colorResource(id = R.color.bar),
                                            thickness = 2.dp
                                        )
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
    }
}

fun subscribeSeller(viewModel: PurchaseViewModel) {
    viewModel.deliveriesComplete.forEach() { del ->
        if (del.value.id_mittente == viewModel.currentSeller.value?.name ?: "") {
            val topic = "SELLER${del.key.toString().drop(1)}"
            FirebaseMessaging.getInstance().subscribeToTopic("/topics/$topic")
                //   Firebase.messaging.subscribeToTopic("/topics/SELLER+${del.key}")
                .addOnCompleteListener { task ->
                    var msg = "Subscribed to $topic"
                    if (!task.isSuccessful) {
                        msg = "Subscribe failed to $topic"
                    }
                }
        }

    }
}