package it.polito.laib_3.registration

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.saveImageToInternalStorage
import it.polito.laib_3.uploadImageToFirebase
import java.time.LocalTime

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterSellerScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage: StorageReference) {

    val context = LocalContext.current
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    var pwd by remember { mutableStateOf(("")) }
    var email by remember { mutableStateOf(("")) }
    var telephone by remember { mutableStateOf(("")) }
    var name by remember { mutableStateOf(("")) }
    var address by remember { mutableStateOf(("")) }
    var category by remember { mutableStateOf(("")) }

    var missing by remember { mutableStateOf(("")) }

    var start by remember { mutableStateOf(("")) }
    var stop by remember { mutableStateOf(("")) }
    var hourStart by remember { mutableStateOf(("")) }
    var hourEnd by remember { mutableStateOf(("")) }
    var startEx by remember { mutableStateOf(("")) }
    var stopEx by remember { mutableStateOf(("")) }
    var hourStartEx by remember { mutableStateOf(("")) }
    var hourEndEx by remember { mutableStateOf(("")) }
    var show by remember { mutableStateOf((false)) }

    var isExpanded by remember { mutableStateOf((false)) }
    var isExpanded1 by remember { mutableStateOf((false)) }
    var isExpanded2 by remember { mutableStateOf((false)) }
    var isExpanded3 by remember { mutableStateOf((false)) }
    var isExpanded4 by remember { mutableStateOf((false)) }
    var svuota by remember {
        mutableStateOf((false))
    }

    var error by remember { mutableStateOf((false)) }
    var errorHour by remember { mutableStateOf((false)) }
    var already by remember { mutableStateOf((false)) }

    var open by remember { mutableStateOf((false)) }
    var extra by remember { mutableStateOf((false)) }
    var orari : MutableMap<String, String> = mutableMapOf()

    val openLoading by viewModel.open2.collectAsState()


    val confirm by viewModel.confirm.collectAsState()

    var alreadyUploaded by remember { mutableStateOf(false) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    val bitmap = remember { mutableStateOf<Bitmap?>(null) }



    val launcher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            saveImageToInternalStorage(context, it)
        }
        imageUri = uri
    }


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Registrazione commerciante") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.SelectRoleScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        /*bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(20.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },*/

        ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Spacer(modifier = Modifier.height(15.dp))
                    /*Row() {
                        Text(
                            text = "Registrazione commerciante",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }
                    Spacer(modifier = Modifier.height(30.dp))*/

                    //per il display della foto utente
                    imageUri?.let {

                        if (Build.VERSION.SDK_INT < 28) {
                            bitmap.value = MediaStore.Images
                                .Media.getBitmap(context.contentResolver, it)


                        } else {
                            val source = ImageDecoder
                                .createSource(context.contentResolver, it)
                            bitmap.value = ImageDecoder.decodeBitmap(source)
                        }
                    }

                    OutlinedButton(
                        onClick = { launcher.launch("image/*") },
                        modifier = Modifier
                            .height(150.dp)
                            .width(150.dp),
                    )
                    {
                        if (bitmap.value == null) {
                            Icon(
                                imageVector = Icons.Filled.AccountCircle,
                                contentDescription = "to show",
                                tint = Color.Black,
                                modifier = Modifier.size(80.dp)
                            )
                        } else {
                            bitmap.value?.let { btm ->
                                Image(
                                    bitmap = btm.asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.height(300.dp),
                                    contentScale = ContentScale.Crop

                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,

                    ) {
                        if(!missing.contains("name")) {
                            Text(
                                text = "Nome attività",
                                fontSize = 16.sp,
                            )
                        }
                        else
                        {
                            Text(
                                text = "Nome attività *",
                                color = Color.Red,
                                fontSize = 16.sp,
                            )
                        }

                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester),
                        value = name,
                        maxLines = 1,
                        onValueChange = { newText ->
                            name = newText
                        },
                        placeholder = {
                            Text(text = "Es. Aldo's", color = Color.LightGray)
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        if(!missing.contains("sede")) {
                            Text(
                                text = "Indirizzo attività",
                                fontSize = 16.sp,
                            )
                        }
                        else
                        {
                            Text(
                                text = "Indirizzo attività *",
                                color = Color.Red,
                                fontSize = 16.sp,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester),
                        value = address,
                        onValueChange = { newText ->
                            address = newText
                        },
                        placeholder = {
                            Text(text = "Es. Via Monginevro 35, Torino", color = Color.LightGray)
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        if(!missing.contains("cat")) {
                            Text(
                                text = "Categoria merceologica",
                                fontSize = 16.sp,
                            )
                        }
                        else
                        {
                            Text(
                                text = "Categoria merceologica *",
                                color = Color.Red,
                                fontSize = 16.sp,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    ExposedDropdownMenuBox(
                        expanded = isExpanded,
                        onExpandedChange = {
                            isExpanded = !isExpanded
                            if(isExpanded)
                            {
                                isExpanded1=false
                                isExpanded2=false }
                        }
                    ) {
                        TextField(
                            value = category,
                            onValueChange = { },
                            readOnly = true,
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                            },
                            placeholder = {
                                Text(text = "seleziona una categoria")
                            },
                            colors = ExposedDropdownMenuDefaults.textFieldColors(),
                            modifier = Modifier.menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = isExpanded,
                            onDismissRequest = {
                                isExpanded = !isExpanded
                            }
                        ) {
                            viewModel.categories.forEach { cat ->

                                    DropdownMenuItem(
                                        text = { Text(text = "" + cat) },
                                        onClick = {
                                            category = "" + cat
                                            isExpanded = false

                                        }
                                    )

                            }
                        }

                    }


                    Spacer(modifier = Modifier.height(15.dp))
                    Row() {
                        if(!missing.contains("tel")) {
                            Text(
                                text = "Numero di telefono",
                                fontSize = 16.sp,
                            )
                        }
                        else
                        {
                            Text(
                                text = "Numero di telefono *",
                                color = Color.Red,
                                fontSize = 16.sp,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester),
                        value = telephone,
                        maxLines = 1,
                        onValueChange = { newText ->
                            telephone = newText
                        },
                        placeholder = {
                            Text(text = "Es. 011788937", color = Color.LightGray)
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(15.dp))

                    Row() {
                        if(!missing.contains("email")) {
                            Text(
                                text = "Email",
                                fontSize = 16.sp,
                            )
                        }
                        else
                        {
                            Text(
                                text = "Email *",
                                color = Color.Red,
                                fontSize = 16.sp,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester),
                        value = email,
                        maxLines = 1,
                        onValueChange = { newText ->
                            email = newText
                        },
                        placeholder = {
                            Text(text = "Es. aldos@gmail.com", color = Color.LightGray)
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(15.dp))

                    Row() {
                        if(!missing.contains("orari")) {
                            Text(
                                text = "Orari di apertura",
                                fontSize = 16.sp,
                            )
                        }
                        else
                        {
                            Text(
                                text = "Orari di apertura *",
                                color = Color.Red,
                                fontSize = 16.sp,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Divider(color = Color.DarkGray, thickness = 1.dp)

                    Spacer(modifier = Modifier.height(7.dp))

                    Row() {
                        Text(
                            text = "In questa sezione inserire i giorni effettivi di apertura del negozio con i relativi orari" +
                                    "in caso di modifiche di orario in certi giorni, cliccare sul bottone + per inserirle",
                            fontSize = 12.sp,
                        )
                    }
                    Spacer(modifier = Modifier.height(7.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 10.dp,
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        Text(
                            text = "Da:",
                            fontSize = 15.sp,
                        )

                        ExposedDropdownMenuBox(
                            expanded = isExpanded1,
                            onExpandedChange = {
                                isExpanded1 = !isExpanded1
                                if(isExpanded1)
                                {
                                    isExpanded=false
                                    isExpanded2=false
                                    isExpanded3=false
                                    isExpanded4=false}
                            }
                        ) {
                            TextField(
                                value = start,
                                onValueChange = { },
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                },
                                placeholder = {
                                    Text(text = "giorno", fontSize = 12.sp)
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier
                                    .menuAnchor()
                                    .width(120.dp),
                            )
                            ExposedDropdownMenu(
                                expanded = isExpanded1,
                                onDismissRequest = {
                                    isExpanded1 = !isExpanded1
                                }
                            ) {
                                viewModel.days.forEach { cat ->

                                    DropdownMenuItem(
                                        text = { Text(text = "" + cat) },
                                        onClick = {
                                            start = "" + cat
                                            isExpanded1 = false

                                        }
                                    )

                                }
                            }

                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(

                            text = "a:",
                            fontSize = 15.sp,
                        )

                        ExposedDropdownMenuBox(
                            expanded = isExpanded2,
                            onExpandedChange = {
                                isExpanded2 = !isExpanded2
                                if(isExpanded2)
                                {
                                    isExpanded=false
                                    isExpanded1=false
                                    isExpanded3=false
                                    isExpanded4=false}
                            }
                        ) {
                            TextField(
                                value = stop,
                                onValueChange = { },
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                },
                                placeholder = {
                                    Text(text = "giorno", fontSize = 12.sp)
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier
                                    .menuAnchor()
                                    .width(120.dp),
                            )
                            ExposedDropdownMenu(
                                expanded = isExpanded2,
                                onDismissRequest = {
                                    isExpanded2 = !isExpanded2
                                }
                            ) {
                                viewModel.days.forEach { cat ->

                                    DropdownMenuItem(
                                        text = { Text(text = "" + cat) },
                                        onClick = {
                                            stop = "" + cat
                                            isExpanded2 = false

                                        }
                                    )

                                }
                            }

                        }
                    }
                    Spacer(modifier = Modifier.height(7.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(space = 8.dp,),
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        IconButton(onClick = { show=true },
                                   enabled = !show
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "Favorite")
                        }
                        Text(
                            text = "Da:",
                            fontSize = 15.sp,
                        )
                        OutlinedTextField(
                            modifier = Modifier
                                .width(110.dp)
                                .focusRequester(focusRequester),
                            value = hourStart,


                            maxLines = 1,
                          /*  onValueChange = { newText ->
                                hourStart = newText
                            }, */
                            onValueChange = { newText ->
                                    hourStart = newText

                            },
                            placeholder = {
                                Text(text = "8:00", color = Color.LightGray)
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Done
                            ),
                        )
                        Text(
                            text = "a:",
                            fontSize = 15.sp,
                        )
                        OutlinedTextField(
                            modifier = Modifier
                                .width(110.dp)
                                .focusRequester(focusRequester),
                            value = hourEnd,
                            maxLines = 1,
                            onValueChange = { newText ->
                                hourEnd = newText
                            },
                            placeholder = {
                                Text(text = "20:00", color = Color.LightGray)
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Done
                            ),
                        )

                    }

                    //////////////////////////////////////////////////////
                    if(show) {
                        Divider(color = Color.DarkGray, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(7.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement
                                .spacedBy(
                                    space = 10.dp,
                                ),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Da:",
                                fontSize = 15.sp,
                            )

                            ExposedDropdownMenuBox(
                                expanded = isExpanded3,
                                onExpandedChange = {
                                    isExpanded3 = !isExpanded3
                                    if (isExpanded3) {
                                        isExpanded = false
                                        isExpanded1 = false
                                        isExpanded2 = false
                                        isExpanded4 = false
                                    }
                                }
                            ) {
                                TextField(
                                    value = startEx,
                                    onValueChange = { },
                                    readOnly = true,
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                    },
                                    placeholder = {
                                        Text(text = "giorno", fontSize = 12.sp)
                                    },
                                    colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                    modifier = Modifier
                                        .menuAnchor()
                                        .width(120.dp),
                                )
                                ExposedDropdownMenu(
                                    expanded = isExpanded3,
                                    onDismissRequest = {
                                        isExpanded3 = !isExpanded3
                                    }
                                ) {
                                    viewModel.days.forEach { cat ->

                                        DropdownMenuItem(
                                            text = { Text(text = "" + cat) },
                                            onClick = {
                                                startEx = "" + cat
                                                isExpanded3 = false

                                            }
                                        )

                                    }
                                }

                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(

                                text = "a:",
                                fontSize = 15.sp,
                            )

                            ExposedDropdownMenuBox(
                                expanded = isExpanded4,
                                onExpandedChange = {
                                    isExpanded4 = !isExpanded4
                                    if (isExpanded4) {
                                        isExpanded = false
                                        isExpanded1 = false
                                        isExpanded2 = false
                                        isExpanded3 = false
                                    }
                                }
                            ) {
                                TextField(
                                    value = stopEx,
                                    onValueChange = { },
                                    readOnly = true,
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                    },
                                    placeholder = {
                                        Text(text = "giorno", fontSize = 12.sp)
                                    },
                                    colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                    modifier = Modifier
                                        .menuAnchor()
                                        .width(150.dp),
                                )
                                ExposedDropdownMenu(
                                    expanded = isExpanded4,
                                    onDismissRequest = {
                                        isExpanded4 = !isExpanded4
                                    }
                                ) {
                                    viewModel.days.forEach { cat ->

                                        DropdownMenuItem(
                                            text = { Text(text = "" + cat) },
                                            onClick = {
                                                stopEx = "" + cat
                                                isExpanded4 = false

                                            }
                                        )

                                    }
                                }

                            }
                        }
                        Spacer(modifier = Modifier.height(7.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement
                                .spacedBy(space = 8.dp,),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { show=false }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Favorite")
                            }
                            Text(
                                text = "Da:",
                                fontSize = 15.sp,
                            )
                            OutlinedTextField(
                                modifier = Modifier
                                    .width(110.dp)
                                    .focusRequester(focusRequester),
                                value = hourStartEx,
                                maxLines = 1,
                                onValueChange = { newText ->
                                    hourStartEx = newText
                                },
                                placeholder = {
                                    Text(text = "8:00", color = Color.LightGray)
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done
                                ),

                            )

                            OutlinedTextField(
                                value = hourStartEx,
                                onValueChange = { newText ->
                                        hourStartEx = newText

                                },
                                modifier = Modifier
                                    .width(110.dp)
                                    .focusRequester(focusRequester),
                                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                maxLines = 1,

                            )

                            Text(
                                text = "a:",
                                fontSize = 15.sp,
                            )
                            OutlinedTextField(
                                modifier = Modifier
                                    .width(110.dp)
                                    .focusRequester(focusRequester),
                                value = hourEndEx,
                                maxLines = 1,
                                onValueChange = { newText ->
                                    hourEndEx = newText
                                },
                                placeholder = {
                                    Text(text = "20:00", color = Color.LightGray)
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done
                                ),
                            )
                        }
                    }

///////////////////////////////////////////////////////////////////////////////////
                    Row() {
                        if(!missing.contains("pwd")) {
                            Text(
                                text = "Password",
                                fontSize = 16.sp,
                            )
                        }
                        else
                        {
                            Text(
                                text = "Password",
                                color = Color.Red,
                                fontSize = 16.sp,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester),
                        value = pwd,
                        maxLines = 1,
                        onValueChange = { newText ->
                            pwd = newText
                        },
                        placeholder = {
                            Text(text = "Password", color = Color.LightGray)
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    Spacer(modifier = Modifier.height(10.dp))

                    Row() {
                        if(!missing.contains("lock")) {
                            Text(
                                text = "Seleziona i tuoi locker: ",
                                fontSize = 16.sp,
                            )
                        }
                        else
                        {
                            Text(
                                text = "Seleziona i tuoi lockers *",
                                color = Color.Red,
                                fontSize = 16.sp,
                            )
                        }
                    }
                    Box()
                    {
                        Image(
                            painter = painterResource(id = R.drawable.mappa),
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(250.dp)

                        )

                        viewModel.lockersList.forEach() { lock ->

                            IconToggleButton(
                                checked = viewModel.lockersSelected.contains(lock),
                                onCheckedChange = { _checked ->


                                    if (_checked)
                                        viewModel.addLockersSelected(lock)
                                    else
                                        viewModel.removeLockersSelected(lock)

                                },
                                modifier = Modifier.padding(top = lock.spaces[0].positionX.dp,start=lock.spaces[0].positionY.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "Favorite Item",
                                    tint = if (viewModel.lockersSelected.contains(lock)) Color.Red else Color.LightGray // icon color
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(5.dp))

                    if(!viewModel.lockersSelected.isEmpty()) {
                        Row() {
                            Text(text = "Lockers selezionati:")
                        }
                    }

                    viewModel.lockersSelected.forEach() { lock->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(320.dp)
                            )
                            {
                                Text(
                                    modifier = Modifier.padding(horizontal = 16.dp),
                                    text = "${lock.spaces[0].address}",
                                    fontSize = 18.sp,
                                    textAlign = TextAlign.Start,
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(60.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = null,
                                    modifier = Modifier.clickable { viewModel.removeLockersSelected(lock)}
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 20.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                    )
                    {
                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .wrapContentSize(),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                            shape = RoundedCornerShape(10.dp),
                            onClick = {

                                val oraActual = LocalTime.now()
                                var img = ""+name+"_"+address+"_"+oraActual+".jpg"

                                if (imageUri != null) {
                                    if (!alreadyUploaded) {
                                        uploadImageToFirebase(imageUri!!, img)
                                        alreadyUploaded = true
                                    }
                                } else
                                    error = true

                                if (name == "" || address == "" || category == "" || pwd == "" || email == "" || telephone == ""||
                                          start==""||stop==""|| hourStart==""|| hourEnd=="" || viewModel.lockersSelected.isEmpty())
                                    error = true
                                if((hourStartEx != "" && hourEndEx=="") || (hourStartEx == "" && hourEndEx!="") )
                                    error=true

                                if(!error) {

                                    hourStart = checkOrario(hourStart)
                                    hourEnd = checkOrario(hourEnd)

                                    if(hourStart == "" || hourEnd=="")
                                        errorHour = true

                                    if(hourStartEx != "" && hourEndEx!="")
                                    {
                                        hourStartEx = checkOrario(hourStartEx)
                                        hourEndEx = checkOrario(hourEndEx)

                                        if(hourStartEx == "" || hourEndEx=="")
                                            errorHour = true

                                    }

                                    viewModel.days.forEach() { day ->
                                        //se non ci sono extra
                                        if (startEx == "") {

                                            if(start==day)
                                                open=true

                                            if(stop==day)
                                                open=false

                                            if(open)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            else if(!open && stop==day)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            else if(!open && stop!=day)
                                                orari.put(day," chiuso")

                                        } else {
                                            //se ci sono extra orari
                                            if(start==day)
                                                open=true

                                            if(stop==day)
                                                open=false

                                            if(startEx==day)
                                                extra=true

                                            if(stopEx==day)
                                                extra=false

                                            if(open && !extra)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            if(open && extra)
                                                orari.put(day, hourStartEx + " - " + hourEndEx)
                                            if(open && !extra && stopEx==day)
                                                orari.put(day, hourStartEx + " - " + hourEndEx)
                                            if(!open && !extra && stopEx==day)
                                                orari.put(day, hourStartEx + " - " + hourEndEx)
                                            if(open && !extra && stopEx!=day)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            if(!open && !extra && stop==day)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            if(!open && !extra && stop!=day && stopEx!=day)
                                                orari.put(day," chiuso")

                                        }
                                    }

                                    var orariString=""

                                    orari.forEach(){ orario ->
                                        orariString = orariString+""+orario.key+"= "+orario.value+";"
                                    }

                                    var lockersString=""
                                    viewModel.lockersSelected.forEach(){ lock ->
                                        lockersString = lockersString+""+lock.spaces[0].address+","
                                    }

                                    viewModel.sellers.forEach(){ s->
                                        if(s.email == email && s.name==name)
                                            already = true

                                    }
                                   // if(viewModel.sellers.contains(seller))
                                    //    already=true



                                    if(!already) {

                                        viewModel.open2.value = true
                                        Log.d("dddd", "open value : "+open)
                                        viewModel.startThreadSeller(authentic, db, pwd, name,  address, category, telephone, email, orariString, lockersString, img)

                                        viewModel.clearLockers()
                                    }
                                }
                            },
                            content = {
                                Text(
                                    text = "Conferma",
                                    fontSize = 16.sp
                                )
                            }
                        )

                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .wrapContentSize(),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                            shape = RoundedCornerShape(10.dp),
                            onClick = {
                                      svuota = true
                            },
                            content = {
                                Text(
                                    text = "Svuota",
                                    fontSize = 16.sp
                                )
                            }
                        )

                    }


                    if (error && !errorHour) {
                        AlertDialog(
                            onDismissRequest = { error = false },
                            text = { Text("E' necessario riempire tutti i campi e inserire un'immagine prima di procede alla registrazione") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                                    onClick = { error = false
                                        if(name == "")
                                            missing = missing+ "name"
                                        if(address == "")
                                            missing = missing+ "sede"
                                        if(category == "")
                                            missing = missing + "cat"
                                        if(pwd == "")
                                            missing += "pwd"
                                        if(email == "")
                                            missing += "email"
                                        if(telephone == "")
                                            missing += "tel"
                                        if(start==""||stop==""|| hourStart==""|| hourEnd=="")
                                            missing += "orari"
                                        if((hourStartEx != "" && hourEndEx=="") || (hourStartEx == "" && hourEndEx!="") )
                                            missing+="orari"
                                        if(viewModel.lockersSelected.isEmpty())
                                            missing += "lock"

                                        focusManager.clearFocus()
                                    }
                                ) {
                                    Text("OK")
                                }
                            }
                        )

                    }

                    if (confirm) {
                        AlertDialog(
                            onDismissRequest = { viewModel.confirm.value = false },
                            text = { Text("Registrazione avvenuta con successo") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                                    onClick = {
                                        viewModel.confirm.value = false

                                        pwd = ""
                                        name=""
                                        address=""
                                        category=""
                                        email = ""
                                        telephone = ""
                                        start=""
                                        stop=""
                                        hourStart=""
                                        hourEnd=""
                                        startEx=""
                                        stopEx=""
                                        hourStartEx=""
                                        hourEndEx=""
                                        missing = ""

                                        viewModel.clearLockers()
                                        navController.navigate(Screen.HomeSellerScreen.route)
                                    }

                                ) {
                                    Text("OK")
                                }
                            }
                        )

                    }

                    if (already) {
                        AlertDialog(
                            onDismissRequest = { already = false },
                            text = { Text("Negozio già esistente") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                                    onClick = { already = false
                                         missing = ""
                                        focusManager.clearFocus()}
                                ) {
                                    Text("OK")
                                }
                            }
                        )

                    }

                    if (errorHour) {
                        AlertDialog(
                            onDismissRequest = { errorHour = false },
                            text = { Text("Orario in formato non corretto") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                                    onClick = { errorHour = false
                                        missing = "orari" }
                                ) {
                                    Text("OK")
                                }
                            }
                        )

                    }



                }

            }
        }
    }
    if (openLoading) {
        AlertDialog(
            onDismissRequest = {
            },
            properties = DialogProperties(
                usePlatformDefaultWidth = false // disable the default size so that we can customize it
            )
        ) {
            Column(
                modifier = Modifier
                    .padding(start = 42.dp, end = 42.dp) // margin
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(top = 36.dp, bottom = 36.dp), // inner padding
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                ProgressIndicatorLoading(
                    progressIndicatorSize = 80.dp,
                    progressIndicatorColor = Color(0xFF35898f)
                )

                // Gap between progress indicator and text
                Spacer(modifier = Modifier.height(32.dp))

                // Please wait text
                Text(
                    text = "Attendere...",
                    style = TextStyle(
                        color = Color.Black,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Normal
                    )
                )
            }
        }
    }
    if (svuota) {
        AlertDialog(
            onDismissRequest = { svuota = false },
            text = { Text("Confermi di voler eliminare i dati inseriti?") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = {

                        pwd = ""
                        name=""
                        address=""
                        category=""
                        email = ""
                        telephone = ""
                        start=""
                        stop=""
                        hourStart=""
                        hourEnd=""
                        startEx=""
                        stopEx=""
                        hourStartEx=""
                        hourEndEx=""
                        viewModel.removeLockerSelectedAll()

                        missing = ""

                        focusManager.clearFocus()
                    }
                ) {
                    Text("Si")
                }
            },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                    onClick = { svuota = false }
                ) {
                    Text("No")
                }
            }
        )
    }
}


@Composable
private fun ProgressIndicatorLoading(
    progressIndicatorSize: Dp,
    progressIndicatorColor: Color
) {
    val infiniteTransition = rememberInfiniteTransition()

    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 600 // animation duration
            }
        )
    )

    CircularProgressIndicator(
        progress = 1f,
        modifier = Modifier
            .size(progressIndicatorSize)
            .rotate(angle)
            .border(
                12.dp,
                brush = Brush.sweepGradient(
                    listOf(
                        Color.White, // add background color first
                        progressIndicatorColor.copy(alpha = 0.1f),
                        progressIndicatorColor
                    )
                ),
                shape = CircleShape
            ),
        strokeWidth = 1.dp,
        color = Color.White // Set background color
    )
}

fun checkOrario(orario: String):String {

    var ok = ""

    if(orario.contains(":"))
        ok=""
    else {
        var parts1 = orario.split(":")

        if (parts1[0].toInt() > 23 || parts1[0].length < 1 || parts1[0].length > 2 || parts1[1].toInt() > 59 || parts1[1].length < 2 || parts1[1].length > 2)
            ok = ""
        else if (parts1[0].length == 1)
            ok = "0" + parts1[0] + ":" + parts1[1]
        else
            ok = parts1[0] + ":" + parts1[1]
    }

    return ok

}
