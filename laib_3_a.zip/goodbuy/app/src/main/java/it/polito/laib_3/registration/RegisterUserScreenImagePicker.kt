package it.polito.laib_3.registration

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.saveImageToInternalStorage
import it.polito.laib_3.uploadImageToFirebase

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterUserScreenImagePicker(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic :FirebaseAuth, storage: StorageReference){

    var already by remember { mutableStateOf(false) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    val context = LocalContext.current
    val bitmap = remember { mutableStateOf<Bitmap?>(null) }
    val bitmap2 = remember { mutableStateOf<Bitmap?>(null) }


    val launcher = rememberLauncherForActivityResult(
        contract =
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            saveImageToInternalStorage(context, it)
        }
        imageUri = uri
    }
    Column() {

        Button(onClick = { launcher.launch("image/*") })
        {
            Text(text = "Pick image")
        }

        Spacer(modifier = Modifier.height(12.dp))


        //caricare immagine su firestore
        imageUri?.let {

            if(!already)
            {   uploadImageToFirebase(imageUri!!)
                already = true
            }

            if (Build.VERSION.SDK_INT < 28) {
                bitmap.value = MediaStore.Images
                    .Media.getBitmap(context.contentResolver, it)


            } else {
                val source = ImageDecoder
                    .createSource(context.contentResolver, it)
                bitmap.value = ImageDecoder.decodeBitmap(source)
            }

            bitmap.value?.let { btm ->
                Image(
                    bitmap = btm.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.size(400.dp)
                )


            }
        }
      //  uploadImageToFirebase(imageUri!!)

     //   var bitmap2: Bitmap?=null

        //prendere immagine da firestore
        Button(onClick = {
            storage.child("images/74eaa297-cb6d-48cf-9e95-cd7c89d48fe7.jpg").getBytes(Long.MAX_VALUE).addOnSuccessListener { bytes->

                Log.d("aaaa", "IMAGEEEEE FROM FIREASE :"+bytes)
                bitmap2.value = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                Log.d("aaaa", "IMAGEEEEE FROM FIREASE :"+bitmap2.value)


                // Mostra l'immagine nell'ImageView

                // Use the bytes to display the image
            }.addOnFailureListener {
                // Handle any errors
            }
        }) {
            Text(text = "load image")
        }

        bitmap2?.value.let { btm ->
            if (btm != null) {
                Image(
                    bitmap = btm.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.size(400.dp)
                )
            }


        }
    }

}



