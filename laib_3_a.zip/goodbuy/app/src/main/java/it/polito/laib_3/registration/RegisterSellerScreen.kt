package it.polito.laib_3.registration

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.Seller
import it.polito.laib_3.bounceClick
import it.polito.laib_3.saveImageToInternalStorage
import it.polito.laib_3.uploadImageToFirebase

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterSellerScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage: StorageReference) {

    val context = LocalContext.current

    var image by remember { mutableStateOf(("")) }
    var pwd by remember { mutableStateOf(("")) }
    var email by remember { mutableStateOf(("")) }
    var telephone by remember { mutableStateOf(("")) }
    var name by remember { mutableStateOf(("")) }
    var address by remember { mutableStateOf(("")) }
    var category by remember { mutableStateOf(("")) }

    var start by remember { mutableStateOf(("")) }
    var stop by remember { mutableStateOf(("")) }
    var hourStart by remember { mutableStateOf(("")) }
    var hourEnd by remember { mutableStateOf(("")) }
    var startEx by remember { mutableStateOf(("")) }
    var stopEx by remember { mutableStateOf(("")) }
    var hourStartEx by remember { mutableStateOf(("")) }
    var hourEndEx by remember { mutableStateOf(("")) }
    var show by remember { mutableStateOf((false)) }

    var isExpanded by remember { mutableStateOf((false)) }
    var isExpanded1 by remember { mutableStateOf((false)) }
    var isExpanded2 by remember { mutableStateOf((false)) }
    var isExpanded3 by remember { mutableStateOf((false)) }
    var isExpanded4 by remember { mutableStateOf((false)) }

    var error by remember { mutableStateOf((false)) }
    var confirm by remember { mutableStateOf((false)) }
    var already by remember { mutableStateOf((false)) }

    var open by remember { mutableStateOf((false)) }
    var stopOpen by remember { mutableStateOf((false)) }
    var closed by remember { mutableStateOf((false)) }
    var extra by remember { mutableStateOf((false)) }
    var orari : MutableMap<String, String> = mutableMapOf()

    var alreadyUploaded by remember { mutableStateOf(false) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    val bitmap = remember { mutableStateOf<Bitmap?>(null) }

    val launcher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            saveImageToInternalStorage(context, it)
        }
        imageUri = uri
    }


    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.SelectRoleScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(20.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                  //  horizontalAlignment = Alignment.CenterHorizontally
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Spacer(modifier = Modifier.height(40.dp))
                    Row() {
                        Text(
                            text = "Registrazione",
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically)
                        )
                    }
                    Spacer(modifier = Modifier.height(30.dp))

                    //per il display della foto utente
                    imageUri?.let {

                        if (Build.VERSION.SDK_INT < 28) {
                            bitmap.value = MediaStore.Images
                                .Media.getBitmap(context.contentResolver, it)


                        } else {
                            val source = ImageDecoder
                                .createSource(context.contentResolver, it)
                            bitmap.value = ImageDecoder.decodeBitmap(source)
                        }
                    }

                    OutlinedButton(
                        onClick = { launcher.launch("image/*") },
                        modifier = Modifier.height(150.dp).width(150.dp),
                    )
                    {
                        if (bitmap.value == null) {
                            Icon(
                                imageVector = Icons.Filled.AccountCircle,
                                contentDescription = "to show",
                                tint = Color.White,
                            )
                        } else {
                            bitmap.value?.let { btm ->
                                Image(
                                    bitmap = btm.asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.height(300.dp),
                                    contentScale = ContentScale.Crop

                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Text(
                            text = "Nome Attività",
                            fontSize = 15.sp,
                        )
                    }
                    OutlinedTextField(
                        modifier = Modifier.fillMaxWidth(),
                        value = name,
                        onValueChange = { newText ->
                            name = newText
                        },
                        placeholder = {
                            Text(text = "Es. Aldo's")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Text(
                            text = "Sede",
                            fontSize = 15.sp,
                        )
                    }
                    OutlinedTextField(
                        modifier = Modifier.fillMaxWidth(),
                        value = address,
                        onValueChange = { newText ->
                            address = newText
                        },
                        placeholder = {
                            Text(text = "Es. Via Monginevro 35")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(15.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Text(
                            text = "Categoria",
                            fontSize = 15.sp,
                        )
                    }
                    ExposedDropdownMenuBox(
                        expanded = isExpanded,
                        onExpandedChange = {
                            isExpanded = !isExpanded
                            if(isExpanded)
                            {
                                isExpanded1=false
                                isExpanded2=false }
                        }
                    ) {
                        TextField(
                            value = category,
                            onValueChange = { },
                            readOnly = true,
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                            },
                            placeholder = {
                                Text(text = "seleziona una categoria")
                            },
                            colors = ExposedDropdownMenuDefaults.textFieldColors(),
                            modifier = Modifier.menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = isExpanded,
                            onDismissRequest = {
                                isExpanded = !isExpanded
                            }
                        ) {
                            viewModel.categories.forEach { cat ->

                                    DropdownMenuItem(
                                        text = { Text(text = "" + cat) },
                                        onClick = {
                                            category = "" + cat
                                            isExpanded = false

                                        }
                                    )

                            }
                        }

                    }


                    Spacer(modifier = Modifier.height(15.dp))
                    Row() {
                        Text(
                            text = "Numero di telefono",
                            fontSize = 15.sp,
                        )
                    }
                    OutlinedTextField(
                        modifier = Modifier.fillMaxWidth(),
                        value = telephone,
                        onValueChange = { newText ->
                            telephone = newText
                        },
                        placeholder = {
                            Text(text = "Es. 011788937")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(15.dp))

                    Row() {
                        Text(
                            text = "Email",
                            fontSize = 15.sp,
                        )
                    }
                    OutlinedTextField(
                        modifier = Modifier.fillMaxWidth(),
                        value = email,
                        onValueChange = { newText ->
                            email = newText
                        },
                        placeholder = {
                            Text(text = "Es. aldos@gmail.com")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(15.dp))

                    Row() {
                        Text(
                            text = "Orari di apertura",
                            fontSize = 15.sp,
                        )
                    }
                    Divider(color = Color.DarkGray, thickness = 1.dp)

                    Spacer(modifier = Modifier.height(7.dp))

                    Row() {
                        Text(
                            text = "In questa sezione inserire i giorni effettivi di apertura del negozio con i relativi orari" +
                                    "in caso di modifiche di orario in certi giorni, cliccare sul bottone + per inserirle",
                            fontSize = 12.sp,
                        )
                    }
                    Spacer(modifier = Modifier.height(7.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 10.dp,
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        Text(
                            text = "Da:",
                            fontSize = 15.sp,
                        )

                        ExposedDropdownMenuBox(
                            expanded = isExpanded1,
                            onExpandedChange = {
                                isExpanded1 = !isExpanded1
                                if(isExpanded1)
                                {
                                    isExpanded=false
                                    isExpanded2=false
                                    isExpanded3=false
                                    isExpanded4=false}
                            }
                        ) {
                            TextField(
                                value = start,
                                onValueChange = { },
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                },
                                placeholder = {
                                    Text(text = "giorno")
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier
                                    .menuAnchor()
                                    .width(150.dp),
                            )
                            ExposedDropdownMenu(
                                expanded = isExpanded1,
                                onDismissRequest = {
                                    isExpanded1 = !isExpanded1
                                }
                            ) {
                                viewModel.days.forEach { cat ->

                                    DropdownMenuItem(
                                        text = { Text(text = "" + cat) },
                                        onClick = {
                                            start = "" + cat
                                            isExpanded1 = false

                                        }
                                    )

                                }
                            }

                        }
                        Text(

                            text = "a:",
                            fontSize = 15.sp,
                        )

                        ExposedDropdownMenuBox(
                            expanded = isExpanded2,
                            onExpandedChange = {
                                isExpanded2 = !isExpanded2
                                if(isExpanded2)
                                {
                                    isExpanded=false
                                    isExpanded1=false
                                    isExpanded3=false
                                    isExpanded4=false}
                            }
                        ) {
                            TextField(
                                value = stop,
                                onValueChange = { },
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                },
                                placeholder = {
                                    Text(text = "giorno")
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier
                                    .menuAnchor()
                                    .width(150.dp),
                            )
                            ExposedDropdownMenu(
                                expanded = isExpanded2,
                                onDismissRequest = {
                                    isExpanded2 = !isExpanded2
                                }
                            ) {
                                viewModel.days.forEach { cat ->

                                    DropdownMenuItem(
                                        text = { Text(text = "" + cat) },
                                        onClick = {
                                            stop = "" + cat
                                            isExpanded2 = false

                                        }
                                    )

                                }
                            }

                        }
                    }
                    Spacer(modifier = Modifier.height(7.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(space = 12.dp,),
                        verticalAlignment = Alignment.CenterVertically
                    ){
                        IconButton(onClick = { show=true }) {
                            Icon(Icons.Filled.Add, contentDescription = "Favorite")
                        }
                        Text(
                            text = "Da:",
                            fontSize = 15.sp,
                        )
                        OutlinedTextField(
                            modifier = Modifier
                                .width(100.dp),
                            value = hourStart,
                            onValueChange = { newText ->
                                hourStart = newText
                            },
                            placeholder = {
                                Text(text = "8:00")
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Done
                            ),
                        )
                        Text(
                            text = "a:",
                            fontSize = 15.sp,
                        )
                        OutlinedTextField(
                            modifier = Modifier
                                .width(100.dp),
                            value = hourEnd,
                            onValueChange = { newText ->
                                hourEnd = newText
                            },
                            placeholder = {
                                Text(text = "20:00")
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Done
                            ),
                        )

                    }

                    //////////////////////////////////////////////////////
                    if(show) {
                        Divider(color = Color.DarkGray, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(7.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement
                                .spacedBy(
                                    space = 10.dp,
                                ),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Da:",
                                fontSize = 15.sp,
                            )

                            ExposedDropdownMenuBox(
                                expanded = isExpanded3,
                                onExpandedChange = {
                                    isExpanded3 = !isExpanded3
                                    if (isExpanded3) {
                                        isExpanded = false
                                        isExpanded1 = false
                                        isExpanded2 = false
                                        isExpanded4 = false
                                    }
                                }
                            ) {
                                TextField(
                                    value = startEx,
                                    onValueChange = { },
                                    readOnly = true,
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                    },
                                    placeholder = {
                                        Text(text = "giorno")
                                    },
                                    colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                    modifier = Modifier
                                        .menuAnchor()
                                        .width(150.dp),
                                )
                                ExposedDropdownMenu(
                                    expanded = isExpanded3,
                                    onDismissRequest = {
                                        isExpanded3 = !isExpanded3
                                    }
                                ) {
                                    viewModel.days.forEach { cat ->

                                        DropdownMenuItem(
                                            text = { Text(text = "" + cat) },
                                            onClick = {
                                                startEx = "" + cat
                                                isExpanded3 = false

                                            }
                                        )

                                    }
                                }

                            }
                            Text(

                                text = "a:",
                                fontSize = 15.sp,
                            )

                            ExposedDropdownMenuBox(
                                expanded = isExpanded4,
                                onExpandedChange = {
                                    isExpanded4 = !isExpanded4
                                    if (isExpanded4) {
                                        isExpanded = false
                                        isExpanded1 = false
                                        isExpanded2 = false
                                        isExpanded3 = false
                                    }
                                }
                            ) {
                                TextField(
                                    value = stopEx,
                                    onValueChange = { },
                                    readOnly = true,
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded)
                                    },
                                    placeholder = {
                                        Text(text = "giorno")
                                    },
                                    colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                    modifier = Modifier
                                        .menuAnchor()
                                        .width(150.dp),
                                )
                                ExposedDropdownMenu(
                                    expanded = isExpanded4,
                                    onDismissRequest = {
                                        isExpanded4 = !isExpanded4
                                    }
                                ) {
                                    viewModel.days.forEach { cat ->

                                        DropdownMenuItem(
                                            text = { Text(text = "" + cat) },
                                            onClick = {
                                                stopEx = "" + cat
                                                isExpanded4 = false

                                            }
                                        )

                                    }
                                }

                            }
                        }
                        Spacer(modifier = Modifier.height(7.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement
                                .spacedBy(space = 8.dp,),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Da:",
                                fontSize = 15.sp,
                            )
                            OutlinedTextField(
                                modifier = Modifier
                                    .width(110.dp),
                                value = hourStartEx,
                                onValueChange = { newText ->
                                    hourStartEx = newText
                                },
                                placeholder = {
                                    Text(text = "8:00")
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done
                                ),
                            )
                            Text(
                                text = "a:",
                                fontSize = 15.sp,
                            )
                            OutlinedTextField(
                                modifier = Modifier
                                    .width(110.dp),
                                value = hourEndEx,
                                onValueChange = { newText ->
                                    hourEndEx = newText
                                },
                                placeholder = {
                                    Text(text = "20:00")
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done
                                ),
                            )
                        }
                    }

///////////////////////////////////////////////////////////////////////////////////
                    Row() {
                        Text(
                            text = "Password",
                            fontSize = 15.sp,
                        )
                    }
                    OutlinedTextField(
                        modifier = Modifier.fillMaxWidth(),
                        value = pwd,
                        onValueChange = { newText ->
                            pwd = newText
                        },
                        placeholder = {
                            Text(text = "Password")
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Done
                        ),
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 20.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                    )
                    {
                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .wrapContentSize(),
                            shape = RoundedCornerShape(10.dp),
                            onClick = {

                                if (name == "" || address == "" || category == "" || pwd == "" || email == "" || telephone == ""||
                                          start==""||stop==""|| hourStart==""|| hourEnd=="" || viewModel.currentImageUrl.value=="")
                                    error = true

                                if(!error) {

                                    if(!alreadyUploaded)
                                    {   uploadImageToFirebase(imageUri!!)
                                        alreadyUploaded = true
                                    }

                                    viewModel.days.forEach() { day ->
                                        //se non ci sono extra
                                        if (startEx == "") {

                                            if(start==day)
                                                open=true

                                            if(stop==day)
                                                open=false

                                            if(open)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            else if(!open && stop!=day)
                                                orari.put(day," chiuso")

                                        } else {
                                            //se ci sono extra orari
                                            if(start==day)
                                                open=true

                                            if(stop==day)
                                                open=false

                                            if(startEx==day)
                                                extra=true

                                            if(stopEx==day)
                                                extra=false

                                            if(open && !extra)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            if(open && extra)
                                                orari.put(day, hourStartEx + " - " + hourEndEx)
                                            if(open && !extra && stopEx==day)
                                                orari.put(day, hourStartEx + " - " + hourEndEx)
                                            if(!open && !extra && stopEx==day)
                                                orari.put(day, hourStartEx + " - " + hourEndEx)
                                            if(open && !extra && stopEx!=day)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            if(!open && !extra && stop==day)
                                                orari.put(day, hourStart + " - " + hourEnd)
                                            if(!open && !extra && stop!=day && stopEx!=day)
                                                orari.put(day," chiuso")

                                        }
                                    }

                                    var orariString=""

                                    orari.forEach(){ orario ->
                                        orariString = orariString+""+orario.key+"= "+orario.value+";"
                                    }

                                    val seller = viewModel.currentImageUrl.value?.let {
                                        Seller(
                                            pwd.replace(" ", ""),
                                            name.replace(" ", ""),
                                            address,
                                            category,
                                            telephone.replace(" ", ""),
                                            email.replace(" ", ""),
                                            orariString,
                                            it
                                        )
                                    }

                                    if(viewModel.sellers.contains(seller))
                                        already=true

                                    if(!already) {

                                        db.child("sellers").push().setValue(seller)
                                        viewModel.currentSeller.value=seller

                                        authentic.createUserWithEmailAndPassword(email, pwd)
                                            .addOnCompleteListener { task ->
                                                if (task.isSuccessful) {
                                                    Log.d("aaaaa", "createUserWithEmail:success")

                                                    val user = authentic.currentUser
                                                    confirm = true

                                                    Log.d("aaaaa", "createUserWithEmail user: "+user)

                                                } else {
                                                    Log.w(
                                                        "aaaaa",
                                                        "createUserWithEmail:failure",
                                                        task.exception
                                                    )
                                                }
                                            }
                                    }
                                }
                            },
                            content = {
                                Text(
                                    text = "Conferma",
                                    fontSize = 16.sp
                                )
                            }
                        )

                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .wrapContentSize(),
                            shape = RoundedCornerShape(10.dp),
                            onClick = {

                                pwd = ""
                                name=""
                                address=""
                                category=""
                                email = ""
                                telephone = ""
                                start=""
                                stop=""
                                hourStart=""
                                hourEnd=""
                                startEx=""
                                stopEx=""
                                hourStartEx=""
                                hourEndEx=""
                            },
                            content = {
                                Text(
                                    text = "Svuota",
                                    fontSize = 16.sp
                                )
                            }
                        )

                    }


                    if (error) {
                        AlertDialog(
                            onDismissRequest = { error = false },
                            text = { Text("E' necessario riempire tutti i campi prima di procede alla registrazione") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    onClick = { error = false }
                                ) {
                                    Text("OK")
                                }
                            }
                        )

                    }

                    if (confirm) {
                        AlertDialog(
                            onDismissRequest = { confirm = false },
                            text = { Text("Registrazione avvenuta con successo") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    onClick = {
                                        confirm = false

                                        pwd = ""
                                        name=""
                                        address=""
                                        category=""
                                        email = ""
                                        telephone = ""
                                        start=""
                                        stop=""
                                        hourStart=""
                                        hourEnd=""
                                        startEx=""
                                        stopEx=""
                                        hourStartEx=""
                                        hourEndEx=""

                                        navController.navigate(Screen.HomeUserScreen.route)
                                    }

                                ) {
                                    Text("OK")
                                }
                            }
                        )

                    }

                    if (already) {
                        AlertDialog(
                            onDismissRequest = { already = false },
                            text = { Text("Profilo già esistente") },
                            confirmButton = {
                                Button(
                                    modifier = Modifier.bounceClick(),
                                    onClick = { already = false }
                                ) {
                                    Text("OK")
                                }
                            }
                        )

                    }



                }

            }
        }
    }
}