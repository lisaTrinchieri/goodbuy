package it.polito.laib_3.user

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.Seller
import it.polito.laib_3.bounceClick
import java.time.LocalDate


@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "SuspiciousIndentation")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, shop: Seller, storage: StorageReference) {

    var checked by remember { mutableStateOf((false)) }
    var show by remember { mutableStateOf((false)) }
    var displayNumber by remember { mutableStateOf((1)) }
    var isExpanded by remember { mutableStateOf((false)) }

    var orari : List<String> = mutableListOf()
    orari = shop.orari.split(";").map { it.trim() }

    val day = LocalDate.now().getDayOfWeek().name
    var giorno = ""
    if(day=="MONDAY")
        giorno = "Lunedì"
    if(day=="TUESDAY")
        giorno = "Martedì"
    if(day=="WEDNESDAY")
        giorno = "Mercoledì"
    if(day=="THURSDAY")
        giorno = "Giovedì"
    if(day=="FRIDAY")
        giorno = "Venerdì"
    if(day=="SATURDAY")
        giorno = "Sabato"
    if(day=="SUNDAY")
        giorno = "Domenica"


    Scaffold(
        topBar = {
            TopAppBar(
                title = {  },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.CartScreen.route) }) {
                        Icon(
                            imageVector =  Icons.Filled.ShoppingCart,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
                )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Icon(Icons.Filled.Home, contentDescription = "Localized description")
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Icon(

                                Icons.Filled.Search,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Icon(
                                Icons.Filled.List,
                                contentDescription = "Localized description",
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route)
                        }) {
                            Icon(
                                Icons.Filled.Person,
                                contentDescription = "Localized description",
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
          //  item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(7.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "     "+shop.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 25.sp,
                            modifier=Modifier.padding(end=30.dp)
                        )

                        IconToggleButton(
                            checked = viewModel.favs.contains(shop.name),
                            onCheckedChange = { _checked ->
                                checked = _checked

                                if(_checked)
                                {    viewModel.addFav(shop.name)
                                    db.child("favourites").child("user1").child(shop.name).setValue(shop.name)
                                }
                                else
                                { viewModel.removeFav(shop.name)
                                    db.getRef().child("favourites").child("user1").removeValue()
                                    viewModel.favs.forEach(){ f->
                                        db.child("favourites").child("user1").child(f).setValue(f)
                                    }

                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Favorite Item",
                                tint = if (viewModel.favs.contains(shop.name)) Color.Red else Color.LightGray // icon color
                            )
                        }
                    }

                    Divider(color = Color.DarkGray, thickness = 2.dp)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Box(
                            modifier = Modifier//.wrapContentSize(Alignment.TopEnd)
                                .height(48.dp)
                                .width(150.dp)
                                              .border(BorderStroke(1.dp, Color.DarkGray))
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "" + shop.category,
                                    fontSize = 15.sp,
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .wrapContentSize(Alignment.TopEnd)
                                .padding(start=20.dp)
                                .border(BorderStroke(1.dp, Color.DarkGray))
                        ) {
                            OutlinedButton(
                                border = BorderStroke(0.dp, Color.Transparent),
                                onClick = { isExpanded = !isExpanded })
                            {
                                var value = ""

                                orari.forEach(){ orario ->
                                   if(orario.contains(giorno)) {

                                       val parts = orario.split("=")
                                       value = parts.getOrNull(1).toString()
                                   }
                                }

                                Text(
                                    text = "Oggi "+value,
                                    fontSize = 15.sp,
                                )
                            }
                            DropdownMenu(
                                expanded = isExpanded,
                                onDismissRequest = { isExpanded = false }
                            ) {

                                orari.forEach(){ orario ->

                                    var p1=""
                                    var p2=""

                                    if(orario.contains("=")) {
                                        val parts = orario.split("=")

                                        p1 = parts.firstOrNull().toString()
                                        p2 = parts.getOrNull(1).toString()


                                            DropdownMenuItem(
                                                text = { Text("" + p1 + "" + p2) },
                                                enabled = false,
                                                onClick = {}
                                            )

                                    }
                                }


                                //     }

                            }
                        }
                    }

               /*     Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Text(
                            text = "- "+shop.category,
                            fontSize = 18.sp,
                            textAlign = TextAlign.Start,
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Text(
                            text = "- Aperto da ${shop.start} a ${shop.stop}",
                            fontSize = 18.sp,
                            textAlign = TextAlign.Start,
                        )
                    }  */

                    Spacer(modifier = Modifier.height(10.dp))

                    Divider(color = Color.DarkGray, thickness = 2.dp)

                    Spacer(modifier = Modifier.height(15.dp))

               /*     if(!viewModel.cart.isEmpty()) {
                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .height(45.dp)
                                .width(230.dp),
                            shape = RoundedCornerShape(10.dp),
                            onClick = { navController.navigate(Screen.CartScreen.route)
                                viewModel.updatePrice() },
                            content = {
                                Text(
                                    text = "Visualizza carrello",
                                    fontSize = 16.sp
                                )
                            }
                        )
                    } */

                    LazyVerticalGrid(
                        modifier = Modifier.fillMaxSize(),
                        columns = GridCells.Fixed(count = 3)
                    ) {
                        items(count = viewModel.products.size) { index ->

                            if(viewModel.products[index].shop==shop.name) {

                                Box(
                                    modifier = Modifier
                                        .padding(
                                            horizontal = 10.dp
                                        )
                                        .height(2000.dp)
                                        .width(110.dp)
                                        .wrapContentSize(Alignment.TopStart)

                                ) {
                                    Column() {
                                            Box(contentAlignment = Alignment.TopEnd)
                                            {
                                                val bitmap = remember { mutableStateOf<Bitmap?>(null) }
                                                val image = viewModel.products[index].image
                                                storage.child("images/$image").getBytes(Long.MAX_VALUE).addOnSuccessListener { bytes->
                                                    bitmap.value = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                                }.addOnFailureListener {}

                                                bitmap?.value.let { btm ->
                                                    if (btm != null) {
                                                        Image(
                                                            bitmap = btm.asImageBitmap(),
                                                            contentDescription = null,
                                                            modifier = Modifier
                                                                .size(110.dp)
                                                                .clip(shape = RoundedCornerShape(size = 12.dp)),
                                                            contentScale = ContentScale.Crop
                                                        )
                                                    }
                                                }

                                                if(!viewModel.cart.containsKey(viewModel.products[index])) {
                                                    IconToggleButton(
                                                        //    modifier=Modifier.padding(start=70.dp),
                                                        checked = checked,
                                                        onCheckedChange = {
                                                            // checked = !checked
                                                            show = true
                                                            viewModel.currentProduct.value = viewModel.products[index]
                                                        }
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Filled.AddCircle,
                                                            contentDescription = null
                                                        )
                                                    }
                                                }
                                            }

                                            /*    OutlinedCard(
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.surface,
                                            ),

                                            border = BorderStroke(1.dp, Color.Black),
                                            modifier = Modifier
                                                .size(width = 165.dp, height = 140.dp)
                                                // .padding(16.dp)
                                                .clickable(onClick = {
                                                    viewModel.currentShop.value =
                                                        viewModel.sellers[index]
                                                    navController.navigate(Screen.ShopScreen.route)
                                                })
                                        ) { */
                                            /*  Image(
                                            painter = painterResource(id = R.drawable.locker),
                                            contentDescription = "confermato",
                                            colorFilter = ColorFilter.tint(Color.Black),
                                            modifier = Modifier.size(23.dp)
                                        )
                                        Icon(Icons.Filled.Check, contentDescription = "Check mark") */

                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "" + viewModel.products[index].price + " €",
                                                fontSize = 13.sp,
                                                color = Color.Black
                                            )
                                            Text(
                                                text = "" + viewModel.products[index].name,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.Black
                                            )
                                            Text(
                                                text = "" + viewModel.products[index].quantity + " " + viewModel.products[index].unit,
                                                fontSize = 13.sp,
                                                color = Color.Black
                                            )


                                    }
                                }


                            /*    OutlinedCard(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                    ),
                                    border = BorderStroke(1.dp, Color.Black),
                                    modifier = Modifier
                                        .size(width = 180.dp, height = 140.dp)
                                        .padding(16.dp)
                                        .clickable(onClick = {
                                            viewModel.addToCart(viewModel.products[index], 1)
                                            viewModel.updatePrice()
                                            navController.navigate(Screen.CartScreen.route)
                                        })
                                ) {
                                    Column {
                                        /*     Image(
                                             modifier = Modifier
                                                 .width(width = 250.dp)
                                                 .clip(shape = RoundedCornerShape(size = 12.dp)),
                                             painter = painterResource(id = R.drawable.music),
                                             contentDescription = null,
                                             contentScale = ContentScale.Crop
                                         )  */
                                        Text(
                                            text = "" + viewModel.products[index].price+ " €",
                                            fontSize = 12.sp,
                                            color = Color.Black
                                        )
                                        Text(
                                            text = "" + viewModel.products[index].name,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                        Text(
                                            text = "" + viewModel.products[index].quantity+" "+viewModel.products[index].unit,
                                            fontSize = 12.sp,
                                            color = Color.Black
                                        )
                                    }

                                }  */
                            }

                        }
                    }

                    if(!viewModel.cart.isEmpty()) {
                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .height(45.dp)
                                .width(230.dp),
                            shape = RoundedCornerShape(10.dp),
                            onClick = { navController.navigate(Screen.CartScreen.route)
                                        viewModel.updatePrice() },
                            content = {
                                Text(
                                    text = "Visualizza carrello",
                                    fontSize = 16.sp
                                )
                            }
                        )
                    }


                }
            }

        if (show) {
            AlertDialog(
                modifier = Modifier.height(280.dp),
                onDismissRequest = { show = false },
                text = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Text(text="Ingredienti:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,)
                        Spacer(modifier = Modifier.height(5.dp))

                        if(viewModel.currentProduct.value?.vegan == true || viewModel.currentProduct.value?.glutenFree == true)
                        {
                            if(viewModel.currentProduct.value?.vegan == true && viewModel.currentProduct.value?.glutenFree == true)
                               Text(text="Gluten free, vegano",  fontSize = 14.sp,)
                            if(viewModel.currentProduct.value?.vegan == true && viewModel.currentProduct.value?.glutenFree == false)
                                Text(text="Vegano",  fontSize = 14.sp,)
                            if(viewModel.currentProduct.value?.vegan == false && viewModel.currentProduct.value?.glutenFree == true)
                                Text(text="Gluten free",  fontSize = 14.sp,)

                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        Text(
                            text=""+ (viewModel.currentProduct.value?.ingredients?.replace(",",", ")
                            ?: ""),
                            fontSize = 14.sp, )
                        Spacer(modifier = Modifier.height(10.dp))

                        Text(text="Seleziona la quantità di prodotto:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,)

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                        ) {

                            CircleButton(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Minus",
                                clickable = displayNumber != 0
                            ){
                                if (displayNumber != 0){
                                    displayNumber--
                                }
                            }

                            Spacer(modifier = Modifier.size(8.dp))

                            Text(
                                text = "${displayNumber}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight(500),
                                color = Color.Black
                            )

                            Spacer(modifier = Modifier.size(8.dp))

                            CircleButton(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add"
                            ){
                                displayNumber++
                            }

                        }

                    }
                     },
                confirmButton = {
                    Button(
                        modifier = Modifier.bounceClick(),
                        onClick = { show = false
                            viewModel.currentProduct.value?.let { viewModel.addToCart(it, displayNumber) }
                            displayNumber = 1
                        }
                    ) {
                        Text("Aggiungi")
                    }
                },
                dismissButton = {
                    Button(
                        modifier = Modifier.bounceClick(),
                        onClick = { show = false
                                    checked=false
                                    displayNumber = 1}
                    ) {
                        Text("Annulla")
                    }
                }

            )

        }
        }
  //  }
}

@Composable
fun CircleButton(
    imageVector: ImageVector,
    contentDescription : String = "",
    clickable : Boolean = true,
    click: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .border(BorderStroke(1.dp, Color.DarkGray))
            .clip(RoundedCornerShape(20.dp))
            .size(30.dp)
            .clickable(
                enabled = clickable,
                onClick = click
            )
    ) {

        Icon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            tint= Color.DarkGray,
            modifier = Modifier
                .size(25.dp)
        )

    }
}
