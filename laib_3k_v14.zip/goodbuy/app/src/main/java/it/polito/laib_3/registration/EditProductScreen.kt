package it.polito.laib_3.registration


import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import android.widget.ImageView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.BottomAppBarDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.Product
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.saveImageToInternalStorage


@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProductScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, storage: StorageReference, prod:Product) {

    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current

    var name by remember { mutableStateOf((prod.name)) }
    var quantity by remember { mutableStateOf((prod.quantity.toString())) }
    var unit by remember { mutableStateOf((prod.unit)) }
    var price by remember { mutableStateOf((prod.price)) }
    var dimension by remember { mutableStateOf((prod.dimension)) }
    var ingredients by remember { mutableStateOf((prod.ingredients)) }
    var cat by remember { mutableStateOf((prod.category)) }
    var missing by remember { mutableStateOf(("")) }


    var isExpanded1 by remember { mutableStateOf((false)) }
    var isExpanded2 by remember { mutableStateOf((false)) }
    var isExpanded3 by remember { mutableStateOf((false)) }

    var isVegan by remember { mutableStateOf((prod.vegan)) }
    var isGluten by remember { mutableStateOf((prod.glutenFree)) }

    var error by remember { mutableStateOf((false)) }
    var back by remember { mutableStateOf((false)) }
    var notUpdated by remember { mutableStateOf((false)) }

    var alreadyUploaded by remember { mutableStateOf(false) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    val bitmap = remember { mutableStateOf<Bitmap?>(null) }

    var context = LocalContext.current

    val launcher =
        rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                saveImageToInternalStorage(context, it)
            }
            imageUri = uri
        }

    val open by viewModel.open2.collectAsState()
    val confirm by viewModel.confirm.collectAsState()



    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Modifica il prodotto") },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = colorResource(id = R.color.bar),
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = {
                     //   navController.navigate(Screen.SellerProductsScreen.route)
                    back=true}) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                containerColor = colorResource(id = R.color.bar),
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {

                        IconButton(onClick = { navController.navigate(Screen.HomeSellerScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.SellerLockerScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.lock),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = {
                                navController.navigate(Screen.SellerOrdersScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.White),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.SellerProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(colorResource(id = R.color.green)),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },

        ) { innerPadding ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg4),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        //  horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(modifier = Modifier.height(20.dp))
                        /*Row() {
                        Text(
                            text = "Prodotto",
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            modifier = Modifier.align(alignment = Alignment.CenterVertically),
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(modifier = Modifier.height(30.dp))*/

                        imageUri?.let {

                            if (Build.VERSION.SDK_INT < 28) {
                                bitmap.value = MediaStore.Images
                                    .Media.getBitmap(context.contentResolver, it)


                            } else {
                                val source = ImageDecoder
                                    .createSource(context.contentResolver, it)
                                bitmap.value = ImageDecoder.decodeBitmap(source)
                            }
                        }

                        OutlinedButton(
                            onClick = { launcher.launch("image/*") },
                            modifier = Modifier.height(150.dp).width(150.dp),
                        )
                        {
                            var image = viewModel.currentProduct.value?.image
                            storage.child("images/$image").getBytes(Long.MAX_VALUE)
                                .addOnSuccessListener { bytes ->
                                    bitmap.value =
                                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                }.addOnFailureListener {}

                            if (bitmap.value == null) {
                                val view = remember { ImageView(context) }

                                // Load Gif with Glide library
                                DisposableEffect(context) {
                                    Glide.with(context)
                                        .asGif()
                                        .load("https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif")
                                        .into(view)
                                    onDispose {
                                        // Cleanup when the composable is disposed
                                        Glide.with(context).clear(view)
                                    }
                                }
                                AndroidView(factory = { view })
                            } else {
                                bitmap.value?.let { btm ->
                                    Image(
                                        bitmap = btm.asImageBitmap(),
                                        contentDescription = null,
                                        modifier = Modifier.height(300.dp).width(300.dp),
                                        contentScale = ContentScale.Crop

                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(15.dp))

                        Row() {
                            if (!missing.contains("name")) {
                                Text(
                                    text = "Nome prodotto",
                                    fontSize = 16.sp,
                                )
                            } else {
                                Text(
                                    text = "Nome prodotto *",
                                    color = Color.Red,
                                    fontSize = 16.sp,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        OutlinedTextField(
                            modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                            value = name,
                            onValueChange = { newText ->
                                name = newText
                            },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Done
                            ),
                        )
                        Spacer(modifier = Modifier.height(15.dp))


                        Row() {
                            if (!missing.contains("qty")) {
                                Text(
                                    text = "Quantità di prodotto",
                                    fontSize = 16.sp,
                                )
                            } else {
                                Text(
                                    text = "Quantità di prodotto *",
                                    color = Color.Red,
                                    fontSize = 16.sp,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        Row(
                            horizontalArrangement = Arrangement
                                .spacedBy(
                                    space = 20.dp,
                                ),
                        ) {
                            OutlinedTextField(
                                modifier = Modifier.width(100.dp).focusRequester(focusRequester),
                                value = quantity,
                                onValueChange = { newText ->
                                    quantity = newText
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                            )

                            ExposedDropdownMenuBox(
                                expanded = isExpanded1,
                                onExpandedChange = {
                                    isExpanded1 = !isExpanded1
                                    if (isExpanded1) {
                                        isExpanded2 = false
                                        isExpanded3 = false
                                    }
                                },
                                modifier = Modifier.width(150.dp)
                            ) {
                                TextField(
                                    value = unit,
                                    onValueChange = { },
                                    readOnly = true,
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded1)
                                    },
                                    placeholder = {
                                        Text(text = "gr")
                                    },
                                    colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                    modifier = Modifier.menuAnchor()
                                )
                                ExposedDropdownMenu(
                                    expanded = isExpanded1,
                                    onDismissRequest = {
                                        isExpanded1 = !isExpanded1
                                    },
                                    modifier = Modifier.width(150.dp)

                                ) {

                                    DropdownMenuItem(
                                        text = { Text(text = "gr") },
                                        onClick = {
                                            unit = "gr"
                                            isExpanded1 = false

                                        }
                                    )


                                    DropdownMenuItem(
                                        text = { Text(text = "pezzi") },
                                        onClick = {
                                            unit = "pezzi"
                                            isExpanded1 = false

                                        }
                                    )


                                }

                            }
                        }

                        Spacer(modifier = Modifier.height(15.dp))

                        Row() {
                            if (!missing.contains("cat")) {
                                Text(
                                    text = "Categoria del prodotto",
                                    fontSize = 16.sp,
                                )
                            } else {
                                Text(
                                    text = "Categoria del prodotto *",
                                    color = Color.Red,
                                    fontSize = 16.sp,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        ExposedDropdownMenuBox(
                            expanded = isExpanded3,
                            onExpandedChange = {
                                isExpanded3 = !isExpanded3
                                if (isExpanded3) {
                                    isExpanded1 = false
                                    isExpanded2 = false
                                }
                            },
                            modifier = Modifier.width(300.dp)

                        ) {
                            TextField(
                                value = cat,
                                onValueChange = { },
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded3)
                                },
                                placeholder = {
                                    Text(text = "selezionare una categoria")
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier.menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = isExpanded3,
                                onDismissRequest = {
                                    isExpanded3 = !isExpanded3
                                }
                            ) {
                                viewModel.categoriesProds.forEach { c ->

                                    DropdownMenuItem(
                                        text = { Text(text = "" + c) },
                                        onClick = {
                                            cat = "" + c
                                            isExpanded3 = false

                                        }
                                    )

                                }
                            }

                        }

                        Spacer(modifier = Modifier.height(15.dp))

                        Row() {
                            if (!missing.contains("dim")) {
                                Text(
                                    text = "Dimensione del prodotto",
                                    fontSize = 16.sp,
                                )
                            } else {
                                Text(
                                    text = "Dimensione del prodotto *",
                                    color = Color.Red,
                                    fontSize = 16.sp,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        ExposedDropdownMenuBox(
                            expanded = isExpanded2,
                            onExpandedChange = {
                                isExpanded2 = !isExpanded2
                                if (isExpanded2) {
                                    isExpanded1 = false
                                    isExpanded3 = false
                                }
                            },
                            modifier = Modifier.width(300.dp)

                        ) {
                            TextField(
                                value = dimension,
                                onValueChange = { },
                                readOnly = true,
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded1)
                                },
                                placeholder = {
                                    Text(text = "selezionare una dimensione")
                                },
                                colors = ExposedDropdownMenuDefaults.textFieldColors(),
                                modifier = Modifier.menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = isExpanded2,
                                onDismissRequest = {
                                    isExpanded2 = !isExpanded2
                                }
                            ) {
                                viewModel.dimensions.forEach { dim ->

                                    DropdownMenuItem(
                                        text = { Text(text = "" + dim) },
                                        onClick = {
                                            dimension = "" + dim
                                            isExpanded2 = false

                                        }
                                    )

                                }
                            }

                        }
                        Spacer(modifier = Modifier.height(15.dp))

                        Row() {
                            if (!missing.contains("ingredienti")) {
                                Text(
                                    text = "Ingredienti",
                                    fontSize = 16.sp,
                                )
                            } else {
                                Text(
                                    text = "Ingredienti *",
                                    color = Color.Red,
                                    fontSize = 16.sp,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))

                        OutlinedTextField(
                            modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                            value = ingredients,
                            onValueChange = { newText ->
                                ingredients = newText
                            },
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            maxLines = 3,
                            //  modifier = Modifier.width(330.dp)
                        )

                        Spacer(modifier = Modifier.height(15.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isVegan,
                                colors = CheckboxDefaults.colors(
                                    checkedColor = colorResource(id = R.color.green),
                                    uncheckedColor = Color.White
                                ),
                                onCheckedChange = { checked_ ->
                                    isVegan = checked_
                                }
                            )
                            Text(
                                modifier = Modifier.padding(start = 2.dp),
                                text = "Vegano"
                            )
                        }


                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isGluten,
                                colors = CheckboxDefaults.colors(
                                    checkedColor = colorResource(id = R.color.green),
                                    uncheckedColor = Color.White
                                ),
                                onCheckedChange = { checked_ ->
                                    isGluten = checked_
                                }
                            )
                            Text(
                                modifier = Modifier.padding(start = 2.dp),
                                text = "Senza glutine"
                            )
                        }


                        Spacer(modifier = Modifier.height(15.dp))

                        Row() {
                            if (!missing.contains("price")) {
                                Text(
                                    text = "Prezzo",
                                    fontSize = 16.sp,
                                )
                            } else {
                                Text(
                                    text = "Prezzo *",
                                    color = Color.Red,
                                    fontSize = 16.sp,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                modifier = Modifier.width(120.dp).focusRequester(focusRequester),
                                value = price,
                                onValueChange = { newText ->
                                    price = newText
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                            )
                            Text(
                                modifier = Modifier.padding(start = 10.dp),
                                text = "€",
                                fontSize = 16.sp,
                                textAlign = TextAlign.Start
                            )
                        }
                        Spacer(modifier = Modifier.height(15.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        )
                        {
                            Button(
                                modifier = Modifier
                                    .bounceClick()
                                    .height(45.dp)
                                    .width(135.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = colorResource(
                                        id = R.color.green
                                    ), contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(10.dp),
                                onClick = {

                                    if (name == "" || quantity == "" || unit == "" || dimension == "" || ingredients == "" || price == "" || cat == "")
                                        error = true

                                    if (name == prod.name && quantity == prod.quantity.toString() && unit == prod.unit && dimension == prod.dimension
                                        && ingredients == prod.ingredients && price == prod.price && isVegan == prod.vegan && isGluten == prod.glutenFree && cat == prod.category
                                    )
                                        notUpdated = true


                                    if (!error && !notUpdated) {

                                        var id = ""

                                        viewModel.productsComplete.forEach() { prod ->
                                            if (prod.value == viewModel.currentProduct.value) {
                                                id = prod.key
                                                viewModel.currentImageUrl.value = prod.value.image
                                                Log.d("ggggg", "edit key " + id)
                                            }
                                        }
                                        viewModel.open2.value = true
                                        viewModel.currentImageUrl.value?.let {
                                            viewModel.startThread(
                                                db,
                                                name,
                                                quantity,
                                                unit,
                                                dimension,
                                                ingredients,
                                                price,
                                                isVegan,
                                                isGluten,
                                                id,
                                                cat,
                                                it
                                            )
                                        }
                                    }

                                },
                                content = {
                                    Text(
                                        text = "Conferma",
                                        fontSize = 16.sp
                                    )
                                }
                            )
                        }


                        if (error) {
                            AlertDialog(
                                onDismissRequest = { error = false },
                                text = { Text("E' necessario riempire tutti i campi e inserire un'immagine prima di procede al salvataggio del prodotto") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = colorResource(
                                                id = R.color.green
                                            ), contentColor = Color.Black
                                        ),
                                        onClick = {
                                            error = false
                                            if (name == "")
                                                missing += "name"
                                            if (quantity == "" || unit == "")
                                                missing += "qty"
                                            if (dimension == "")
                                                missing += "dim"

                                            if (ingredients == "")
                                                missing += "ingredienti"

                                            if (price == "")
                                                missing += "price"
                                            if (cat == "")
                                                missing += "cat"

                                            focusManager.clearFocus()
                                        }
                                    ) {
                                        Text("OK")
                                    }
                                }
                            )

                        }

                        if (confirm) {
                            AlertDialog(
                                onDismissRequest = { viewModel.confirm.value = false },
                                text = { Text("Aggiornamento del prodotto avvenuta con successo") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = colorResource(
                                                id = R.color.green
                                            ), contentColor = Color.Black
                                        ),
                                        onClick = {
                                            viewModel.confirm.value = false
                                            navController.navigate(Screen.SellerProductsScreen.route)
                                            missing = ""
                                        }
                                    ) {
                                        Text("OK")
                                    }
                                }
                            )

                        }

                        if (notUpdated) {
                            AlertDialog(
                                onDismissRequest = { notUpdated = false },
                                text = { Text("Non è stato effettuato nessun aggiornamento") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = colorResource(
                                                id = R.color.green
                                            ), contentColor = Color.Black
                                        ),
                                        onClick = {
                                            notUpdated = false
                                            missing = ""
                                            focusManager.clearFocus()
                                        }
                                    ) {
                                        Text("OK")
                                    }
                                }
                            )

                        }


                        if (open) {
                            AlertDialog(
                                onDismissRequest = {
                                },
                                properties = DialogProperties(
                                    usePlatformDefaultWidth = false // disable the default size so that we can customize it
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(start = 42.dp, end = 42.dp) // margin
                                        .background(
                                            color = Color.White,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .padding(top = 36.dp, bottom = 36.dp), // inner padding
                                    verticalArrangement = Arrangement.Center,
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {

                                    ProgressIndicatorLoading(
                                        progressIndicatorSize = 80.dp,
                                        progressIndicatorColor = Color(0xFF35898f)
                                    )

                                    // Gap between progress indicator and text
                                    Spacer(modifier = Modifier.height(32.dp))

                                    // Please wait text
                                    Text(
                                        text = "Attendere...",
                                        style = TextStyle(
                                            color = Color.Black,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Normal
                                        )
                                    )
                                }
                            }
                        }

                        if (back) {
                            AlertDialog(
                                onDismissRequest = { back = false },
                                text = { Text("Confermi di voler tornare indietro esenza effettuare modifiche?") },
                                confirmButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                                        onClick = { navController.navigate(Screen.SellerProductsScreen.route) }
                                    ) {
                                        Text("Si")
                                    }
                                },
                                dismissButton = {
                                    Button(
                                        modifier = Modifier.bounceClick(),
                                        colors = ButtonDefaults.outlinedButtonColors(containerColor = colorResource(id = R.color.green), contentColor = Color.Black),
                                        onClick = { back = false }
                                    ) {
                                        Text("No")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}


                @Composable
                private fun ProgressIndicatorLoading(
                    progressIndicatorSize: Dp,
                    progressIndicatorColor: Color
                ) {
                    val infiniteTransition = rememberInfiniteTransition()

                    val angle by infiniteTransition.animateFloat(
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(
                            animation = keyframes {
                                durationMillis = 600 // animation duration
                            }
                        )
                    )

                    CircularProgressIndicator(
                        progress = 1f,
                        modifier = Modifier
                            .size(progressIndicatorSize)
                            .rotate(angle)
                            .border(
                                12.dp,
                                brush = Brush.sweepGradient(
                                    listOf(
                                        Color.White, // add background color first
                                        progressIndicatorColor.copy(alpha = 0.1f),
                                        progressIndicatorColor
                                    )
                                ),
                                shape = CircleShape
                            ),
                        strokeWidth = 1.dp,
                        color = Color.White // Set background color
                    )
                }



