package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.formatCurrency

@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersUserScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth) {



    var isExpanded by remember { mutableStateOf((false)) }
    var isEmpty by remember { mutableStateOf((true)) }
    var status by remember { mutableStateOf(("")) }
    var chip by remember { mutableStateOf(("")) }
    var rejected by remember { mutableStateOf((false)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
               // horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(7.dp))
                //  item {
                Row() {
                    //   Divider(color = Color.DarkGray, thickness = 2.dp)

                    Box(
                        modifier = Modifier.width(150.dp).wrapContentSize(Alignment.TopEnd).padding(), //if(status=="") end=200.dp else end=2.dp),

                        contentAlignment = Alignment.CenterStart,

                    ) {
                        OutlinedButton(
                            onClick = { isExpanded = !isExpanded }
                        ) {
                            Text(
                                text = "Filtra per",
                                fontSize = 15.sp,
                            )
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = "More"
                            )
                        }

                        DropdownMenu(
                            expanded = isExpanded,
                            onDismissRequest = { isExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("In corso") },
                                onClick = { status = "inProgress&toLocker"
                                            chip = "In corso"
                                           isExpanded = false
                                    isEmpty = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Terminate") },
                                onClick = { status = "leftInLocker&taken&rejected"
                                            chip = "Terminate"
                                            isExpanded = false
                                    isEmpty = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Future") },
                                onClick = { status = "started"
                                            chip = "Future"
                                            isExpanded = false
                                    isEmpty = true }
                            )
                            //     }

                        }
                    }

                    Spacer(modifier = Modifier.width(20.dp))

                    if(status != "") {

                        InputChip(
                            modifier = Modifier.height(40.dp).wrapContentWidth(),
                            onClick = { status = ""
                                        chip = ""
                                        isEmpty = true },
                            label = { Text(text = ""+chip) },
                            selected = true,
                            trailingIcon = {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Localized description",
                                )
                            },
                        )
                    }

                    Spacer(modifier = Modifier.width(70.dp))

                }

                Spacer(modifier = Modifier.height(20.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    viewModel.orderDeliveries()

                    viewModel.deliveries.forEach() { del ->

                        if ((status == "" || status.contains(del.status) && del.id_destinatario== viewModel.currentUser.value?.email ?: "")) {
                            isEmpty = false
                        }
                    }

                    if(!isEmpty)
                    { viewModel.deliveries.forEach() { del ->

                        if ((status == "" || status.contains(del.status)) && del.id_destinatario== viewModel.currentUser.value?.email ?: "" ) {
                            isEmpty = false
                            var statusDel = ""

                            Row() {

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                    ),
                                    modifier = Modifier
                                        .size(width = 370.dp, height = 100.dp),
                                    onClick = {
                                        viewModel.currentDelivery.value = del

                                        if (del.status != "rejected") {
                                            navController.navigate(Screen.OrderDetailUser.route)
                                        } else {
                                            rejected = true
                                        }
                                    }
                                ) {
                                    Row()
                                    {
                                        Box(
                                            modifier = Modifier.fillMaxHeight()
                                                .width(50.dp)
                                                .wrapContentSize(Alignment.Center)
                                                .padding(end = 15.dp, bottom = 30.dp)
                                        ) {
                                            if (del.status == "toLocker") {
                                                statusDel = "In consegna il " + del.date_Update
                                                Image(
                                                    painter = painterResource(id = R.drawable.scooter),
                                                    contentDescription = "confermato",
                                                    colorFilter = ColorFilter.tint(Color.Yellow),
                                                    modifier = Modifier.size(30.dp)
                                                )
                                            }
                                            if (del.status == "leftInLocker") {
                                                statusDel =
                                                    "Consegnato al locker il ${del.date_Update}"
                                                Image(
                                                    painter = painterResource(id = R.drawable.armadietto),
                                                    contentDescription = "confermato",
                                                    colorFilter = ColorFilter.tint(Color.Black),
                                                    modifier = Modifier.size(30.dp)
                                                )
                                            }
                                            if (del.status == "rejected") {
                                                statusDel = "Ordine non confermato"
                                                Image(
                                                    painter = painterResource(id = R.drawable.errore),
                                                    contentDescription = "confermato",
                                                    colorFilter = ColorFilter.tint(Color.Red),
                                                    modifier = Modifier.size(30.dp)
                                                )
                                            }
                                            if (del.status == "taken") {
                                                statusDel = "Ritirato il " + del.date_Update
                                                Image(
                                                    painter = painterResource(id = R.drawable.check),
                                                    contentDescription = "confermato",
                                                    modifier = Modifier.size(30.dp)
                                                )
                                            }

                                            if (del.status == "inProgress" || del.status == "started") {
                                                statusDel = "Da consegnare il " + del.date_Due
                                                Image(
                                                    painter = painterResource(id = R.drawable.confermato),
                                                    contentDescription = "confermato",
                                                    colorFilter = if (del.status == "inProgress") ColorFilter.tint(
                                                        Color.Green
                                                    ) else ColorFilter.tint(Color.Black),
                                                    modifier = Modifier.size(30.dp)
                                                )
                                            }

                                        }

                                        Box(
                                            modifier = Modifier.fillMaxHeight()
                                                .width(220.dp)
                                                .wrapContentSize(Alignment.TopStart)
                                        ) {
                                            Column() {

                                                Text(
                                                    text = "" + del.id_mittente,
                                                    textAlign = TextAlign.Left,
                                                    fontSize = 16.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Black
                                                )

                                                val prods: Map<String, Int> =
                                                    del.products.split(',')
                                                        .map { it.split(':') }
                                                        .associate { it[0] to it[1].toInt() }


                                                prods.forEach() { item ->
                                                    Spacer(modifier = Modifier.height(3.dp))
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        verticalAlignment = Alignment.CenterVertically

                                                    ) {

                                                        Text(
                                                            text = "${item.value} x ${item.key}",
                                                            fontSize = 15.sp,
                                                            textAlign = TextAlign.Start,
                                                        )
                                                    }

                                                }

                                                if (del.status == "inProgress") {
                                                    Text(
                                                        text = "Ordine confermato",
                                                        textAlign = TextAlign.Left,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.Green
                                                    )
                                                }

                                                Text(
                                                    text = "" + statusDel,
                                                    textAlign = TextAlign.Left,
                                                    fontSize = 14.sp,
                                                    color = if (statusDel == "Ordine non confermato") Color.Red
                                                    else Color.Black
                                                )
                                            }

                                        }
                                        Box(
                                            modifier = Modifier.fillMaxHeight()
                                                .width(100.dp)
                                                .wrapContentSize(Alignment.TopEnd)
                                        ) {
                                            Text(
                                                text = "" + formatCurrency(del.price) + " €",
                                                modifier = Modifier
                                                    .padding(15.dp),
                                                textAlign = TextAlign.End,
                                            )
                                        }
                                    }
                                }

                            }


                        }
                       }
                    }

                    if(isEmpty && chip!="")
                    {
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(
                            modifier = Modifier
                                .padding(start = 16.dp, end = 16.dp)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        )
                        {
                            Row()
                            {  val text = "Nessun ordine nello stato '$chip'."

                                val annotatedString = buildAnnotatedString {
                                    append(text)
                                    addStyle(
                                        style = SpanStyle(fontWeight = FontWeight.Bold),
                                        start = 25,
                                        end = text.length-1
                                    )
                                }

                                Text(text = annotatedString) }
                        }
                    }
                }
            }
        }
    }

    if (rejected) {
        AlertDialog(
            modifier = Modifier.wrapContentSize(),
            onDismissRequest = { rejected = false },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ){

                    Text(text="Siamo spiacenti, l'ordine non è stato confermato!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,)
                    Spacer(modifier = Modifier.height(18.dp))

                    if(viewModel.currentDelivery.value?.rejected?.contains("Alcuni prodotti non sono attualmente disponibili") == true)
                    {
                        val parts = viewModel.currentDelivery.value?.rejected?.split(":")
                        val mot = parts?.get(0)
                        val other = parts?.get(1)

                        Text(text="${mot}",
                            fontSize = 16.sp,)

                        Text(text="${other}",
                            fontSize = 16.sp,)
                    }
                    else
                    { Text(text="${viewModel.currentDelivery.value?.rejected}",
                        fontSize = 16.sp,) }

                    Spacer(modifier = Modifier.height(18.dp))
                    Text(text="Chiama ${viewModel.currentDelivery.value?.id_mittente}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,)

                    var num=""

                    viewModel.sellers.forEach() {s->
                        if(s.name == viewModel.currentDelivery.value?.id_mittente)
                            num = s.number
                    }
                    Spacer(modifier = Modifier.height(1.dp))
                    Text(text="$num",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,)

                }
            },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = { rejected= false }
                ) {
                    Text("OK")
                }
            },

            )

    }
}








