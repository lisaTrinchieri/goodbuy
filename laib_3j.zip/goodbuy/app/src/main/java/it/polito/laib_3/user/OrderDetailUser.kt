package it.polito.laib_3.user


import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.storage.StorageReference
import it.polito.laib_3.Consegna
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.formatCurrency


@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDetailUser(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic : FirebaseAuth, delivery: Consegna, storage: StorageReference) {


    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text=""+delivery.id_mittente
                ) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
                navigationIcon = {
                    IconButton(onClick = { navController.navigate(Screen.OrdersUserScreen.route) }) {
                        Icon(

                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "to show",
                            tint = Color.White,
                        )
                    }
                },            )
        },
        bottomBar = {
            BottomAppBar(
                actions = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 50.dp,
                            ),
                    )
                    {
                        IconButton(onClick = { navController.navigate(Screen.HomeUserScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.home_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.UserSearchScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.search),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(

                            onClick = { navController.navigate(Screen.OrdersUserScreen.route)
                            }) {
                            Image(
                                painter = painterResource(id = R.drawable.list_filled),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { navController.navigate(Screen.UserProfileScreen.route) }) {
                            Image(
                                painter = painterResource(id = R.drawable.utente),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(7.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 5.dp,
                                alignment = Alignment.CenterHorizontally
                            ),
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        /*     Button(
                            enabled = false,
                            modifier= Modifier.size(65.dp),
                            onClick = { /*TODO*/ },
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor=Color.DarkGray)
                        ) {

                            Image(
                                painter = painterResource(id = R.drawable.ordine_confermato),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Yellow),
                                modifier = Modifier.size(40.dp)
                            )
                        } */

                        if (delivery.status == "started") {
                            OutlinedIconButton(
                                onClick = { },
                                enabled = false,
                                border = BorderStroke(1.dp, Color.Black)
                            ) {

                                Image(
                                    painter = painterResource(id = R.drawable.ordine_confermato),
                                    contentDescription = "confermato",
                                    colorFilter = ColorFilter.tint(Color.Black),
                                    modifier = Modifier.size(23.dp)
                                )
                            }
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.ordine_confermato),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }

                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight / 2),
                                end = Offset(x = 0f, y = canvasHeight / 2),
                                color = Color.DarkGray,
                                strokeWidth = if(delivery.status == "inProgress" || delivery.status == "toLocker" ||
                                    delivery.status == "leftInLocker" || delivery.status == "taken") 3F else 1F
                            )
                        }

                        if (delivery.status == "inProgress" || delivery.status == "toLocker") {
                            OutlinedIconButton(
                                onClick = { },
                                enabled = false,
                                border = BorderStroke(1.dp, Color.Black)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.busta_della_spesa),
                                    contentDescription = "confermato",
                                    colorFilter = ColorFilter.tint(Color.Black),
                                    modifier = Modifier.size(23.dp)
                                )
                            }
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.busta_della_spesa),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )

                        }

                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight / 2),
                                end = Offset(x = 0f, y = canvasHeight / 2),
                                color = Color.DarkGray,
                                strokeWidth = if(delivery.status == "leftInLocker" || delivery.status == "taken") 3F else 1F
                            )
                        }

                        if (delivery.status == "leftInLocker") {
                            OutlinedIconButton(
                                onClick = { },
                                enabled = false,
                                border = BorderStroke(1.dp, Color.Black)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.locker),
                                    contentDescription = "confermato",
                                    colorFilter = ColorFilter.tint(Color.Black),
                                    modifier = Modifier.size(23.dp)
                                )
                            }
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.locker),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )
                        }

                        Canvas(modifier = Modifier.width(55.dp)) {

                            val canvasWidth = size.width
                            val canvasHeight = size.height

                            drawLine(
                                start = Offset(x = canvasWidth, y = canvasHeight / 2),
                                end = Offset(x = 0f, y = canvasHeight / 2),
                                color = Color.DarkGray,
                                strokeWidth = if(delivery.status=="taken" ) 3F else 1F
                            )
                        }

                        if (delivery.status == "taken") {
                            OutlinedIconButton(
                                onClick = { },
                                enabled = false,
                                border = BorderStroke(1.dp, Color.Black)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ritiro),
                                    contentDescription = "confermato",
                                    colorFilter = ColorFilter.tint(Color.Black),
                                    modifier = Modifier.size(23.dp)
                                )
                            }
                        } else {
                            Image(
                                painter = painterResource(id = R.drawable.ritiro),
                                contentDescription = "confermato",
                                colorFilter = ColorFilter.tint(Color.Black),
                                modifier = Modifier.size(23.dp)
                            )

                        }


                    }
                    Row()
                    {
                        Text(
                            modifier = Modifier.padding(end = 10.dp),
                            text = "Ordine confermato",
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                        )
                        Text(
                            modifier = Modifier.padding(end = 10.dp),
                            text = "In preparazione",
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                        )
                        Text(
                            modifier = Modifier.padding(end = 10.dp),
                            text = "Portato al locker",
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                        )
                        Text(
                            modifier = Modifier.padding(end = 10.dp),
                            text = "Ordine ritirato",
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    var address = ""
                    viewModel.lockersList.forEach() { lock ->
                        if (lock.id_locker == viewModel.currentDelivery.value?.locker ?: "")
                            address = lock.spaces[0].address
                    }

                    Text(
                        text = "${address}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val text =
                            "Codice di ritiro: ${viewModel.currentDelivery.value?.code_sblocco}"

                        val annotatedString = buildAnnotatedString {
                            append(text)
                            addStyle(
                                style = SpanStyle(fontWeight = FontWeight.Bold),
                                start = 16,
                                end = text.length
                            )
                        }

                        Text(text = annotatedString)
                    }



                    Spacer(modifier = Modifier.height(15.dp))

                    Divider(color = Color.DarkGray, thickness = 2.dp)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Il tuo ordine",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Start,
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    val prods: Map<String, Int> = delivery.products.split(',')
                        .map { it.split(':') }
                        .associate { it[0] to it[1].toInt() }


                    prods.forEach() { item ->
                        Spacer(modifier = Modifier.height(5.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement
                                .spacedBy(
                                    space = 30.dp,
                                    alignment = Alignment.Start
                                ),
                            verticalAlignment = Alignment.CenterVertically

                        ) {
                            val bitmap = remember { mutableStateOf<Bitmap?>(null) }

                            var image = ""

                            viewModel.products.forEach() { product ->

                                if (product.name == item.key && product.shop == delivery.id_mittente) {
                                    image = product.image

                                }
                            }


                            storage.child("images/$image").getBytes(Long.MAX_VALUE)
                                .addOnSuccessListener { bytes ->
                                    bitmap.value =
                                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                }.addOnFailureListener {}


                                bitmap?.value.let { btm ->
                                    if (btm != null) {
                                        Box(
                                            modifier = Modifier.height(60.dp).width(60.dp)
                                                .border(1.dp, Color.Black)
                                                .clip(shape = RoundedCornerShape(size = 12.dp))
                                        ) {
                                            Image(
                                                bitmap = btm.asImageBitmap(),
                                                contentDescription = null,
                                                modifier = Modifier
                                                    .size(50.dp)
                                                    .clip(shape = RoundedCornerShape(size = 12.dp)),
                                                contentScale = ContentScale.Fit
                                            )
                                        }
                                    }
                                    else
                                    {    Box(
                                            modifier = Modifier.height(60.dp).width(60.dp)
                                                .border(1.dp, Color.Black)
                                                .clip(shape = RoundedCornerShape(size = 12.dp))
                                        ) {
                                        val view = remember { ImageView(context) }

                                        // Load Gif with Glide library
                                        DisposableEffect(context) {
                                            Glide.with(context)
                                                .asGif()
                                                .load("https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif")
                                                .into(view)
                                            onDispose {
                                                // Cleanup when the composable is disposed
                                                Glide.with(context).clear(view)
                                            }
                                        }
                                        AndroidView(factory = { view })
                                    }
                                }
                            }

                            Box(
                                modifier = Modifier.fillMaxHeight().width(180.dp)
                            ) {
                                Text(
                                    text = "" + item.key + " x " + item.value,
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Start,
                                    modifier = Modifier.padding(end = 20.dp)
                                )
                            }

                            var price = 0.00
                            viewModel.products.forEach() { prod ->
                                if (item.key == prod.name)
                                    price = prod.price.toDouble()
                            }
                            Box(
                                modifier = Modifier.fillMaxHeight().width(100.dp)
                            ) {
                                Text(
                                    text = "" + formatCurrency(price * item.value) + " €",
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Right,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                    }

                    Spacer(modifier = Modifier.height(15.dp))

                    Divider(color = Color.DarkGray, thickness = 2.dp)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement
                            .spacedBy(
                                space = 200.dp,
                                //  alignment = Alignment.Start
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Totale",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Start,
                        )

                        Text(
                            text = "" + formatCurrency(delivery.price) + " €",
                            fontSize = 18.sp,
                            textAlign = TextAlign.Right,
                        )
                    }


                }

                }
            }
        }
    }
