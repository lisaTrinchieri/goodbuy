package it.polito.laib_3

sealed class Screen(val route: String) {

    object SplashScreen : Screen("splash_screen")
    object LoginScreen : Screen("login_screen")
    object KeypadScreen : Screen("keypad_screen")
    object StartScreen : Screen("start_screen")
    object ResultScreen : Screen("result_screen")


}
