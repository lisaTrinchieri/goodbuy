package it.polito.laib_3.screen

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.android.volley.RequestQueue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.getValue
import it.polito.laib_3.Consegna
import it.polito.laib_3.InputDots
import it.polito.laib_3.LockerSpace
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.R
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick
import it.polito.laib_3.buttonShape
import it.polito.laib_3.sendNotification
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.random.Random

//schermata finale di apertura locker
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KeypadScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, authentic: FirebaseAuth, FCM_API:String, serverKey:String, contentType:String, requestQueue: RequestQueue) {

    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd | HH:mm")
    val current = LocalDateTime.now().format(formatter)

    val parts = current.split(" | ")
    val date = parts[0]
    val time = parts[1]

    var error by remember { mutableStateOf((false)) }
    var empty by remember { mutableStateOf((false)) }
    var exit by remember { mutableStateOf((false)) }

    var confirm by remember { mutableStateOf((false)) }



    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Goodbuy locker",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )

        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(30.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically

                ) {
                    Text(
                        text = "Inserisci il pin:",
                        fontSize = 22.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }
                Spacer(modifier = Modifier.height(35.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    horizontalArrangement = Arrangement.spacedBy(30.dp),
                    verticalAlignment = Alignment.CenterVertically

                ) {
                    InputDots(numbers = viewModel.code)
                }

                Spacer(modifier = Modifier.height(30.dp))

                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        buttonShape(viewModel = viewModel, content = "1")
                        Spacer(modifier = Modifier.width(30.dp))
                        buttonShape(viewModel = viewModel, content = "2")
                        Spacer(modifier = Modifier.width(30.dp))
                        buttonShape(viewModel = viewModel, content = "3")

                    }
                    Spacer(modifier = Modifier.height(25.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        buttonShape(viewModel = viewModel, content = "4")
                        Spacer(modifier = Modifier.width(30.dp))
                        buttonShape(viewModel = viewModel, content = "5")
                        Spacer(modifier = Modifier.width(30.dp))
                        buttonShape(viewModel = viewModel, content = "6")

                    }
                    Spacer(modifier = Modifier.height(25.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        buttonShape(viewModel = viewModel, content = "7")
                        Spacer(modifier = Modifier.width(30.dp))
                        buttonShape(viewModel = viewModel, content = "8")
                        Spacer(modifier = Modifier.width(30.dp))
                        buttonShape(viewModel = viewModel, content = "9")

                    }
                    Spacer(modifier = Modifier.height(25.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        buttonShape(viewModel = viewModel, content = "*")
                        Spacer(modifier = Modifier.width(30.dp))
                        buttonShape(viewModel = viewModel, content = "0")
                        Spacer(modifier = Modifier.width(30.dp))
                        buttonShape(viewModel = viewModel, content = "#")

                    }

                    Spacer(modifier = Modifier.height(45.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(55.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically

                    ) {
                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .height(55.dp)
                                .width(85.dp),
                            shape = RoundedCornerShape(20.dp),
                            onClick = { viewModel.code = "" },
                            content = {
                                Image(
                                    painter = painterResource(id = R.drawable.delete),
                                    contentDescription = "confermato",
                                    colorFilter = ColorFilter.tint(Color.White),
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        )
                        Spacer(modifier = Modifier.width(30.dp))
                        //conferma
                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .height(55.dp)
                                .width(85.dp),
                            shape = RoundedCornerShape(20.dp),
                            onClick = {

                                if (viewModel.code == "" || viewModel.code.length < 4)
                                    empty = true
                                else {
                                    if (viewModel.code == "**##") {
                                        exit = true
                                        viewModel.loggedIn.value = false

                                        viewModel.code = ""
                                        viewModel.clearDel()
                                        viewModel.currentDel.value = null
                                        viewModel.currentSpace.value = null
                                        viewModel.current.value = null

                                    } else {

                                        viewModel.current.value?.spaces?.forEach() { space ->

                                            if (space.code_ins == viewModel.code.toInt() && space.free && !space.open) {

                                                viewModel.currentSpace.value = space
                                                confirm = true
                                                viewModel.currentDel.value = space.delivery
                                                viewModel.status.value = "left"

                                                var randomNumber = generate(viewModel)

                                                var spaceNew = space?.let {
                                                    LockerSpace(
                                                        space.name,
                                                        false,
                                                        randomNumber,
                                                        space.code_rit,
                                                        space.dimension,
                                                        space.address,
                                                        space.positionX,
                                                        space.positionY,
                                                        true,
                                                        space.delivery
                                                    )
                                                }
                                                db.child("lockers")
                                                    .child("" + viewModel.current.value!!.id_locker)
                                                    .child("" + space.name).setValue(spaceNew)

                                            } else if (space.code_rit == viewModel.code.toInt() && !space.free && !space.open) {

                                                viewModel.currentSpace.value = space
                                                confirm = true
                                                viewModel.status.value = "taken"
                                                viewModel.currentDel.value = space.delivery

                                                var randomNumber = generate(viewModel)

                                                // val random = Random.nextInt(1000, 10000)

                                                var spaceNew = space?.let {
                                                    LockerSpace(
                                                        space.name,
                                                        true,
                                                        space.code_ins,
                                                        randomNumber,
                                                        space.dimension,
                                                        space.address,
                                                        space.positionX,
                                                        space.positionY,
                                                        true,
                                                        ""
                                                    )
                                                }
                                                db.child("lockers")
                                                    .child("" + viewModel.current.value!!.id_locker)
                                                    .child("" + space.name).setValue(spaceNew)

                                            } else
                                                error = true

                                        }
                                    }
                                }
                            },
                            content = {
                                Image(
                                    painter = painterResource(id = R.drawable.ok),
                                    contentDescription = "confermato",
                                    colorFilter = ColorFilter.tint(Color.White),
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        )

                        Spacer(modifier = Modifier.width(30.dp))
                        Button(
                            modifier = Modifier
                                .bounceClick()
                                .height(55.dp)
                                .width(85.dp),
                            shape = RoundedCornerShape(20.dp),
                            onClick = {
                                viewModel.code = viewModel.code.dropLast(1)
                            },
                            content = {
                                Image(
                                    painter = painterResource(id = R.drawable.back),
                                    contentDescription = "confermato",
                                    colorFilter = ColorFilter.tint(Color.White),
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        )
                    }
                }


            }
        }
    }

    if (empty) {
        AlertDialog(
            onDismissRequest = { empty = false },
            text = { Text("Inserire un codice") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                        empty = false
                        viewModel.code = ""
                    }
                ) {
                    Text("OK")
                }
            }
        )

    }

    if (error) {
        AlertDialog(
            onDismissRequest = { error = false },
            text = { Text("Il codice inserito non è valido") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                        error = false
                        viewModel.code = ""
                    }
                ) {
                    Text("OK")
                }
            }
        )

    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            text = { Text("Codice valido, attendi che lo sportello si apra") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                        confirm = false
                        error=false
                        empty=false
                        navController.navigate(Screen.ResultScreen.route)
                    }
                ) {
                    Text("OK")
                }
            }
        )

    }

    if (exit) {
        AlertDialog(
            onDismissRequest = { exit = false },
            text = { Text("Confermi di voler effettuare il logout?") },
            confirmButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = {
                        authentic.signOut()

                        exit = false
                        navController.navigate(Screen.LoginScreen.route)

                        viewModel.current.value = null
                        viewModel.currentSpace.value = null
                        viewModel.code = ""

                        viewModel.clearDel()

                    }
                ) {
                    Text("Si")
                }
            },
            dismissButton = {
                Button(
                    modifier = Modifier.bounceClick(),
                    onClick = { exit=false }
                ) {
                    Text("No")
                }
            }
        )
    }
}

fun generate(viewModel: PurchaseViewModel): Int {
    var randomNumber=0
    do {
        randomNumber = Random.nextInt(1000, 10000) // Genera un numero casuale tra 1000 e 9999 inclusi
    } while (randomNumber== viewModel.current.value!!.spaces[0].code_ins
        || randomNumber== viewModel.current.value!!.spaces[0].code_rit
        || randomNumber== viewModel.current.value!!.spaces[1].code_ins
        || randomNumber== viewModel.current.value!!.spaces[1].code_rit)

    return randomNumber
}