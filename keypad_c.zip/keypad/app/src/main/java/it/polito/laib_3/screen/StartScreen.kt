package it.polito.laib_3.screen

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import it.polito.laib_3.PurchaseViewModel
import it.polito.laib_3.Screen
import it.polito.laib_3.bounceClick


//per iniziare l'experience
@RequiresApi(Build.VERSION_CODES.O)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StartScreen(navController: NavController, viewModel: PurchaseViewModel, db: DatabaseReference, auth:FirebaseAuth) {

    if(auth.currentUser?.email?.contains("lock1") == true)
    {    getLocker("locker1", db, viewModel)
        viewModel.loggedIn.value = true }

    if(auth.currentUser?.email?.contains("lock2") == true)
    {   getLocker("locker2", db,viewModel)
        viewModel.loggedIn.value = true
    }

    if(auth.currentUser?.email?.contains("lock3") == true)
    {   getLocker("lock3", db, viewModel)
        viewModel.loggedIn.value = true}

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = "Goodbuy locker",
                    )
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                ),
            )

        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.height(30.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
            }
        },

        ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(50.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically

                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Favorite Item",
                    )
                    Spacer(modifier = Modifier.width(25.dp))
                    Text(
                        text = ""+ (viewModel.current.value?.spaces?.get(0)?.address ?: ""),
                        // fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }
                Spacer(modifier = Modifier.height(80.dp))
                Row() {
                    Text(
                        text = "Benvenuto!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 30.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }

                Spacer(modifier = Modifier.height(20.dp))
                Row() {
                    Text(
                        text = "Clicca il bottone qui sotto per digitare il codice di inserimento o di ritiro",
                        fontSize = 22.sp,
                        modifier = Modifier.align(alignment = Alignment.CenterVertically)
                    ) }

                Spacer(modifier = Modifier.height(40.dp))

                Button(
                    modifier = Modifier
                        .bounceClick()
                        .height(45.dp)
                        .width(120.dp),
                    shape = RoundedCornerShape(20.dp),
                    onClick = { navController.navigate(Screen.KeypadScreen.route)
                        viewModel.code = ""},
                    content = { Text( text="Inizia",
                        fontSize = 16.sp ) }
                )
            }
        }
    }
}